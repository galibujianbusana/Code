/** Automatically generated file. DO NOT MODIFY */
package com.multak.MK8507MOA;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}