package com.multak.Karaoke;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class YouTubeInfo{
	//
	public static int StartSongIndex = 0x10000000 + 500000;  
	public static ArrayList<String> VideoIDList = new ArrayList<String>(); 
	public static HashMap<String, String> SongNameMap = new HashMap<String, String>();
	public static HashMap<String, String> SongRealUrl = new HashMap<String, String>();
	private static Lock lock = new ReentrantLock();

	public static String GetSongName(int SongIndex)
	{
		String SongName = "";
		int Pos = SongIndex - StartSongIndex;
		if(Pos >= 0 && Pos < VideoIDList.size())
		{
			return SongNameMap.get(VideoIDList.get(Pos));
		}
				
		return SongName;
	}
	
	public static String GetSongUrlBySongIndex(int SongIndex)
	{
		String url = "";
		int Pos = SongIndex - StartSongIndex;
		if(Pos >= 0 && Pos < VideoIDList.size())
		{
			url = GetSongUrlByVideoId(VideoIDList.get(Pos));
		}
		
		return url;
	}
	
	public static String GetSongUrlByVideoId(String VideoId)
	{
		String url = "";
		if(SongRealUrl.containsKey(VideoId) == true)
		{
			url = SongRealUrl.get(VideoId);
		}
		return url;
	}
	
	public static int AddYouTubeProg(String videoId, String songName, boolean needOrder)
	{
		int SongIndex = 0; 
		try
		{
			lock.lock();
			
			if(VideoIDList.contains(videoId) == true)
			{
				SongIndex = VideoIDList.indexOf(videoId) + StartSongIndex;
			}
			else
			{
				SongIndex = VideoIDList.size() + StartSongIndex;
				
				VideoIDList.add(videoId);
				SongNameMap.put(videoId, songName);
				
				YouTubeThreadUrl _threadUrl = new YouTubeThreadUrl(videoId);
				_threadUrl.start();
			}
			if(needOrder == true)
			{
				KaraokeLib.orderYouTubeVideo(SongIndex, songName, videoId);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally {
			lock.unlock();
		}
		return SongIndex;
	}
	

}