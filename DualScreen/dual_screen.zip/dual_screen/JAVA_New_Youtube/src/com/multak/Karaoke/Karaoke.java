﻿package com.multak.Karaoke;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.zip.ZipException;

import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.http.conn.util.InetAddressUtils;

import com.multak.MK8507MOA.MainActivity;
import com.multak.MK8507MOA.R;
import com.multak.MK8507MOA.AppUtils;
import com.multak.MK8507MOA.SimpleWebServer;





import com.multak.MultakStandard.BaseHelper;
import com.multak.MultakStandard.MultakConnect;
import com.multak.MultakStandard.MultakStandard;
import com.multak.MultakStandard.MultakConnect.NetType;
import com.multak.MultakStandard.MultakConnectListener;


import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.StatFs;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import android.media.AudioManager;
import android.hardware.display.DisplayManager;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class Karaoke implements MyListener,MultakConnectListener {
	private static String TAG = "Karaoke";
	
	private static String Uid = "multak@multak";
	private static String sID = null;
	private static String macAddress = "";
	private static int MultakConnectInfo = 0;
	private static final String INSTALLATION = "INSTALLATION";

	private Context mcontext,g_context;

	//apk info
	private PackageManager pm;
	private String apkPath = "";
	private PackageInfo info2 = null;
    
	//karaoke path
	public static String HappyKTVFilePath = "/KARAOKE";
	private String UpdateFilePath = "/Update";
	private String RecFilePath = "/REC";
	private String ResFilePath = "/RES";
	private String SongFilePath = "/SONG";
	private String CfgFilePath = "/CFG";
	private String PicFilePath = "/PIC";
	private String UserSongPath = "/USER";
	private String BgvFilePath = "/BGV";
	private String NetFilePath = "/NET";
	private String NetSongPath = "/NET/SONG";
	private String CameraPath = "/Camera";
	private String FolderPath = "";
	private String InternalUserIniPath = "/data/data/com.multak.MK8507MOA/Android";
	private String CloudServerURL = "";
	//rate
	private static int nFlagMobile = 0;
	public static int LocalSampleRate = 480;
	public static int LocalSampleRateOut = 480;

	//youtube
	public static YouTubeService mYoutubeService = null;
	public static YouTubeService mYoutubeService2 = null;
	
	public static Map<Long, File> DownIDSongIndexMap = new HashMap<Long, File>();
	public static Map<String, String> DownTaskMap = new HashMap<String, String>();
	
	//karaoke view
	private static Loading mLoadingView = null;
	private static KaraokeVGA mKaraokeVGA = null;
	private static KaraokeHDMI mKaraokeHDMI = null;

	//karaoke bg pic
	public static String bgPicPath = "";
	public static boolean bgPicExit = true;
	public static List<String> bgfilePaths = new ArrayList<String>();
	public static int bgfileIndex = 0;
	
	//public static List<String> DownloadID = new ArrayList<String>();
	//public static List<String> DownloadNmae = new ArrayList<String>();
	//public static int downindex = 0;
	
	final static  int downloadlimit = 400;//20;
	
	public static String[][] aDownload = new String[2][downloadlimit];
	public static int putindex = 0;
	public static int getindex = 0;
	public static boolean downloadExit = true;
	public static long downloadId = 0;
	public static long laststatus = 0;
	//karaoke start
	private MultakStandard mMultakStandard = null;
	private WakeLock wakeLock = null;	
	public static int RenderStatus = 0;
	public static int RenderStatusEx = 0;
	public static int singStatusChanged = 0;
	public static int FinishKaraokeStartFlag = 0;
	private static int UsbDeviceNum = 0;
	
    private Timer HotPotCheck;
    private TimerTask HotPotCheckTask;
    
    private DownloadManager downloadManager;
    private int downloadprepared = 1;
	//karaoke status
	public enum SkyKTVState {
		SkyKTV_Init,
		SkyKTV_Update,
		SkyKTV_Start,
		SkyKTV_ChooseGame,
		SkyKTV_UpdateJNI,
		SkyKTV_Init2,
		SkyKTV_Quit,
	};
	public static SkyKTVState m_SkyKTVState = SkyKTVState.SkyKTV_Quit;
	public static SkyKTVState m_SkyKTVStateEx = SkyKTVState.SkyKTV_Quit;

	public static GridView mGridView = null;
	public static ImageButton mPriority = null;
	public static ImageButton mSelect = null;
	public static ImageButton mDownload = null;
	public static TextView mProgress = null;
	public static TextView mWaring = null;
	public static TextView mYTSearch = null;
	public static boolean YTSearched = false;
	public static int mFocusID = 0;
	
	
	//wifi hotspot
	private WifiManager wifiManager;	
	private WifiUtil mWifiUtil;
    private Timer mHotSpot;
    private TimerTask mHotSpotTask;
    private Timer wifiLevelTimer;    
    private TimerTask wifiLevelTimerTask;
    //public boolean servernotfound = false;
    
    public static int progressbarshown = 0;	//0 normal 1 showing 2 hide
    private int progresstype = 0;	//0 normalbar 1 circle
    private int lastprogress = 0;
    //exit 
    private static int isExit = 0;
    
    private Timer mTimerMiniuteCount;
    private TimerTask mTimerTaskMiniuteCount;
    
    private Timer mTimerScoreCount;
    private TimerTask mTimerTaskScoreCount;
    
    private int miniutebase = (1000*64);
    private int scorebase = 30 ;
    private int miniutecount = 0;
    private int score100limit = 10;
    private boolean score100enable = false;
    public boolean DLUseHttp = false;
    private boolean HDDLowCap = false;
    
    public static Map<String,Uri> MapYPIC = null;
    
	public Karaoke(Context context) {
		mcontext = context;
	}

	public void KaraokeInit() {
		g_context = mcontext;
		my_id(g_context);
		my_id(mcontext);
		
		MapYPIC = new HashMap<String,Uri>();
		wifiManager = (WifiManager) mcontext.getSystemService(Context.WIFI_SERVICE);  
		WifiInfo wifiinfo = wifiManager.getConnectionInfo();
		macAddress = wifiinfo.getMacAddress();
		if (macAddress == null || macAddress.length() != 17) {
			macAddress = "FF:FF:01:02:03:04";
		}
		BaseHelper.log(TAG, macAddress);
		macAddress = macAddress.replace(":", "");
		macAddress = macAddress.replace(".", "");
		Uid = macAddress + "." + sID + ".1";
		
		mYoutubeService = new YouTubeService(mcontext);

		initKaraokePath();
		initKaraokeLanguage();
		
		//Loading
		Display display = ((Activity) mcontext).getWindowManager().getDefaultDisplay();
        mLoadingView = new Loading(mcontext, display.getWidth(), display.getHeight());
        mLoadingView.setLoadingListener(this);
        mLoadingView.setLoadingTitle("Ver " + info2.versionName, "For Android");
        ((Activity) mcontext).addContentView(mLoadingView, new ViewGroup.LayoutParams(display.getWidth(), display.getHeight()));

		SharedPreferences prefs = mcontext.getSharedPreferences(mcontext.getPackageName(), Context.MODE_PRIVATE);
		nFlagMobile = prefs.getInt("mobileFlag", 0);
		if (nFlagMobile == 1) {
			KaraokeLib.monoFlag = prefs.getInt("mono", 2);
			Karaoke.LocalSampleRate = prefs.getInt("samplerate", 480);
			Karaoke.LocalSampleRateOut = prefs.getInt("samplerateOut", 480);
		}
		((Activity) mcontext).getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		//VGA
		mKaraokeVGA = new KaraokeVGA(mcontext);
		mKaraokeVGA.initKaraokeView();
		

		
		startPicThread();
		startWifiRender();
		
		//later
		startDownloadTask();
		
		//downloadSong();
	
	}
	
	
	public int getscore()
    {
    	int score = 0;
    	int max=100;
        int min=80;
        //Log.i(TAG,"miniutecount " + miniutecount);
    	if(score100enable == true)
    	{
    		Random random = new Random();
    		score = random.nextInt(max-min+1) + min;
    		Log.i(TAG,"ori score " + score + " timeleft " + (scorebase - miniutecount));
    		if(score != 100 && (scorebase - miniutecount) <= score100limit)
    		{
    			score = 100;
    			
    		}
    		Log.i(TAG,"get socre 222 " + score);
    		if(score == 100)
    		{
    			score100enable = false;
    		}	
    	}
    	else
    	{
    		max = 99;
    		Random random = new Random();
    		score = random.nextInt(max-min+1) + min;
    		Log.i(TAG,"get socre 111 " + score);
    	}	
    	return score;
    }
	
	public void KaraokeStart() {
		mMultakStandard = new MultakStandard(MultakStandard.Platforms[0], 
				MultakStandard.NetDetectNormal, MultakStandard.StorageDetectNormal);
		mMultakStandard.MultakStandardInit2(mcontext, (MultakConnectListener) this);
	
		if (Uid.trim().length() == 0) {
			ControlUART(0x80000);
			return;
		}

		StartKaraokePresentation();
		
		GetMountDevice();

		KaraokeLib.InitAudioRecord();
		KaraokeLib.InitAudioTrack();
		
		KaraokeLib.myListener = this;
		KaraokeVGALib.myListener = this;
		FileProgressMonitor.myListener = this;
		FtpUtil.myListener = this;
		if (KaraokeHDMI.mCameraPicture == null) {
			KaraokeHDMI.mCameraPicture = new CameraPicture();
		}
		
		if (singStatusChanged == 1) {
			SaveLocalSingInfo();
			singStatusChanged = 0;
		}
		
		RenderStatusEx = 1;

		PowerManager pm = (PowerManager) mcontext.getSystemService(Context.POWER_SERVICE);
		wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, Karaoke.class.getName());
		wakeLock.acquire();
		
		FinishKaraokeStartFlag++;
		
		mTimerMiniuteCount = new Timer();    
		mTimerTaskMiniuteCount = new TimerTask(){
			
			 @Override
	            public void run() {
				 miniutecount ++;
				 Log.i(TAG,"miniutecount " + miniutecount);
			 }
			
		};
		mTimerMiniuteCount.schedule(mTimerTaskMiniuteCount, 0, miniutebase);
		
		int base = KaraokeLib.getSongScore(0);
		
		if(base < 3)
			base = base + 4;
		else if(base < 6)
			base = base - 2;
		else
			base = 4;
		Log.i(TAG," base " + base);
		
		scorebase = scorebase * base;
		
		Log.i(TAG,"scorebase " + scorebase);
		mTimerScoreCount = new Timer();    
		mTimerTaskScoreCount = new TimerTask(){
			
			 @Override
	            public void run() {
				 miniutecount = 0;
				 score100enable = true;
				 Log.i(TAG,"timerscore start");
			 }
			
		};
		mTimerScoreCount.schedule(mTimerTaskScoreCount, 0, scorebase * miniutebase);
		
		
		
	}
	
	public void KaraokeStop() {
		bgPicExit = true;
		downloadExit = true;
	}

	public void KaraokePause() {
		if (FinishKaraokeStartFlag == 2) {
		}
	}

	public void KaraokeResume() {
		if (FinishKaraokeStartFlag == 2) {
			KaraokeLib.InitAudioRecord();
			KaraokeLib.InitAudioTrack();
			KaraokeLib.setEnv(LocalSampleRate, KaraokeLib.monoFlag,
					KaraokeLib.g_bufferSizeOutBytes,
					KaraokeLib.g_bufferSizeInBytes, LocalSampleRateOut);
			
			//AudioManager audioManager = (AudioManager) mcontext.getSystemService(Context.AUDIO_SERVICE);
			//int vol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
			//KaraokeLib.setMute(vol == 0);
		}
	}

	private void initKaraokePath() {
		apkPath = mcontext.getPackageCodePath();
		pm = mcontext.getPackageManager();
      	info2 = pm.getPackageArchiveInfo(apkPath, PackageManager.GET_ACTIVITIES);

		FolderPath = GetRootMountDevice();
		BaseHelper.log(TAG, String.format("Folder Path %s", FolderPath));

		// 拼接新路
		HappyKTVFilePath = "/KARAOKE";
		HappyKTVFilePath = FolderPath + HappyKTVFilePath;
		checkPath(HappyKTVFilePath, false);

		UpdateFilePath = HappyKTVFilePath + UpdateFilePath;
		checkPath(UpdateFilePath, false);

		RecFilePath = HappyKTVFilePath + RecFilePath;
		checkPath(RecFilePath, false);

		String AndoidPath = FolderPath + "/Android";
		checkPath(AndoidPath, true);

		SongFilePath = HappyKTVFilePath + SongFilePath;
		checkPath(SongFilePath, false);

		CfgFilePath = HappyKTVFilePath + CfgFilePath;
		checkPath(CfgFilePath, false);

		BgvFilePath = HappyKTVFilePath + BgvFilePath;
		checkPath(BgvFilePath, false);

		PicFilePath = HappyKTVFilePath + PicFilePath;
		checkPath(PicFilePath, false);

		UserSongPath = HappyKTVFilePath + UserSongPath;
		checkPath(UserSongPath, false);

		NetFilePath = HappyKTVFilePath + NetFilePath;
		checkPath(NetFilePath, false);

		NetSongPath = HappyKTVFilePath + NetSongPath;
		checkPath(NetSongPath, false);
		
		CameraPath = HappyKTVFilePath + CameraPath;
		checkPath(CameraPath, false);
		
		// without sdcard
		if (InternalUserIniPath.equals(FolderPath + "/Android") == false) {
			checkPath(InternalUserIniPath, true);
		}
		
		downloadManager = (DownloadManager) g_context.getSystemService(Context.DOWNLOAD_SERVICE);
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
		mcontext.registerReceiver(mReceiver, intentFilter);
		
	}
	
	 public static void forChannel(File f1,File f2) throws Exception{
	        
	        int length=2097152;
	        FileInputStream in=new FileInputStream(f1);
	        FileOutputStream out=new FileOutputStream(f2);
	        FileChannel inC=in.getChannel();
	        FileChannel outC=out.getChannel();
	        ByteBuffer b=null;
	        while(true){
	            if(inC.position()==inC.size()){
	                inC.close();
	                outC.close();
	                return ;
	            }
	            if((inC.size()-inC.position())<length){
	                length=(int)(inC.size()-inC.position());
	            }else
	                length=2097152;
	            b=ByteBuffer.allocateDirect(length);
	            inC.read(b);
	            b.flip();
	            outC.write(b);
	            outC.force(false);
	        }
	    }
	
	
	private void CPCloudsong(String sourcepath)
	{
		final String file = sourcepath;
		new Thread(new Runnable() {
			public void run() {
				try
				{
					String destpath = KaraokeVGALib.getGLString(3,0);
					Log.i("Youtube","copy file from " + file + "to " + destpath);
					File s = new File(file);
					File d = new File(destpath);
					forChannel(s,d);
					Log.i("Youtube","download complete " + file);
					KaraokeVGALib.setGLString(5, 0, file);
					ControlUARTJavaDelay(MyListener.MSG_ID_YOUTUBE_DOWNLOAD, 1);
				}
				catch(Exception e)
        		{
        			Log.e("Youtube", e.getMessage());
        			KaraokeVGALib.setGLString(5, -1, file);
        		}
				
				downloadprepared = 1;
			}
		}).start();
		
	}
	
	BroadcastReceiver mReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			String action = intent.getAction();  
          if (action.equals(DownloadManager.ACTION_DOWNLOAD_COMPLETE)) {  
            	long completeDownloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            	
            	Log.i("Youtube","download complete " + completeDownloadId);
            	if(DownIDSongIndexMap.containsKey(completeDownloadId) == true)
            	{
            		try
            		{
	            		File f = DownIDSongIndexMap.get(completeDownloadId);
	            		
	            		
	            		
	            		if(f.exists() == true)
	            		{	
	            			
	            			String path = f.getCanonicalPath();
	            			if(path.endsWith(".OKF"))
	            			{
	            				KaraokeVGALib.setGLString(4, 0, f.getCanonicalPath());	
	            				CPCloudsong(f.getCanonicalPath());
	            			}	
	            				
	            			else
	            			{
	            				KaraokeVGALib.setGLString(1, 0, f.getCanonicalPath());
	            				downloadprepared = 1;
	            				ControlUARTJavaDelay(MyListener.MSG_ID_YOUTUBE_DOWNLOAD, 1);
		            			Log.i("Youtube","download complete " + f.getCanonicalPath());
	            			}	
	            				
	            		}
	            		else
	            		{
	            			downloadprepared = 1;
	            			ControlUARTJava(185);
	            			String path = f.getCanonicalPath();
	            			if(path.endsWith(".OKF"))
	            				KaraokeVGALib.setGLString(4, 0, f.getCanonicalPath());	
	            		}	
	            			
            		}
            		catch(Exception e)
            		{
            			
            		}
            		DownIDSongIndexMap.remove(completeDownloadId);
            		Log.i("Youtube","DownIDSongIndexMap.size " + DownIDSongIndexMap.size());
            	}
            } 
		}

		
	};
	
	
	
	private void initKaraokeLanguage() {
		if(mcontext.getString(R.string.language).equals("vi")){
			KaraokeVGALib.setStatus(299, 0, 0);
		} else {
			KaraokeVGALib.setStatus(299, 0, 1);
		}
	}
	
	private void startPicThread() {
		bgPicExit = false;
		new Thread(new Runnable() {
			public void run() {
				while(bgPicExit == false) {
					if(bgPicPath.length() > 0) {
						if(bgfilePaths.size() == 0) {
							File folder = new File(bgPicPath);
							if(folder.canRead() == true && folder.isDirectory() == true) {
								for(File f : folder.listFiles()) {
									if(f.getName().toLowerCase().endsWith(".jpg")
									|| f.getName().toLowerCase().endsWith(".png")
									|| f.getName().toLowerCase().endsWith(".bmp")) {
										bgfilePaths.add(f.getAbsolutePath());
									}
								}
							}
						} else {
							int totalLength = bgfilePaths.size();
							String filePath = bgfilePaths.get(bgfileIndex % totalLength);
							bgfileIndex++;
							KaraokeLib.addCameraPic(filePath);
							KaraokeVGALib.setGLString(2, 2, filePath);
							try {
								Thread.sleep(9000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					} else {
						try {
							Thread.sleep(10000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		}).start();
	}
	static private String CloudDIR = "SMARTK+/SongStrore/";
	private String GetCloudURL(String ID)
	{
		String SongURL;
		if(CloudServerURL.length() == 0)
		{
			SongURL = "";
		}	
			//SongURL = "http://maseco.com.vn/download/Smart%20K+/SMARTK+/" + ID + ".OKF";
		else
			SongURL = CloudServerURL + CloudDIR  + ID + ".OKF";
			//just test
			//SongURL = "http://maseco.com.vn/download/Smart%20K+/SMARTK+/" + ID + ".OKF";
		Log.i("Youtube","SongURL " + SongURL);
		return SongURL;
	}
	static private String ConfigURL = "http://maseco.com.vn/download/3600WTK/config.cfg";
	
	private String FTPURL = "124.158.9.11";
	private String FTPUSER = "orchestra";
	private String FTPPASS = "{qNZdM-E6c9}c-5sU$";
	private int	FTPPort = 21;
	
	public void downloadSong() 
	{ 

		try {
			new Thread(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					boolean newftp = false;//true;
					final String fname  = "Count.txt";
					//if(newftp == false)
					
					/*
					try {
						long size = SFTPGet.DownloadFileSize(FTPURL,"SMARTK+/SongStrore/","8150285.OKF");
						Log.w(TAG,"filesize " + size);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					*/
					{
						final FTPClient ftp = new FTPClient();
						FTPFile[] files = null; 
						final int reply;
						boolean flag = false;
						
						
						final InputStream in;
						final OutputStream out;
						//try{
						//	in = new FileInputStream(new File("/mnt/sda2/KARAOKE/NewCount.txt"));
						//}catch (FileNotFoundException e)
						//	{
						//		e.printStackTrace();
						//		return;
						//	}
						try{
							ftp.connect(FTPURL,FTPPort);
							flag = ftp.login(FTPUSER, FTPPASS);
							if(flag == true)
								Log.w(TAG,"login flag true" );
							else
								Log.w(TAG,"login flag false" );
							reply = ftp.getReplyCode(); 
							if (!FTPReply.isPositiveCompletion(reply)) 
							{ 
								Log.w(TAG,"connect error");
								ftp.disconnect(); 
								return ; 
							}
							ftp.setControlEncoding("UTF-8"); // 中文支持  
							ftp.setFileType(FTPClient.BINARY_FILE_TYPE); 
				            
							flag = ftp.changeWorkingDirectory("SMARTK+/SongStrore");
							if(flag == true)
								Log.w(TAG,"changeWorkingDirectory flag true" );
							else
								Log.w(TAG,"changeWorkingDirectory flag false" );
							ftp.enterLocalPassiveMode();
							
							String[] names = ftp.listNames();
							for(String name : names)
							{
								Log.w(TAG,"name " + name);
							}
							
							in = ftp.retrieveFileStream("8150002.OKF");
							
							File localf = new File(android.os.Environment.getExternalStorageDirectory().getPath() + "/" + "8150002.OKF");
							out = new FileOutputStream(localf);
							int length = 0;
							int total = 0;
							byte[] bytes = new byte[1024];
							
							try
							{
								while((length = in.read(bytes))!= -1)
								{
								out.write(bytes, 0, length);
								total += length;
								Log.i(TAG,"write length " + total);
								
								}	
							}catch(Exception e)
							{
								e.printStackTrace();
							}
							
							out.flush();
							out.close();
							in.close();
							/*flag = ftp.storeFile(fname, in);
							if(flag == true)
								Log.w(TAG,"storeFile flag true" );
							else
								Log.w(TAG,"storeFile flag false" );
						 
							in.close();
							*/
							ftp.logout(); 
							
						}catch (IOException e) 
						{ 
							e.printStackTrace();
							
						}
						finally { 
							if (ftp.isConnected()) { 
								try { 
									ftp.disconnect(); 
								} catch (IOException ioe) { } 
							} 
							} 
						
					
						if(flag == true)
						{
							
							
						}
						
					}	
					

				}
			}).start();
		} catch (Exception e) {
			Log.i(TAG, "e:" + e.getMessage());
			
		}	
		
	}
	
	
	
	
	private void startDownloadTask(){
		downloadExit = false;
		try {
			new Thread(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					while(downloadExit == false)
					{
						if(CloudServerURL.length() == 0)
						{
							
							Log.i("Youtube","Get CloudServerURL");
							String Config = SystemUt.getHTML(ConfigURL);
							String[] info = Config.split("\n");
							String filter;
							if(DLUseHttp == true)
								filter = "SongServerUrl:";
							else
								filter = "CloudUrl:";
							for(int i = 0; i< info.length; i++)
							{
								if(info[i].contains(filter))
								{
									CloudServerURL = info[i].replace(filter, "").trim();
									Log.i("Youtube","Get CloudServerURL " + CloudServerURL);
									break;
								}	
								
							}	
						}
						//Log.i("Youtube","CloudServerURL " + CloudServerURL + "length " + CloudServerURL.length());
						//Log.i("Youtube","getindex " + getindex + "putindex " + putindex);
						String UrlSong;
						DownloadManager.Query query = null;
						Cursor cursor = null;
						long downloadedBytes = 0;
						long totalBytes = 0;
						long status = 0;
						
						{
							
							if(getindex < putindex && downloadprepared == 1)
							{
								downloadprepared = 0;
								String VID = aDownload[0][getindex % downloadlimit];
								File f = new File(aDownload[1][getindex % downloadlimit]);
								ControlUARTJava(181,aDownload[1][getindex % downloadlimit]);
								Log.i("Youtube","VID " + VID);
								if(VID.length() == 7 && VID.startsWith("81"))
								{
									UrlSong = GetCloudURL(VID);
								}
								else
									UrlSong = mYoutubeService.GetYoutubeUrl(VID);
								
								if(UrlSong != "")
								{
									if(VID.length() == 7 && VID.startsWith("81") && DLUseHttp == false)
									{
										progresstype = 1;
										String src = VID + ".OKF";
										//String dir = "/mnt/sda4/KARAOKE/SONG/" + VID.substring(0, 4);
										String dst = aDownload[1][getindex % downloadlimit];//dir + "/" + src;
										//File file = new File(dir);
										//if(file.exists() == false)
										//{
										//	file.mkdir();
											
										//}
										try {
											int index = 0;
											index = Integer.parseInt(VID);
											KaraokeVGALib.setGLString(6, index, "");
											
											//long ret = SFTPGet.DownloadFile(CloudServerURL,CloudDIR,src,dst);
											String fsize = KaraokeVGALib.getGLString(5, index);
											Log.i(TAG,"fsize " + fsize);
											int size = Integer.parseInt(fsize);
											/*
											FtpUtil FTP = new FtpUtil(size);
											int ret = FTP.downloadFtpFile(CloudServerURL, FTPUSER, FTPPASS, FTPPort, CloudDIR, dst,src);
											if(ret > 0)
											{
												File dstfile = new File(dst);
												if(dstfile.exists() == true && dstfile.length() == ret)
												{
													KaraokeVGALib.setGLString(4, 0, dst);
													//KaraokeLib.setGLString(5, 0, dst);
													//ControlUARTJavaDelay(MyListener.MSG_ID_YOUTUBE_DOWNLOAD, 1);
													CPCloudsong(dst);
												}
												else
												{
													ControlUARTJava(185);
													KaraokeVGALib.setGLString(4, 0, dst);
													downloadprepared = 1;
												}
												
											}	
											else
											{
												ControlUARTJava(185);
												KaraokeVGALib.setGLString(4, 0, dst);
												downloadprepared = 1;
												
											}	
											*/
											FtpUtil.fileSize = size;
											FtpUtil.downloadFtpFile(CloudServerURL, FTPUSER, FTPPASS, FTPPort, CloudDIR, dst,src);
											
										} catch (Exception e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											downloadprepared = 1;
										}
										
									}
									else
									{
										downloadId = downloadFile(UrlSong, f);
										if(VID.length() == 7 && VID.startsWith("81"))
										{
											//KaraokeVGALib.setGLString(7, -1, "");
											//KaraokeVGALib.setGLString(6, VID., "");
											progresstype = 1;	
											int index = 0;
											try
											{
												index = Integer.parseInt(VID);
												KaraokeVGALib.setGLString(6, index, "");
												
											}
											catch(Exception e)
											{
												Log.e("Youtube", "err:" + e.getMessage());
											}
											
										}
										else
										{
											progresstype = 0;
										}
										
									}	
									
										
								getindex ++;
									
								}
								else
								{
									downloadprepared = 1;
									Log.e("Youtube","not found");
									
									/*
									if(VID.length() == 7 && VID.startsWith("81"))
									{
										if(servernotfound == false)
										{
											KaraokeVGALib.setGLString(4, 0, aDownload[1][getindex % 10]);
											ControlUARTJava(194);
											
										}	

									}	*/
								}	
							}
							else
							{
								if(downloadId != 0)
								{
									Log.i("Youtube","downloadId " + downloadId);
									query = new DownloadManager.Query().setFilterById(downloadId); 
								
									try {  
									    cursor = downloadManager.query(query);  
									    if (cursor != null && cursor.moveToFirst()) {  
									        downloadedBytes = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));  
									        totalBytes = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));  
									        status = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
									        Log.i("Youtube","downloadedBytes " + downloadedBytes + " totalBytes" + totalBytes + " status" + status);
									        
									        	Log.i("Youtube","laststatus " + laststatus + " status " + status);
									        	if(status == DownloadManager.STATUS_RUNNING)
									        	{
									        		
									        		if(laststatus != status)
									        			//KaraokeVGA.mProgrressBar.setVisibility(View.VISIBLE);
									        			ControlUARTJava(183);
									        		//KaraokeVGA.mProgrressBar.setMax((int)totalBytes);
									        		//ControlUARTJava(184,String.valueOf(totalBytes));
									        		//KaraokeVGA.mProgrressBar.setProgress((int)downloadedBytes);
									        		if(totalBytes > 0)
									        		{	
									        			long progress = downloadedBytes * 100 / totalBytes;
									        			ControlUARTJava(184,String.valueOf(progress));
									        		}
									        		laststatus = status;
									        	}	
									        	else if(status == DownloadManager.STATUS_FAILED)
									        	{
									        		//if(laststatus != status)
									        		//	ControlUARTJava(185);
									        		laststatus = 0;
									        	}
									        	else if(status == DownloadManager.STATUS_SUCCESSFUL)
									        	{
									        		laststatus = 0;
									        		
									        	}	
									        	else
									        		laststatus = status;
									     
									        
									    }  
									} finally {  
									    if (cursor != null) {  
									        cursor.close();  
									    }  
									}  
								}
								try {
									Thread.sleep(5000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								
							}	
							
						} 
						
						
					}
					
					
				}
			}).start();
		} catch (Exception e) {
			Log.e("Youtube", "e:" + e.getMessage());
			downloadprepared = 1;
		}
		
	}
	
	public static void setSearchinvisiable()
	{
		//mYTSearch.setVisibility(View.GONE);
		//ControlUARTJava(205);
		m_myControlUARTSnd(0xcd0000);
	}
	
	private void startWifiRender() {
    	mWifiUtil = new WifiUtil();
    	
    	 //timer for set wifi level
    	wifiLevelTimer = new Timer();    
    	wifiLevelTimerTask = new TimerTask() {    
            @Override
            public void run() {  
        		if(mWifiUtil.getWifiApState(wifiManager) == mWifiUtil.WIFI_AP_STATE_ENABLED) {
        			WifiConfiguration wifiAp = wifiManager.getWifiApConfiguration();
        			KaraokeLib.setGLString(1, -1, wifiAp.SSID);
        			KaraokeLib.setGLString(10, 0, "192.168.43.1");
        		} else {
	            	if (wifiManager.isWifiEnabled()) {
	            		WifiInfo coninfo = wifiManager.getConnectionInfo();
	            		if(coninfo.getSSID() != null && coninfo.getSSID() != "0x" && coninfo.getRssi() > -1000) {
	            			KaraokeLib.setGLString(1, coninfo.getRssi(), coninfo.getSSID());
	            			KaraokeLib.setGLString(10, 0, convertIPAddress(coninfo.getIpAddress()));
	            		} else {
	            			KaraokeLib.setGLString(1, 0, "");
	            		}
	        		} else {
	            		KaraokeLib.setGLString(1, 0, "");
	            	}
        		}
            }    
        };
        wifiLevelTimer.scheduleAtFixedRate(wifiLevelTimerTask, 3000, 3000);
	}
	
	private final DialogInterface.OnDismissListener mOnDismissListener = new DialogInterface.OnDismissListener() {
		@Override
        public void onDismiss(DialogInterface dialog) {
			if (dialog == mKaraokeHDMI) {
				Log.i(TAG, "Presentation was dismissed.");
				mKaraokeHDMI = null;
            }
        }
    };
    
	void StartKaraokePresentation() {
	    DisplayManager mDisplayManager = (DisplayManager)mcontext.getSystemService(Context.DISPLAY_SERVICE);
	    Display[]  mDisplays = mDisplayManager.getDisplays();
        Display presentationDisplay = mDisplays[1];
        
        if (mKaraokeHDMI != null && mKaraokeHDMI.getDisplay() != presentationDisplay) {
        	mKaraokeHDMI.dismiss();
        	mKaraokeHDMI = null;
        }

        if (mKaraokeHDMI == null && presentationDisplay != null) {
        	mKaraokeHDMI = new KaraokeHDMI(mcontext, presentationDisplay);
        	mKaraokeHDMI.setOnDismissListener(mOnDismissListener);
            try {
            	mKaraokeHDMI.show();
            } catch (WindowManager.InvalidDisplayException ex) {
            	mKaraokeHDMI = null;
            }
        }
	}
	
	private Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			try {
				switch (msg.what) {
				case 1:
					if (MultakConnect.isNetworkAvailable(mcontext) == true) {
						KaraokeLib.setNetworkState(1);
						KaraokeVGALib.setStatus(1, 0, 0);
					} else {
						KaraokeLib.setNetworkState(0);
						KaraokeVGALib.setStatus(0, 0, 0);
					}
					
					ResFilePath = HappyKTVFilePath + ResFilePath;
					BaseHelper.log(TAG, String.format("Check Res %s", ResFilePath));
					File ff = new File(ResFilePath + "/" + info2.versionName + ".txt");
					if (ff.canRead() == false) {
						BaseHelper.log(TAG, "Release Res");
						File zipFile = new File(apkPath);
						BaseHelper.log(TAG, "Unzip SkyKTV resources");
						try {
							ZipUtils.unZipSelectedFile(zipFile, HappyKTVFilePath, "assets");
						} catch (ZipException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						File fa = new File(HappyKTVFilePath + "/assets");
						File fb = new File(ResFilePath);
						if (fb.canRead() == true) {
							MUtils.deleteDir(fb);
						}
						if (fa.canRead() == true) {
							fa.renameTo(fb);
						}
						File ff2 = new File(ResFilePath + "/" + info2.versionName + ".txt");
						try {
							ff2.createNewFile();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					KaraokeStart();
					mLoadingView.setVisibility(View.GONE);
					//ControlUARTJavaDelay(100, 10000);
					break;
					
				case 4:
					if(isExit == 0 ) {
                    	isExit = 1;
                    	Toast.makeText(mcontext, R.string.slipToExit, Toast.LENGTH_SHORT).show();
                    	mHandler.postDelayed(new Runnable() {
                    		@Override
							public void run() {
								// TODO Auto-generated method stub
                                isExit = 0;
							}
						}, 2000);
                    } else {
						FinishActivity();           
                    }
					break;
					
				case 27:
					KaraokeHDMI.mCameraPicture.CameraPicture_Finish();
					bgPicPath = "";
					KaraokeLib.setGLString(2, 0, "");
					KaraokeVGALib.setGLString(2, 0, "");
					break;

				case 28:
					bgfileIndex = 0;
					bgfilePaths.clear();
					if(KaraokeHDMI.mCameraPicture.CameraPicture_Init(KaraokeHDMI.mPicSurfaceView, CameraPath, 1280, 720) > 0) {
						bgPicPath = "";
						KaraokeLib.setGLString(2, 1, "");
						Log.i("VideoView", "mImageView start 1");
					} else {
						KaraokeLib.addCameraPic("");
						bgPicPath = KaraokeLib.getWebUrl(1);						
						KaraokeLib.setGLString(2, 2, bgPicPath);
						Log.i("VideoView", "mImageView start 2");
					}
					KaraokeVGALib.setGLString(2, 1, "");
					break;

				case 30: // record start, upload tell who to who which song
					KaraokeLib.MediaRecordStart();
					break;
					
				case 31: // record end
					KaraokeLib.MediaRecordEnd();
					break;
					
				case 38: // 声音测试超时
					LocalSampleRate = 160;
					KaraokeLib.setEnv(LocalSampleRate, KaraokeLib.monoFlag,
							KaraokeLib.g_bufferSizeOutBytes,
							KaraokeLib.g_bufferSizeInBytes, LocalSampleRateOut);
					SaveLocalSingInfo();
					break;
					
				case 39:
					KaraokeLib.StopAudioRecord();
					KaraokeLib.StopAudioTrack();
					break;
					
				case 40:
					KaraokeLib.InitAudioTrack();
					KaraokeLib.InitAudioRecord();
					KaraokeLib.setEnv(LocalSampleRate, KaraokeLib.monoFlag,
							KaraokeLib.g_bufferSizeOutBytes,
							KaraokeLib.g_bufferSizeInBytes, LocalSampleRateOut);
					break;
				
				case 50:
					FrameLayout.LayoutParams layout = (android.widget.FrameLayout.LayoutParams) KaraokeVGA.mVideoSurfaceViewEx.getLayoutParams();
					if(msg.arg1 == 1) {
						layout.width = (int) mcontext.getResources().getDimension(R.dimen.px1280);
						layout.height = (int) mcontext.getResources().getDimension(R.dimen.px720);
						layout.leftMargin = 0;
						layout.topMargin = 0;
						mGridView.setVisibility(View.GONE);
						
						mYTSearch.setVisibility(View.GONE);
						if(progressbarshown == 1)
							KaraokeVGA.mProgrressBar.setVisibility(View.INVISIBLE);
					} else {
						layout.width = (int) mcontext.getResources().getDimension(R.dimen.px446);
						layout.height = (int) mcontext.getResources().getDimension(R.dimen.px233);
						layout.leftMargin = (int) mcontext.getResources().getDimension(R.dimen.px814);
						layout.topMargin = (int) mcontext.getResources().getDimension(R.dimen.px20);
						if(progressbarshown == 1 && progresstype == 0)
							KaraokeVGA.mProgrressBar.setVisibility(View.VISIBLE);
					}
					KaraokeVGA.mVideoSurfaceViewEx.setLayoutParams(layout);
					break;
					
				case 60://wifi hotspot
					if(wifiManager.getWifiState() != 1) {
                		wifiManager.setWifiEnabled(false);
					}
					if(mWifiUtil.getWifiApState(wifiManager) != 11) {
						mWifiUtil.closeWifiAp(wifiManager);               		
					}
					ControlUARTJavaDelay(64, 2000);
					
					break;
				case 64:
					mHotSpot = new Timer();
					mHotSpotTask = new TimerTask() {
                        public void run() {
                        	if(wifiManager.getWifiState() == 1 && mWifiUtil.getWifiApState(wifiManager) == 11) {
                        		mHotSpot.cancel();
                        		if(mWifiUtil.getWifiApState(wifiManager) != 13) {
                        			String HotSpotName,HotSpotPassword;
                        			HotSpotName = KaraokeLib.getHotSpotName();
                        			HotSpotPassword = KaraokeLib.getHotSpotPassword();
                        			if(HotSpotName.equals("")) {
                        				HotSpotName = "WIFIAP";
                        				HotSpotPassword = "88888888";
                        			}
									mWifiUtil.stratWifiAp(wifiManager, HotSpotName, HotSpotPassword);
									ControlUARTJava(62);
                        		}
                        	}
						}
                    };
                    mHotSpot.schedule(mHotSpotTask, 2000, 2000);
					break;
				case 61:
					if(wifiManager.getWifiState() != 1) {
                		//wifiManager.setWifiEnabled(false);
						ControlUARTJava(62);
						break;            		
					}
					if(mWifiUtil.getWifiApState(wifiManager) != 11) {
						mWifiUtil.closeWifiAp(wifiManager); 
					}
					break;
					
				case 62:
					if(wifiManager.isWifiEnabled()) {
						WifiInfo coninfo = wifiManager.getConnectionInfo();
	            		if(coninfo.getSSID() != null && coninfo.getSSID() != "0x" && coninfo.getRssi() > -1000) {
							StartMTVServer(convertIPAddress(coninfo.getIpAddress()));
							break;
	            		}
					} else if(mWifiUtil.getWifiApState(wifiManager) == mWifiUtil.WIFI_AP_STATE_ENABLED) {
						mHandler.postDelayed(new Runnable() {
							public void run() {
								StartMTVServer("192.168.43.1");
							}
						}, 2000);
						ControlUARTJavaDelay(63,2000);
						break;
					}
					ControlUARTJavaDelay(62, 2000);
					break;
				case 63:
					//if(wifiManager.getWifiState()!= 1)
                	//{
					//	break;
					//}
					HotPotCheck = new Timer();
					HotPotCheckTask = new TimerTask(){
						public void run(){
							int APstatus = mWifiUtil.getWifiApState(wifiManager);
							Log.i("APcheck","APstatus = " + APstatus);
							if(APstatus != 13 || wifiManager.isWifiEnabled())
							{
								
								
								Log.i("APcheck","AP reset , status = " + APstatus);
								Log.i("APcheck","WIFIStatus = " + wifiManager.getWifiState());
								
								wifiManager.setWifiEnabled(false);
								mWifiUtil.closeWifiAp(wifiManager);
								ControlUARTJavaDelay(65, 2000);
								
							}
						}
						
						
					};
					HotPotCheck.schedule(HotPotCheckTask,20000,20000);
					break;
				case 65:
					String HotSpotName,HotSpotPassword;
        			HotSpotName = KaraokeLib.getHotSpotName();
        			HotSpotPassword = KaraokeLib.getHotSpotPassword();
        			if(HotSpotName.equals(""))
        			{
        				HotSpotName = "WIFIAP";
        				HotSpotPassword = "88888888";
        			}
        			mWifiUtil.stratWifiAp(wifiManager, HotSpotName, HotSpotPassword);
					break;
				case 100:
					
					//MainActivity.ExoPlay("aa");
					break;
				case 153:
				case 152:
					if (MultakConnect.isNetworkAvailable(mcontext)) {
						KaraokeLib.setNetworkState(1);
						KaraokeVGALib.setStatus(1, 0, 0);
					} else {
						KaraokeLib.setNetworkState(0);
						KaraokeVGALib.setStatus(0, 0, 0);
					}
					break;
				case MyListener.MSG_ID_YOUTUBE_DOWNLOAD:
					/*String info = (String)msg.obj;
					String[] syd =  info.split("#YD#");
					if(syd.length == 2)
					{
						String VID = syd[0];
						String SongName = syd[1];
						
						SongName = URLEncoder.encode(SongName, "UTF-8");
						SongName = SongName.replace("%20", " ");
						
						String UrlSong = mYoutubeService.calculateYouTubeUrl(VID);
						File f = new File("/mnt/sda4/" + SongName + ".mp4");
						if(f.exists() == false)
						{
							//downloadFileSD(UrlSong, f);
							Log.i("Youtube","Start download file " + "/mnt/sda4/" + SongName + ".mp4");
						}
					}*/	
					//KaraokeVGA.mProgrressBar.setVisibility(View.INVISIBLE);
					mProgress.setVisibility(View.GONE);
					mWaring.setVisibility(View.GONE);
					progressbarshown = 0;
					if(progresstype == 1)
					{
						KaraokeVGALib.setGLString(7, -1, "");
						KaraokeVGALib.setGLString(6, 0, "");
						KaraokeVGALib.setGLString(8, 0, "");
					}	
						
					Toast.makeText(mcontext, "Download Complete!", Toast.LENGTH_LONG).show();
					break;
				case 169:
					mKaraokeVGA.startPreview();
					break;
					
				case 170:
					mKaraokeVGA.stopPreview();
					break;
				case 180:
					StatFs sf = new StatFs("/mnt/sdcard");
					long block = sf.getAvailableBlocks();
					long blocksize = sf.getBlockSize();
					long freesize = (block * blocksize)/(1024*1024);
					
					Log.i("Youtube","Availablesize MB " + freesize);
					
					StatFs sf1 = new StatFs("/mnt/sda4");
					long block1 = sf1.getAvailableBlocks();
					long blocksize1 = sf1.getBlockSize();
					long freesize1 = (block1 * blocksize1)/(1024*1024);
					
					Log.i("Youtube","11 Availablesize MB " + freesize1);
					HDDLowCap = false;
					if(freesize > 300 && freesize1 > 300)
					{
						/*if(DownIDSongIndexMap.size() >= 3)
						{
							Log.w("Youtube","Download is busy");
							Toast.makeText(mcontext, "Download is busy", Toast.LENGTH_LONG).show();
						}
						else*/
						if(freesize1 < (100 * 1024))
							HDDLowCap = true;
						
						{
							String VIDEOID = KaraokeVGALib.getGLString(1,0);
							Log.i("Youtube","VIDOEID " + VIDEOID);
							String VIDEONAME = KaraokeVGALib.getGLString(2,0);
							Log.i("Youtube","VIDOENAME " + VIDEONAME);
							
							
							
							
							
						//	String SongName = URLEncoder.encode(VIDEONAME, "UTF-8");
						//	SongName = SongName.replace("%20", " ");
							
							Log.i("Youtube","downloadprepared " + downloadprepared);
							Log.i("Youtube","DownIDSongIndexMap.size " + DownIDSongIndexMap.size());
							//if(downloadprepared == 0 || DownIDSongIndexMap.size() >= 1)
							if(putindex >= downloadlimit + getindex)
							{
								Toast.makeText(mcontext, "Download is busy! Please Wait !", Toast.LENGTH_LONG).show();
			
							}
								
							else
								prepareDownload(VIDEOID,VIDEONAME);
							
						}
					}
					else
					{
						Log.w("Youtube", "Storage lower than 300M");
						Toast.makeText(mcontext, "Not Enougth Space!", Toast.LENGTH_LONG).show();
						HDDLowCap = true;
					}	
					
					break;
				case 181:
					String filename = (String)msg.obj;
					Toast.makeText(mcontext, "Start Download" + filename, Toast.LENGTH_LONG).show();
					break;
				case 182:
					 
					
					break;
				case 183:
					
					if(progressbarshown != 1)
					{
						if(progresstype == 0)
						{	
						//KaraokeVGA.mProgrressBar.setProgress(0);
						//KaraokeVGA.mProgrressBar.setVisibility(View.VISIBLE);
						//Log.i("Youtube","mProgrressBar set visible");
							if(mProgress != null)
							{
								mProgress.setVisibility(View.VISIBLE);
								mWaring.setVisibility(View.GONE);
							}	
						}
						else
						{
							KaraokeVGALib.setGLString(7, 0, "");
							
						}	
						progressbarshown = 1;
					}
					Log.i("Youtube","progressbarshown " +  progressbarshown + " progresstype " + progresstype);
					break;
				case 185:
					
				//	int max = Integer.parseInt((String)msg.obj);
				//	KaraokeVGA.mProgrressBar.setMax(max);
					Log.i("Youtube","Downlaod Fail");
					
					Toast.makeText(mcontext, "Download fail!", Toast.LENGTH_LONG).show();
					//KaraokeVGA.mProgrressBar.setVisibility(View.INVISIBLE);
					mProgress.setVisibility(View.GONE);
					mWaring.setVisibility(View.GONE);
					if(progresstype == 1)
					{
						KaraokeVGALib.setGLString(7, -1, "");
						KaraokeVGALib.setGLString(6, 0, "");
					}	
						
					progressbarshown = 0;
					break;
				case 184:
					
					int cur = Integer.parseInt((String)msg.obj);
					Log.i("Youtube", "Progress " + cur + " progresstype " + progresstype + " progressbarshown " + progressbarshown);
					if(progresstype == 0 && progressbarshown == 1)
					{	
						//KaraokeVGA.mProgrressBar.setProgress(cur);
						//KaraokeVGA.mProgrressBar.setVisibility(View.VISIBLE);
						//Log.i("Youtube","mProgrressBar setProgress");
						mProgress.setVisibility(View.VISIBLE);
						mProgress.setText("Download Progress " + cur + "%");
						if(HDDLowCap == true)
							mWaring.setVisibility(View.VISIBLE);
						else
							mWaring.setVisibility(View.GONE);
					}
						else
					{
						int tmpprogerss = cur/10;
						if(tmpprogerss != lastprogress)
						{
							KaraokeVGALib.setGLString(7, tmpprogerss, "");
						}
						lastprogress = tmpprogerss ;
					}	
					
					
					break;
				case 186:
					//if(progressbarshown == 1)
					//	KaraokeVGA.mProgrressBar.setVisibility(View.INVISIBLE);
					break;
				case 187:
					//if(progressbarshown == 1 && progresstype == 0)
					//	KaraokeVGA.mProgrressBar.setVisibility(View.VISIBLE);
					break;
				case 188:
					
					Toast.makeText(mcontext, "Not Enough Space!", Toast.LENGTH_LONG).show();
					break;
				case 189:
					Toast.makeText(mcontext, "Song DB upate!", Toast.LENGTH_LONG).show();
					break;
				case 190:
					Toast.makeText(mcontext, "Start Update DataBase!", Toast.LENGTH_LONG).show();
					break;
				case 191:
					if(downloadId != 0)
					{
						downloadManager.remove(downloadId);
						
					}	
					break;
				case 192:
					Toast.makeText(mcontext, "Song Fixing!", Toast.LENGTH_LONG).show();
					break;
				case 193:
					Toast.makeText(mcontext, "Start Fix!", Toast.LENGTH_LONG).show();
					break;
				case 194:
					Toast.makeText(mcontext, "Server not found!", Toast.LENGTH_LONG).show();
					break;
				case 195:
					ControlUARTJava(185);
					KaraokeVGALib.setGLString(4, 0, (String)msg.obj);
					downloadprepared = 1;
					break;
				case 196:
					File dstfile = new File((String)msg.obj);
					if(dstfile.exists() == true)
					{
						Log.i(TAG,"dstfile filesize " + dstfile.length());
					}
					if(dstfile.exists() == true && dstfile.length() == FtpUtil.transize)
					{
						KaraokeVGALib.setGLString(4, 0, (String)msg.obj);
						//KaraokeLib.setGLString(5, 0, dst);
						//ControlUARTJavaDelay(MyListener.MSG_ID_YOUTUBE_DOWNLOAD, 1);
						CPCloudsong((String)msg.obj);
					}
					else
					{
						ControlUARTJava(185);
						KaraokeVGALib.setGLString(4, 0, (String)msg.obj);
						downloadprepared = 1;
					}
					break;
				case 198:
					Toast.makeText(mcontext, "Download is busy ,Please wait !", Toast.LENGTH_LONG).show();	
				case 200:
					KaraokeHDMI.mCameraPicture.CameraPicture_Init(KaraokeHDMI.mPicSurfaceView, CameraPath, 1280, 720);
					BaseHelper.log(TAG, "Camera Start Pic");
					break;
					
				case 201:
					KaraokeHDMI.mCameraPicture.CameraPicture_Finish();
					break;
					
				case 202:
					KaraokeLib.getWebUrl(-5);
					BaseHelper.log(TAG, "Camera Start Pic 202");
					break;
					
				case 203:
					mGridView.setVisibility(View.GONE);
					mYTSearch.setVisibility(View.GONE);
					break;
				case 204:
					mGridView.setVisibility(View.VISIBLE);
					Log.i(TAG,"YTSearched " + YTSearched);
					if(YTSearched == false)
						mYTSearch.setVisibility(View.VISIBLE);
					else
						mYTSearch.setVisibility(View.GONE);
					break;
				case 205:
					mYTSearch.setVisibility(View.GONE);
					break;
	            case 210:
	            	KaraokeLib.setGLString(21, getscore(), "");
	            	break;	
				case 234: 
					ArrayList<String> mChannels = new ArrayList<String>();
					mChannels.clear();
			    	mChannels.add ("AUDIO_CODEC");
			    	MainActivity.mAudioManager.setAudioDeviceActive(mChannels, AudioManager.AUDIO_OUTPUT_ACTIVE);  
					break;
					
				case 240:
					AppUtils mAppUtils = new AppUtils(mcontext);
					mAppUtils.OpenApk("com.softwinner.ddrtester","",0);
					break;
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	};
	
	private long downloadFile(String fileUrl, File file) {            //创建下载任务
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(fileUrl));
        request.setAllowedOverRoaming(false);
        //漫游网络是否可以下载
        //设置文件类型，可以在下载结束后自动打开该文件
        //MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        //String mimeString = mimeTypeMap.getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(versionUrl));
        //request.setMimeType(mimeString);
        //在通知栏中显示，默认就是显示的
        //request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
        //request.setVisibleInDownloadsUi(true);
        //request.setShowRunningNotification(false);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_HIDDEN);
        request.setVisibleInDownloadsUi(false);
        //sdcard的目录下的download文件夹，必须设置
        request.setDestinationUri(Uri.fromFile(file));
        //request.setDestinationInExternalFilesDir(),也可以自己制定下载路径
        //将下载请求加入下载队列
        //加入下载队列后会给该任务返回一个long型的id，
        //通过该id可以取消任务，重启任务等等，看上面源码中框起来的方法
        
        try
        {
	        long ID = downloadManager.enqueue(request);
	        DownIDSongIndexMap.put(ID, file);
	        return ID; 
        }
        catch(Exception e)
        {
        	downloadprepared = 1;
        	e.printStackTrace();
        }
        return 0; 
    }
	
	
	private boolean prepareDownload(String VID,String FName)
	{
		boolean ret = false;
		//final String ID = VID;
		File f;
		if(FName.length() == 7 && FName.startsWith("81"))
		{
			
			//if(DLUseHttp == false)
			//	f = new File("/mnt/sda4/KARAOKE/SONG/" + FName.substring(0, 3) + "/" + FName + ".OKF");
			//else
				f = new File(android.os.Environment.getExternalStorageDirectory().getPath() + "/" + FName + ".OKF");
		}	
		else
			f = new File(android.os.Environment.getExternalStorageDirectory().getPath() + "/" + FName + ".mp4");
		//downloadprepared = 0;
		
		//if(f.exists() == false)
		{
			
			if(f.exists())
			{
				f.delete();
				Log.i("Youtube","already exist , delete first");
			}
			//DownTaskMap.put(VID, FName);
			
			//Toast.makeText(mcontext, "Start Download!", Toast.LENGTH_LONG).show();	
			Log.i("Youtube","download file name " + android.os.Environment.getExternalStorageDirectory().getPath() + "/" + FName + ".mp4" );
			
			if(FName.length() == 7 && FName.startsWith("81"))
			{
				if(CloudServerURL.length() == 0)
				{
				
						String path = android.os.Environment.getExternalStorageDirectory().getPath() + "/" + FName + ".OKF";
						//if(DLUseHttp == false)
						//	path = "/mnt/sda4/KARAOKE/SONG/" + FName.substring(0, 3) + "/" + FName + ".OKF";
					Log.i("Youtube","server not found " + path);
					KaraokeVGALib.setGLString(4, 0, path);
					KaraokeVGALib.setGLString(7, -1, "");
					KaraokeVGALib.setGLString(6, 0, "");
					ControlUARTJava(194);
					
					return false;
				}	
				
			}
			aDownload[0][putindex % downloadlimit] = VID;
			if(VID.length() == 7 && VID.startsWith("81"))
				aDownload[1][putindex % downloadlimit] = android.os.Environment.getExternalStorageDirectory().getPath() + "/" + FName + ".OKF";
			else	
				aDownload[1][putindex % downloadlimit] = android.os.Environment.getExternalStorageDirectory().getPath() + "/" + FName + ".mp4";
			putindex ++;
			
		}
	/*	else
		{
			Toast.makeText(mcontext, "File already downloaded!", Toast.LENGTH_LONG).show();
			//downloadprepared = 1;
		}
		*/
		return ret;
	}
	public static String GetMountDevice() { // use to get usb path
		String FolderPath = "";
		BaseHelper.log(TAG, "getDevice come in");
		File[] files2 = new File("/mnt").listFiles();
		System.out.printf("GetMountDevice start \n");
		int type = 0;

		KaraokeLib.initMultakDevice();
		KaraokeVGALib.initMultakDevice();
		UsbDeviceNum = 0;
		for (File file2 : files2) {
			System.out.printf("**** GetMountDevice  %s \n", file2.getPath());

			if (file2.isDirectory() && file2.getPath().startsWith("/mnt")) {
				if (file2 != null) {
					if ((file2.canRead() == true) && (file2.canWrite() == true)) {
						System.out.printf("canWrite and canRead %s \n", file2.getPath());
						if (file2.getPath().startsWith("/mnt/sda1")) {
							type = 1;
						} else if (file2.getPath().startsWith("/mnt/sda2")) {
							type = 3;
						} else if (file2.getPath().startsWith("/mnt/sda3")) {
							type = 4;
						} else {
							type = 0;
						}

						if (type != 0) {
							if (type == 3) {
								String aa;
								int index, index1;
								int haveSubDevice = 0;
								String minor = null;
								String major = null;

								File[] filesUsb = new File(file2.getPath()).listFiles();
								for (File fileUsb : filesUsb) {
									aa = fileUsb.getPath();
									if (aa.endsWith("in.img") || aa.endsWith("out.img") || aa.endsWith("multak.img")) {
										haveSubDevice = -1; // net need to add
										break;
									}

									System.out.printf("**** usb list aa = %s\n", aa);
									haveSubDevice = 1;

									index = aa.lastIndexOf("_");
									index1 = aa.lastIndexOf('/');

									System.out.printf("**** usb list aa = %s, index1 = %d\n", aa, index1);

									if (index != -1 && index != (aa.length() - 1)) {
										major = aa.substring(index1 + 1, index);
										minor = aa.substring(index + 1, aa.length());
										try {
											Integer.valueOf(major);
											Integer.valueOf(minor);
										} catch (NumberFormatException e) {
											/* 如果该字符串不能被解析为数字,则退出 */
											haveSubDevice = 0;
											break;
										}
									} else {
										haveSubDevice = 0;
										break;
									}
								}

								if (haveSubDevice == -1) {
									continue;
								} else if (haveSubDevice == 1) {
									System.out.printf("haveSubDevice == 1\n");

									for (File fileUsb : filesUsb) {
										System.out.printf("add subdevice %s\n", fileUsb);

										if((fileUsb.canRead() == true) && (fileUsb.canWrite() == true)){
											String rootPath = fileUsb.getPath() + "/KARAOKE";
											checkPath(rootPath, false);
	
											String RecPath = rootPath + "/REC";
											checkPath(RecPath, false);
	
											String SongPath = rootPath + "/SONG";
											checkPath(SongPath, false);
	
											File ktvfile3 = new File(SongPath);
											if (ktvfile3.canRead() == true) {
												String SubSongPath;
												for (int i = 0; i < 100; i++) {
													if (i < 10) {
														SubSongPath = SongPath + "/0";
													} else {
														SubSongPath = SongPath + "/";
													}
													SubSongPath += Integer.toString(i);
													checkPath(SubSongPath, false);
												}
												String SongPathTemp = rootPath + "/SONG/.Media";
												checkPath(SongPathTemp, false);
											}
											String CfgPath = rootPath + "/CFG";
											checkPath(CfgPath, false);
	
											String BgvPath = rootPath + "/BGV";
											checkPath(BgvPath, false);
	
											String PicPath = rootPath + "/PIC";
											checkPath(PicPath, false);
	
											String UserSongPath = rootPath + "/USER";
											checkPath(UserSongPath, false);
	
											String NetPath = rootPath + "/NET";
											checkPath(NetPath, false);
	
											String NetSongPath = rootPath + "/NET/SONG";
											checkPath(NetSongPath, false);
	
											rootPath += "/";
											System.out.printf("addMultakDevice : rootPath = %s\n", rootPath);
											KaraokeLib.addMultakDevice(type, rootPath);
				            				KaraokeVGALib.addMultakDevice(type, rootPath);
										}
									}
									continue;
								}
							}
							String rootPath = file2.getPath() + "/KARAOKE";
							checkPath(rootPath, false);

							String RecPath = rootPath + "/REC";
							checkPath(RecPath, false);

							String SongPath = rootPath + "/SONG";
							checkPath(SongPath, false);

							File ktvfile3 = new File(SongPath);
							if (ktvfile3.canRead() == true) {
								String SubSongPath;
								for (int i = 0; i < 100; i++) {
									if (i < 10) {
										SubSongPath = SongPath + "/0";
									} else {
										SubSongPath = SongPath + "/";
									}
									SubSongPath += Integer.toString(i);
									checkPath(SubSongPath, false);
								}
							}
							String CfgPath = rootPath + "/CFG";
							checkPath(CfgPath, false);

							String BgvPath = rootPath + "/BGV";
							checkPath(BgvPath, false);

							String PicPath = rootPath + "/PIC";
							checkPath(PicPath, false);

							String UserSongPath = rootPath + "/USER";
							checkPath(UserSongPath, false);

							String NetPath = rootPath + "/NET";
							checkPath(NetPath, false);

							String NetSongPath = rootPath + "/NET/SONG";
							checkPath(NetSongPath, false);

							rootPath += "/";
							System.out.printf("addMultakDevice : rootPath = %s\n", rootPath);
							KaraokeLib.addMultakDevice(type, rootPath);
            				KaraokeVGALib.addMultakDevice(type, rootPath);
							if (!rootPath.startsWith("/mnt/sda")) {// zhangwc
								UsbDeviceNum++;
							}
						}
					}
				}
			}
		}
		KaraokeLib.restartMultakDevice();
		KaraokeVGALib.restartMultakDevice();

		System.out.printf("getExternalStorageDirectory  %s \n", android.os.Environment.getExternalStorageDirectory().getPath());

		String state = android.os.Environment.getExternalStorageState();
		// 判断SdCard是否存在并且是可用的
		if (android.os.Environment.MEDIA_MOUNTED.equals(state)) {
			if (android.os.Environment.getExternalStorageDirectory().canWrite()) {
				return android.os.Environment.getExternalStorageDirectory().getPath();
			}
		}

		FolderPath = "/data/data/com.multak.MK8507MOA";
		Log.w(TAG, "no externel storage");
		return FolderPath;
	}

	public void canceldownload()	
	{
		if(downloadId != 0)
		{
			downloadManager.remove(downloadId);
			
		}

	}
	public String GetRootMountDevice() {
		String FolderPath = "";
		BaseHelper.log(TAG, "GetRootMountDevice getDevice come in");
		File[] files = new File("/mnt").listFiles();

		for (File file : files){
			if (file.isDirectory() && (file.getPath().startsWith("/mnt/sda1"))) {
				FolderPath = file.getPath();
				File ff = new File(FolderPath);
				if (ff.canRead() == true && ff.canWrite() == true) {
					return FolderPath;
				}
			}
		}
		System.out.printf("getExternalStorageDirectory  %s \n",  android.os.Environment.getExternalStorageDirectory().getPath());

		// 判断SdCard是否存在并且是可用的
		String state = android.os.Environment.getExternalStorageState();
		if(android.os.Environment.MEDIA_MOUNTED.equals(state)) {
			if(android.os.Environment.getExternalStorageDirectory().canWrite()) {
				return android.os.Environment.getExternalStorageDirectory().getPath();
			}
		}

		FolderPath = "/data/data/com.multak.MK8507MOA";
		Log.w(TAG, "no externel storage");
		return FolderPath;
	};

	public boolean fileIsExist(String filePath) {
		File f = new File(filePath);
		if (f.exists() != true) {
			return false;
		}
		return true;
	}

	public synchronized static String my_id(Context context) {
		if (sID == null) {
			File installation = new File(context.getFilesDir(), INSTALLATION);
			try {
				if (!installation.exists())
					writeInstallationFile(installation);
				sID = readInstallationFile(installation);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		return sID;
	}

	private static String readInstallationFile(File installation) throws IOException {
		RandomAccessFile f = new RandomAccessFile(installation, "r");
		byte[] bytes = new byte[(int) f.length()];
		f.readFully(bytes);
		f.close();
		return new String(bytes);
	}

	private static void writeInstallationFile(File installation) throws IOException {  
		FileOutputStream out = new FileOutputStream(installation);
		String id = UUID.randomUUID().toString();
		id = id.replace("-", "");
		out.write(id.getBytes());
		out.close();
	}

	public static void checkPath(String path, boolean needMedia) {
		File ktvfile3 = new File(path);
		if (ktvfile3.canRead() == false) {
			if (ktvfile3.mkdir() == true) {

			}
		}

		if (!needMedia) {
			ktvfile3 = new File(path + "/.nomedia");
			if (ktvfile3.canRead() == false) {
				if (ktvfile3.mkdir() == true) {

				}
			}
		}
	}

	void SaveLocalSingInfo() {
  		SharedPreferences prefs = mcontext.getSharedPreferences(mcontext.getPackageName(), Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = prefs.edit();

		ed.putInt("mobileFlag", 1);
		ed.putInt("mono", KaraokeLib.monoFlag);
		ed.putInt("samplerate", LocalSampleRate);
		ed.putInt("samplerateOut", LocalSampleRateOut);
		ed.commit();
	}

	@Override
	public void ControlUART(int n) {
		// TODO Auto-generated method stub
		BaseHelper.log(TAG, String.format("ControlUART %d", n));
		try {
			int a = (n & 0x00FFFF);
			int b = ((n & 0xFF0000) >> 16);
			Message msg = new Message();
			msg.what = b;
			msg.arg1 = a;
			mHandler.sendMessage(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void ControlUARTJava(int n) {
		BaseHelper.log(TAG, "ControlUARTJava n = " + n);
		try {
			Message msg = new Message();
			msg.what = n;
			mHandler.sendMessage(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void ControlUARTJavaS(int n, String content) {
		BaseHelper.log(TAG, "ControlUARTJava n = " + n);
		try {
			Message msg = new Message();
			msg.what = n;
			msg.obj = content;
			mHandler.sendMessage(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	public void ControlUARTJava(int n, String content) {
		BaseHelper.log(TAG, "ControlUARTJava n = " + n);
		try {
			Message msg = new Message();
			msg.what = n;
			msg.obj = content;
			mHandler.sendMessage(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	

	public void ControlUARTJavaDelay(int n, int delay) {
		BaseHelper.log(TAG, "ControlUARTJavaDelay n = " + n);
		try {
			Message msg = new Message();
			msg.what = n;
			mHandler.sendMessageDelayed(msg, delay);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public void FinishActivity() {
		// TODO Auto-generated method stub
		Toast.makeText(mcontext, R.string.slipToExit2, Toast.LENGTH_SHORT).show();
		
	   	SharedPreferences prefs2 = mcontext.getSharedPreferences(mcontext.getPackageName(), Context.MODE_PRIVATE);
		SharedPreferences.Editor ed= prefs2.edit();
		ed.putString("program", "2");
		ed.commit();
		
		KaraokeLib.StopAudioRecord();
		KaraokeLib.StopAudioTrack();
		RenderStatus = 0;
		RenderStatusEx = 0;
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				KaraokeLib.exit();
				KaraokeVGALib.exit();

				((MainActivity)mcontext).finish();
		    	android.os.Process.killProcess(android.os.Process.myPid());
			}
		}, 100);
	}

	@Override
	public void MultakConnectBroadcastOn(List<NetType> type, int typenum) {
		// TODO Auto-generated method stub
		if (MultakConnectInfo == 0) {
			MultakConnectInfo = 1;
		} else {
			BaseHelper.log(TAG, "MultakConnect off");
			ControlUART(0x980000);
		}
	}

	@Override
	public void MultakConnectBroadcastOff() {
		// TODO Auto-generated method stub
		if (MultakConnectInfo == 0) {
			MultakConnectInfo = 1;
		} else {
			BaseHelper.log(TAG, "MultakConnect On");
			ControlUART(0x990000);
		}
	}

	@Override
	public void MultakConnectBroadcastAll(List<NetType> type, int typenum) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onMsgNotify(int n) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onMsgNotify(int what, Object obj, String token) {
		// TODO Auto-generated method stub
	}
	
	// youtube service
	public static void getYoutubeViedoList(String queryTerm) {
		mYoutubeService.getYoutubeViedoList(queryTerm);
	}
	
	
	
	public static Handler mHandlerEx = new Handler();
	public static YouTubeListAdapter m_adapter = null;
	public static void getYoutubeViedoList1(String queryTerm) {
		YouTubeService.setQueryTerm(queryTerm);
		MultakRunnable runnable = new MultakRunnable(){
			@Override
			public void run() {
				// TODO Auto-generated method stub
				YouTubeListAdapter adapter = new YouTubeListAdapter();
				if(YouTubeService.getYoutubeViedoList1(m_StrParam, adapter)) {
					m_adapter = adapter;
					mHandlerEx.post(new Runnable() {
						@Override
						public void run() {
							// TODO Auto-generated method stub
							mGridView.setAdapter(m_adapter);
							mPriority = null;
							mSelect = null;
							mDownload = null;
							mFocusID = 0;
						}
					});
				}
			}
		};
		runnable.m_StrParam = queryTerm;
		new Thread(runnable).start();
	}
	
	
	/*
	public void YoutubeDownload(String pYouTubeVideoId) throws MalformedURLException{
		//mYoutubeService.YoutubeDownload(pYouTubeVideoId);
		
		//String[] syd =  pYouTubeVideoId.split("#YD#");
		StatFs sf = new StatFs("/mnt/sda4");
		int block = sf.getAvailableBlocks();
		int blocksize = sf.getBlockSize();
		int freesize = block * blocksize;
		Log.i("Youtube","blocksize " + blocksize);
		Log.i("Youtube","AvailableBlocks " + block);
		if(freesize > (104857600 * 5))
		{
			if(DownIDSongIndexMap.size() >= 3)
			{
				Log.w("Youtube","Download is busy");
			}
			else
			{
			//	ControlUARTJava(MyListener.MSG_ID_YOUTUBE_DOWNLOAD,pYouTubeVideoId);
				
			}
		}
		else
		{
			Log.w("Youtube", "Storage lower than 500M");
			
		}	
	}
	*/
	
	public static void mstartYoutubeVideoPreview() {
		mKaraokeVGA.startPreview();
	}
	public static void m_myControlUARTSnd(int n) {
		mKaraokeVGA.mm_myControlUARTSnd(n);
	}
	public static void m_MsgToHDMI(int iparam1, int iparam2, int iparam3, 
			int iparam4, int iparam5, int iparam6, int iparam7, int iparam8,
			String strparam1, String strparam2, String strparam3, String strparam4) {

		KaraokeLib.recvMsgFromVGA(iparam1, iparam2, iparam3,
				  iparam4, iparam5, iparam6, iparam7, iparam8,
				  strparam1, strparam2, strparam3, strparam4);
		return;
	}

	public static void startYoutubeVideoPreview() {
		mKaraokeVGA.startPreview();
	}
	// youtube service
	
	public static String getIPAddress(boolean useIPv4) {
    	try {
    		List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
    		for (NetworkInterface intf : interfaces) {
            	List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
            	for (InetAddress addr : addrs) {
            		if (!addr.isLoopbackAddress()) {
            			String sAddr = addr.getHostAddress().toUpperCase();
            			boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr); 
            			if (useIPv4) {
            				if (isIPv4) {
            					return sAddr;
            				}
            			} else {
            				if (!isIPv4) {
            					int delim = sAddr.indexOf('%'); // drop ip6 port suffix
            					return delim<0 ? sAddr : sAddr.substring(0, delim);
            				}
            			}
            		}
            	}
    		}
    	} catch (Exception ex) { } // for now eat exceptions
    	return "";
    }

    public static String convertIPAddress(int ip) {
    	return (ip & 0xFF ) + "." + ((ip >> 8 ) & 0xFF) + "." + ((ip >> 16 ) & 0xFF) + "." + ( ip >> 24 & 0xFF) ;  
    }
    
    private static void StartMTVServer(String ip) {
    	/*String[] args = new String[] {
    		"MTVServer",
    		"-h", ip, 
			"-p", "8084",
			"-d", "/mnt/sda4/KARAOKE/SONG",
    	};
    	StandardWebServer.StartServer(args);*/
    	String[] args = new String[] {
    		"-h", ip, 
			"-p", "8084",
			"-d", "/mnt/sda4/KARAOKE/SONG",
    	};
    	SimpleWebServer.StartServer(args);
    	Log.w(TAG, "StartServer  " + ip);
    }
    
    private static void StopMTVSercer() {
    	//StandardWebServer.StopServer("MTVServer");
    	SimpleWebServer.StopServer();
    }
}
