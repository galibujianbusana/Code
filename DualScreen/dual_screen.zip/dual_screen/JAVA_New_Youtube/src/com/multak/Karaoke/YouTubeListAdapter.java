package com.multak.Karaoke;

import java.util.ArrayList;
import java.util.List;

import com.multak.MK8507MOA.R;
import com.squareup.picasso.Picasso;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.util.Log;

public class YouTubeListAdapter extends BaseAdapter {

	private static Context mContext = null;
	
	private List<YouTubeListItem> m_list = new ArrayList<YouTubeListItem>();
	
	public static void setContext(Context context) {
		mContext = context;
	}
	
	public YouTubeListItem getItemData(int position) {
		return  m_list.get(position);
	}
	public YouTubeListItem findItemData(String videoID){
		YouTubeListItem item = null;
		//return m_list.contains(arg0)
		for(int i = 0; i < m_list.size();i++){
			if(m_list.get(i).m_videoID.equals(videoID)){
				item = m_list.get(i);
			}
		}
		return item;
	}
	
	public void setListItem(String ID, String Name, String Url) {
		YouTubeListItem item = new YouTubeListItem();;
		item.m_videoID = ID;
		item.m_videoName = Name;
		item.m_videoThumbUrl = Url;
		m_list.add(item);
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return m_list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if(convertView == null) {
			LayoutInflater inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.youtube_item, parent, false);
		}
		ImageView image = (ImageView)convertView.findViewById(R.id.imageView);
		Uri uri = Uri.parse(m_list.get(position).m_videoThumbUrl);
		Log.i("GetImg","Uri " + uri);
		Picasso.with(image.getContext()).load(uri).placeholder(R.drawable.loading_thumbnail).error(R.drawable.no_thumbnail).into(image);
		ImageButton priority = (ImageButton)convertView.findViewById(R.id.priority);
		priority.setVisibility(View.INVISIBLE);
		ImageButton select = (ImageButton)convertView.findViewById(R.id.select);
		select.setVisibility(View.INVISIBLE);
		TextView text = (TextView)convertView.findViewById(R.id.textView);
		text.setText(m_list.get(position).m_videoName);
		text.setTextColor(Color.rgb(0, 0, 0));
		convertView.setTag(position);
		return convertView;
	}

}
