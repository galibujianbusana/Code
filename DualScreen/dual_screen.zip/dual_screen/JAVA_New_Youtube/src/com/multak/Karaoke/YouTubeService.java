package com.multak.Karaoke;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Random;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.content.Context;
import android.net.ParseException;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout.LayoutParams;
import android.widget.FrameLayout;
import android.widget.VideoView;

import com.github.axet.vget.VGet;
import com.github.axet.vget.info.VideoFileInfo;
import com.github.axet.vget.info.VideoInfo;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayer.ErrorReason;
import com.google.android.youtube.player.YouTubePlayer.PlaybackEventListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStyle;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerFragment;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.ResourceId;
import com.google.api.services.youtube.model.SearchListResponse;
import com.google.api.services.youtube.model.SearchResult;
import com.google.api.services.youtube.model.Thumbnail;
import com.multak.MK8507MOA.MainActivity;
import com.multak.Karaoke.SearchYouTube;
import com.multak.Karaoke.VideoSearchList;
import com.singmate.findyoutube.YoutubeUtil;

/*
 * 
 *
  "AIzaSyDGWhgCVfYXq1Xm8yBUcxo2vyO1dkTQf-Y",
  "AIzaSyDJ2NmoIICbupmZb_W1c7JXE5w1x5ZHF5Y",
  "AIzaSyBkiOhiX4tQrPrPEcAaSa3XCwnYIbuTZgk",
  "AIzaSyBrtL6xPqqjZLOHiXjgMPWfzfZFtGRJd30",
  "AIzaSyCcmJ4gMw3AXFYVZkVHjZmVIoxqgc6mI9k",
  "AIzaSyCmttG9ie8sZ-1tDlZmgXWKa_S9vzDFu4Y",
  "AIzaSyCMoFO8nxPiwaeNf2qAA1KOn1M9T72-olg",
  "AIzaSyBeVA1ZYrs8o6ouUsIe_9IbOdUPhtFtXTI",
  "AIzaSyBfl3bX05mqe5LGg2DQNtj3h9fUJYy4X6c",
  "AIzaSyAXj9iMHpNPzTpnhtL4mnC3_EO2-2kho0Q",
 * 
 * */
public class YouTubeService implements YouTubePlayer.OnInitializedListener {
	private static String TAG = "YouTube";  

	private static final String DEVELOPER_KEY = "AIzaSyAKRV1ctvRV9_zEP4JcKu9kuFTDNbuARqA";

	private Context mcontext;
	static VideoSearchList videoList;
	private static YouTube youtube = null;
	private static YouTubePlayer youTubeplayer = null;
	private static YouTubePlayerView youTubePlayerView = null;
	private static YouTubePlayerView youTubePlayerView_ex = null;
	private static String m_queryTerm = "";
	public static String YID = "Test";
	public static void setQueryTerm(String queryTerm) {
		m_queryTerm = queryTerm;
	}


	
	public YouTubeService(Context context) {
        mcontext = context; 
        
        File fsn = new File("/mnt/sdcard/SN.TXT");
		//String YID = "Test";
		if(fsn.canRead()){
			try {
				BufferedReader reader = new BufferedReader(new FileReader(fsn));
				try {
					YID = reader.readLine();
					YID = YID.replace(" ", "");
					Log.i("GETSN","GETSN " + YID);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
    }
	/**
     * ����n����ͬ��������������������Ϊ[0,10)
     * @param n
     * @return
     */
	private static boolean SearchWithKey = false;//true;
	//public String[] SEARCH_KEY = {"AIzaSyCcmJ4gMw3AXFYVZkVHjZmVIoxqgc6mI9k","AIzaSyCmttG9ie8sZ-1tDlZmgXWKa_S9vzDFu4Y","AIzaSyCMoFO8nxPiwaeNf2qAA1KOn1M9T72-olg","AIzaSyBeVA1ZYrs8o6ouUsIe_9IbOdUPhtFtXTI","AIzaSyBfl3bX05mqe5LGg2DQNtj3h9fUJYy4X6c"};
	public static String[] SEARCH_KEY = {//"AIzaSyBtlCvSHR4i-EaaTeR1EyKOZ6oGfB1wASU",
								  
								  "AIzaSyDGWhgCVfYXq1Xm8yBUcxo2vyO1dkTQf-Y",
								  "AIzaSyDJ2NmoIICbupmZb_W1c7JXE5w1x5ZHF5Y",
								  "AIzaSyBkiOhiX4tQrPrPEcAaSa3XCwnYIbuTZgk",
								  "AIzaSyBrtL6xPqqjZLOHiXjgMPWfzfZFtGRJd30",
								  "AIzaSyCcmJ4gMw3AXFYVZkVHjZmVIoxqgc6mI9k",
								  "AIzaSyCmttG9ie8sZ-1tDlZmgXWKa_S9vzDFu4Y",
								  "AIzaSyCMoFO8nxPiwaeNf2qAA1KOn1M9T72-olg",
								  "AIzaSyBeVA1ZYrs8o6ouUsIe_9IbOdUPhtFtXTI",
								  "AIzaSyBfl3bX05mqe5LGg2DQNtj3h9fUJYy4X6c",
								  "AIzaSyAXj9iMHpNPzTpnhtL4mnC3_EO2-2kho0Q",
								  
								  };
	public static ArrayList<String> getDiffKEY(int n){
        // ���� [0-n) �����ظ��������
        // list ����������Щ�����
        ArrayList<String> list = new ArrayList<String>();
        Random rand = new Random();
        boolean[] bool = new boolean[n];
        int num = 0;
        for (int i = 0; i < n; i++) {
            do {
                // �������������ͬ����ѭ��
                num = rand.nextInt(n);
            } while (bool[num]);
            bool[num] = true;
            list.add(SEARCH_KEY[num]);
        }
        return list;
    }
	//search
	public static boolean getYoutubeURL(final String queryTerm, final YouTubeListAdapter adapter)
	{
//		new Thread(){
	      //       @Override
	        //     public void run() {
	         //        super.run();
	                 SearchYouTube syt = new SearchYouTube("karaoke"+queryTerm, "/mnt/sda2/"/*android.os.Environment.getExternalStorageDirectory().getPath()*/);
	                 syt.ClearSearch();
	                 syt.StartSearch();
	                 
	                 while(syt.searchReady == 0)
	                 {
	                     try {
	                         Thread.sleep(1000);
	                     } catch (InterruptedException e) {
	                         e.printStackTrace();
	                         return false;
	                     }
	                 }
	                 
	                 syt.SearchPage(1);
	                 while(syt.searchReady == 0)
	                 {
	                     try {
	                         Thread.sleep(1000);
	                     } catch (InterruptedException e) {
	                         e.printStackTrace();
	                         return false;
	                     }
	                 }
	                 
	                 videoList = syt.videoList;

	                 int sizeYouTube=videoList.GetSearchCount();
	                 for(int i=0;i<sizeYouTube;i++){
	                     VideoSearchList.YouTubeItem item=videoList.GetSearchItem(i);
	                     VideoSearchList.YouTubeItem._snippet snippet = item.snippet;
	                     VideoSearchList.YouTubeItem._id id = item.id;
	                     String videoId = id.videoId;
	                     String title = snippet.title;
	                     VideoSearchList.YouTubeItem._snippet._thumbnails thumbnails = snippet.thumbnails;
	                     String url = thumbnails.high.url;
	                     //data.add(new AdapterData(url,title,videoId));
	                     adapter.setListItem(videoId,title,url);
	                     
	                     Log.d(TAG, "search result--"+videoId+"---"+title+"----"+url);
	                 }
	                 if(sizeYouTube > 0){
	                	 Karaoke.setSearchinvisiable();
	                	 Karaoke.YTSearched = true;
	                 }
	                 return true;	
	                 //handler.sendEmptyMessageDelayed(MSG_SEARCH,100);

	                 

	          //   }
	        // }.start();
	}
	public static boolean getYoutubeViedoList1(final String queryTerm, final YouTubeListAdapter adapter) {
		if(queryTerm.equals(m_queryTerm)) {
			
			int j;
			ArrayList<String> random_list = getDiffKEY(SEARCH_KEY.length);
			boolean searchsuccessful = false;
			if(SearchWithKey == true){
				for(j = 0; j < SEARCH_KEY.length ; j++)
				{
					try {
						if(youtube == null) {
							youtube = new YouTube.Builder(new NetHttpTransport(), new JacksonFactory(), new HttpRequestInitializer() {
								public void initialize(HttpRequest request) throws IOException {
								}
							}).setApplicationName("youtube-search-multak").build();
						}
						YouTube.Search.List search = youtube.search().list("id,snippet");
						//String s_key = random_list.get(j);
						//search.setKey(random_list.get(j));
						String s_key = SEARCH_KEY[j];
						search.setKey(s_key);
						Log.w(TAG, "getYoutubeViedoList DEVELOPER_KEY =" + s_key);
						
						search.setQ("karaoke " + queryTerm);
						search.setType("video");
						search.setFields("items(id/kind,id/videoId,snippet/title,snippet/thumbnails/high/url),nextPageToken");
						search.setMaxResults((long)50);
						SearchListResponse searchResponse = search.execute();
						List<SearchResult> searchResultList = searchResponse.getItems();
						if (searchResultList != null) {
							if(queryTerm.equals(m_queryTerm)) {
								setSearchList1(searchResultList.iterator(), queryTerm, adapter);
								searchsuccessful = true;
							} else {
								//return false;
							}
						}
						//test
						/*for(int i = 0; i < 1; i ++) {
							String nextpageToken = searchResponse.getNextPageToken();
							if(nextpageToken != null) {
								search.setPageToken(nextpageToken);
								searchResponse = search.execute();
								searchResultList = searchResponse.getItems();
								if (searchResultList != null) {
									if(queryTerm.equals(m_queryTerm)) {
										setSearchList1(searchResultList.iterator(), queryTerm, adapter);
										searchsuccessful = true;
									} else {
										//return false;
									}
								}
							}
						}*/
						//test
						return true;
					} catch (GoogleJsonResponseException e) {
						System.err.println("GoogleJsonResponseException code: " + e.getDetails().getCode() + " : " + e.getDetails().getMessage());
						e.printStackTrace();
						//searchsuccessful = false;
						searchsuccessful = getYoutubeURL(queryTerm,adapter);
					} catch (IOException e) {
						System.err.println("There was an IO error: " + e.getCause() + " : " + e.getMessage());
						//searchsuccessful = false;
						searchsuccessful = getYoutubeURL(queryTerm,adapter);
					} catch (Throwable t) {
						t.printStackTrace();
						//searchsuccessful = false;
						searchsuccessful = getYoutubeURL(queryTerm,adapter);
					}
					if(searchsuccessful == true)
						return true;
				}
			}else{
				searchsuccessful = getYoutubeURL(queryTerm,adapter);
				if(searchsuccessful == true)
					return true;
			}
			
			
			
			
			
		
		}
		return false;
	}
	
	private static void setSearchList1(Iterator<SearchResult> iteratorSearchResults, String query, YouTubeListAdapter adapter) {
			if (!iteratorSearchResults.hasNext()) {
				Log.w(TAG, " There aren't any results for your query.");
			}
			else{
				Karaoke.setSearchinvisiable();
           	 	Karaoke.YTSearched = true;
			}
            	 
        
			while (iteratorSearchResults.hasNext()) {
				SearchResult singleVideo = iteratorSearchResults.next();
				ResourceId rId = singleVideo.getId();
				if (rId.getKind().equals("youtube#video")) {
					//KaraokeLib.setYoutube(1, query, singleVideo.getSnippet().getTitle(), rId.getVideoId());
						
					adapter.setListItem(rId.getVideoId(), singleVideo.getSnippet().getTitle(), singleVideo.getSnippet().getThumbnails().getHigh().getUrl());
					
				 }
			}
			//KaraokeVGALib.setYoutube(2, "", "", "");
		}

	public void getYoutubeViedoList(String queryTerm) {
		
		int j;
		ArrayList<String> random_list = getDiffKEY(SEARCH_KEY.length);
		
		
		boolean searchsuccessful = false;
		for(j = 0; j < SEARCH_KEY.length ; j++)
		{
			
			try {
				if(youtube == null) {
					youtube = new YouTube.Builder(new NetHttpTransport(), new JacksonFactory(), new HttpRequestInitializer() {
						public void initialize(HttpRequest request) throws IOException {
						}
					}).setApplicationName("youtube-search-multak").build();
				}
				YouTube.Search.List search = youtube.search().list("id,snippet");
				
				String s_key = random_list.get(j);
				search.setKey(random_list.get(j));
				Log.w(TAG, "getYoutubeViedoList DEVELOPER_KEY =" + s_key);
				search.setQ("karaoke " + queryTerm);
				search.setType("video");
				search.setFields("items(id/kind,id/videoId,snippet/title,snippet/thumbnails/default/url),nextPageToken");
				search.setMaxResults((long)50);
				SearchListResponse searchResponse = search.execute();
				List<SearchResult> searchResultList = searchResponse.getItems();
				if (searchResultList != null) {
					setSearchList(searchResultList.iterator(), queryTerm);
					searchsuccessful = true;
				}
				//test
				/*
				for(int i = 0; i < 1; i ++) {
					String nextpageToken = searchResponse.getNextPageToken();
					if(nextpageToken != null) {
						search.setPageToken(nextpageToken);
						searchResponse = search.execute();
						searchResultList = searchResponse.getItems();
						if (searchResultList != null) {
							setSearchList(searchResultList.iterator(), queryTerm);
							searchsuccessful = true;
						}
					}
				}*/
				//test
				
			} catch (GoogleJsonResponseException e) {
				System.err.println("GoogleJsonResponseException code: " + e.getDetails().getCode() + " : " + e.getDetails().getMessage());
				e.printStackTrace();
				searchsuccessful = false;
			} catch (IOException e) {
				System.err.println("There was an IO error: " + e.getCause() + " : " + e.getMessage());
				searchsuccessful = false;
			} catch (Throwable t) {
				t.printStackTrace();
				searchsuccessful = false;
			}
			if(searchsuccessful == true)
				break;
		}
		
	}
	
	private static void setSearchList(Iterator<SearchResult> iteratorSearchResults, String query) {
		if (!iteratorSearchResults.hasNext()) {
			Log.w(TAG, " There aren't any results for your query.");
		}
        while (iteratorSearchResults.hasNext()) {
            SearchResult singleVideo = iteratorSearchResults.next();
            ResourceId rId = singleVideo.getId();
            if (rId.getKind().equals("youtube#video")) {
                //Thumbnail thumbnail = singleVideo.getSnippet().getThumbnails().getDefault();
            	//thumbnail.getUrl()
            	KaraokeVGALib.setYoutube(1, query, singleVideo.getSnippet().getTitle(), rId.getVideoId());
             }
        }
        //KaraokeVGALib.setYoutube(2, "", "", "");
    }

	//play
	public void setYoutubeView(YouTubePlayerView view) {
		youTubePlayerView = view;
		if(youTubePlayerView != null) {
			youTubePlayerView.initialize(DEVELOPER_KEY, this);
			Log.w(TAG, "youTubePlayerView" + DEVELOPER_KEY);
		}
	}
	
	public void setYoutubeView_ex(YouTubePlayerView view) {
		//youTubePlayerView_ex = view;
		//if(youTubePlayerView_ex != null) {
			//youTubePlayerView_ex.initialize(DEVELOPER_KEY, this);
			//Log.w(TAG, "youTubePlayerView_ex" + DEVELOPER_KEY);
		//}
	}
	
	
	public void playYoutubeEXO(String url)
	{
		final String Yurl = url;
		((MainActivity)mcontext).runOnUiThread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				//MainActivity.ExoPlay(Yurl);
			}
		});
		
	}
	public void HideYoubuteView()
	{
		
		
		((MainActivity)mcontext).runOnUiThread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				youTubePlayerView.setVisibility(View.INVISIBLE);
				KaraokeHDMI.mVideoSurfaceView.setVisibility(View.VISIBLE);
			}
		});
	}
	private String mVideoID = "";
	public void playYoutubeVideo(String videoID) {
		mVideoID = videoID;
		if(youTubeplayer != null) {
			((MainActivity)mcontext).runOnUiThread(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					youTubePlayerView.setVisibility(View.VISIBLE);
					KaraokeHDMI.mVideoSurfaceView.setVisibility(View.INVISIBLE);
					//youTubePlayerView_ex.setVisibility(View.VISIBLE);
					//KaraokeVGA.mVideoSurfaceViewEx.setVisibility(View.INVISIBLE);
					if(youTubeplayer != null) {
						youTubeplayer.loadVideo(mVideoID);
						//youTubeplayer.cueVideo(mVideoID);
					}
				}
			});
		} else {
			//JavaVideoLib.youTubePlayerOnError();
			Log.w(TAG, "youTubePlayerOnError");
		}
	}

	@Override
	public void onInitializationFailure(Provider arg0, YouTubeInitializationResult arg1) {
		// TODO Auto-generated method stub
		Log.w(TAG, "onInitializationFailure");
	}

	@Override
	public void onInitializationSuccess(Provider arg0, YouTubePlayer arg1, boolean arg2) {
		// TODO Auto-generated method stub
		Log.w(TAG, "onInitializationSuccess" + " arg1 " + arg1);
		youTubeplayer = arg1;
		youTubeplayer.setPlayerStyle(PlayerStyle.MINIMAL);
		youTubeplayer.setPlaybackEventListener(new PlaybackEventListener() {
			@Override
			public void onStopped() {
				// TODO Auto-generated method stub
				Log.w(TAG, "onStopped");
			}
			@Override
			public void onSeekTo(int arg0) {
				// TODO Auto-generated method stub
			}
			@Override
			public void onPlaying() {
				// TODO Auto-generated method stub
				Log.w(TAG, "onPlaying");
				JavaVideoLib.setYouTubePlayerStatus(JavaVideoLib.m_playing);
				
			}
			@Override
			public void onPaused() {
				// TODO Auto-generated method stub
				Log.w(TAG, "onPaused");
				JavaVideoLib.setYouTubePlayerStatus(JavaVideoLib.m_paused);
			}
			@Override
			public void onBuffering(boolean arg0) {
				// TODO Auto-generated method stub
				Log.w(TAG, "onBuffering");
			}
			
		});
		youTubeplayer.setPlayerStateChangeListener(new PlayerStateChangeListener() {
			@Override
			public void onVideoStarted() {
				// TODO Auto-generated method stub
				Log.w(TAG, "onVideoStarted");
				JavaVideoLib.setYouTubePlayerStatus(JavaVideoLib.m_playing);
				KaraokeVGALib.setStatus(2,-1,0);
				KaraokeVGALib.setStatus(4,10,0);
			}
			@Override
			public void onVideoEnded() {
				// TODO Auto-generated method stub
				Log.w(TAG, "onVideoEnded");
				((MainActivity)mcontext).runOnUiThread(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
					//	youTubePlayerView.setVisibility(View.INVISIBLE);
					//	KaraokeHDMI.mVideoSurfaceView.setVisibility(View.VISIBLE);
					//	JavaVideoLib.stopproc();
					//	KaraokeVGALib.setStatus(2,10,0);
						KaraokeVGALib.setStatus(3,0,0);
					}
				});
			}
			@Override
			public void onLoading() {
				// TODO Auto-generated method stub
				Log.w(TAG, "onLoading");
			}
			@Override
			public void onLoaded(String arg0) {
				// TODO Auto-generated method stub
				Log.w(TAG, "onLoaded");
				JavaVideoLib.setYouTubePlayerStatus(JavaVideoLib.m_parsed);
				//if(youTubeplayer != null) {
				//	youTubeplayer.play();
				//}
			}
			@Override
			public void onError(ErrorReason arg0) {
				// TODO Auto-generated method stub
				Log.w(TAG, "onError " + arg0.name());
				if(JavaVideoLib.getYouTubePlayerStatus()==JavaVideoLib.m_playing)
				{
					KaraokeVGALib.setStatus(3,0,0);
				}else{
					JavaVideoLib.setYouTubePlayerStatus(JavaVideoLib.m_parsed);
					
					try {
			            Thread.sleep(300);
			        } catch (InterruptedException e) {
						e.printStackTrace();
			        }	

					
					
					JavaVideoLib.setYouTubePlayerStatus(JavaVideoLib.m_playing);
					KaraokeVGALib.setStatus(4,10,0);
				}
				
				
			}
			@Override
			public void onAdStarted() {
				// TODO Auto-generated method stub
				Log.w(TAG, "onAdStarted");
			}
		});
	}
	
	public void pause() {
		if(youTubeplayer != null) {
			youTubeplayer.pause();
		}
	}
	
	public void resume() {
		if(youTubeplayer != null) {
			youTubeplayer.play();
		}
	}
	
	public void stop() {
		if(youTubeplayer != null) {
			youTubeplayer.pause();
			JavaVideoLib.setYouTubePlayerStatus(JavaVideoLib.m_stopping);
			((MainActivity)mcontext).runOnUiThread(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
				///	youTubePlayerView.setVisibility(View.INVISIBLE);
				///	KaraokeHDMI.mVideoSurfaceView.setVisibility(View.VISIBLE);
					//youTubePlayerView_ex.setVisibility(View.INVISIBLE);
					//KaraokeVGA.mVideoSurfaceViewEx.setVisibility(View.VISIBLE);
					//JavaVideoLib.setYouTubePlayerStatus(JavaVideoLib.m_stopped);
					//JavaVideoLib.stopproc();
					KaraokeVGALib.setStatus(2,10,0);
					JavaVideoLib.setYouTubePlayerStatus(JavaVideoLib.m_stopped);
					KaraokeVGALib.setStatus(4,0,0);
				}
			});
		}
	}
	public void YoutubeDownload(String pYouTubeVideoId) throws MalformedURLException
	{
		String url = calculateYouTubeUrl(pYouTubeVideoId);
		
		//String url = GetYoutbeWebUrl(pYouTubeVideoId);
	}
	
	//get url
	public String calculateYouTubeUrl(String pYouTubeVideoId) /*throws MalformedURLException */{
		
		/*
		String weburl = GetYoutbeWebUrl(pYouTubeVideoId);
		
		Log.i(TAG,"web url " + weburl);
		if(weburl.contains("&ip=47.74.146.114"))
		{
			Log.i(TAG,"use Vget");
			String url = "https://www.youtube.com/watch?v=" + pYouTubeVideoId;
	        String path = "/mnt/sdcard";
	        try
	        {
	        	VGet v1 = new VGet(new URL(url), new File(path));
	            v1.extract();
	            VideoInfo info = v1.getVideo();
	            List<VideoFileInfo> dinfoList = info.getInfo();
	            Log.i("MainActivity", "total " + dinfoList.size());
	            if(dinfoList.size() > 0) {
	            	return dinfoList.get(0).getSource().toString();
	            }
	        }catch (Exception e)
	        {
	        	e.printStackTrace();
	        }
	        
			return "";
		}else{
			Log.i(TAG,"use server");
			return weburl;
		}
		*/
		Log.i(TAG,"real ID " + YID);
		String weburl=YoutubeUtil.getPlayUrl(pYouTubeVideoId,YID);
		Log.i(TAG,"web url " + weburl);
		
		if(weburl != "" || weburl != null){
			try {
				JSONArray jarray = new JSONArray(weburl);
				//Log.i(TAG,"jarray="+jarray);
				JSONObject jobject = (JSONObject)jarray.get(0);
				//Log.i(TAG,"jobject="+jobject);
				return jobject.getString("videoUrl");
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "";
			}

		}else{
			return "";
		}
		
		 
		
	}
	
	
	public String GetYoutbeWebUrl(String VID)
	{
		String url = "http://m3.51kara.com/update/geturl.php?prj=mk8509zda&v=" + VID;
		String weburl ="";
		try{
			Log.i(TAG,"inurl " + url);
			weburl = SystemUt.getHTML1(url);
			Log.i(TAG,"weburl " + weburl);
			String result[] = weburl.split("#");
			if(result.length >= 3){
				int returnid = Integer.parseInt(result[1]);
				if(returnid > 0){
					Log.i(TAG,"url " + result[2]);
					return result[2];
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return "";
	}
	
	
	public String GetYoutubeUrl(String VID)
	{
		String YoutubeUrl = "";
		
		try
		{
			String url = "https://www.youtube.com/watch?v=" + VID;
	        String path = "/mnt/sdcard";
	        boolean resultOK = false;
	        
	        try
            {
	            VGet v1 = new VGet(new URL(url), new File(path));
	            //v1.download();
	            v1.extract();
	            VideoInfo info = v1.getVideo();
	            List<VideoFileInfo> dinfoList = info.getInfo();
	            if(dinfoList.size() > 0)
	            {
		            URL urlSource = dinfoList.get(0).getSource();
		            YoutubeUrl = dinfoList.get(0).getSource().toString();
					resultOK = true;
	            }
            }
            catch(Exception e)
            {
            	Log.e("Youtube",e.getMessage());
            }
	        if(resultOK == false)
            {
            	try
                {
	            	Thread.sleep(1000);
	            	
	            	 VGet v2 = new VGet(new URL(url), new File(path));
	                 //v1.download();
	                 v2.extract();
	                 VideoInfo info2 = v2.getVideo();
	                 List<VideoFileInfo> dinfoList2 = info2.getInfo();
	                 if(dinfoList2.size() > 0)
	                 {
	     	            URL urlSource2 = dinfoList2.get(0).getSource();
	     	            YoutubeUrl = dinfoList2.get(0).getSource().toString();
	     				resultOK = true;
	                 }
                }
            	catch(Exception e)
                {
            		Log.e("Youtube",e.getMessage());
                }
            }
	        if(resultOK == false)
            {
            	try
                {
	            	Thread.sleep(1000);
	            	
	            	 VGet v2 = new VGet(new URL(url), new File(path));
	                 //v1.download();
	                 v2.extract();
	                 VideoInfo info2 = v2.getVideo();
	                 List<VideoFileInfo> dinfoList2 = info2.getInfo();
	                 if(dinfoList2.size() > 0)
	                 {
	     	            URL urlSource2 = dinfoList2.get(0).getSource();
	     	            YoutubeUrl = dinfoList2.get(0).getSource().toString();
	     				resultOK = true;
	                 }
                }
            	catch(Exception e)
                {
            		Log.e("Youtube",e.getMessage());
                }
            }
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally {
			//lockUrl.unlock();
		}
		return YoutubeUrl;
	}
	
	
	private static final String YOUTUBE_VIDEO_INFORMATION_URL = "http://www.youtube.com/get_video_info?&video_id=";
	public String calculateYouTubeUrl(String pYouTubeFmtQuality, boolean pFallback,
            String pYouTubeVideoId) throws IOException,
            ClientProtocolException, UnsupportedEncodingException {
		
        String lUriStr = null;
        HttpClient lClient = new DefaultHttpClient();
        HttpGet lGetMethod = new HttpGet(YOUTUBE_VIDEO_INFORMATION_URL + pYouTubeVideoId);
        HttpResponse lResp = null;
        lResp = lClient.execute(lGetMethod);
            
        ByteArrayOutputStream lBOS = new ByteArrayOutputStream();
        String lInfoStr = null;
        lResp.getEntity().writeTo(lBOS);
        lInfoStr = new String(lBOS.toString("UTF-8"));
        
        String[] lArgs=lInfoStr.split("&");
        Map<String,String> lArgMap = new HashMap<String, String>();
        for(int i=0; i<lArgs.length; i++){
            String[] lArgValStrArr = lArgs[i].split("=");
            if(lArgValStrArr != null){
                if(lArgValStrArr.length >= 2){
                    lArgMap.put(lArgValStrArr[0], URLDecoder.decode(lArgValStrArr[1]));
                }
            }
        }
        
        //Find out the URI string from the parameters
        //Populate the list of formats for the video
        String lFmtList = URLDecoder.decode(lArgMap.get("fmt_list"));
        ArrayList<Format> lFormats = new ArrayList<Format>();
        if(null != lFmtList){
            String lFormatStrs[] = lFmtList.split(",");
            
            for(String lFormatStr : lFormatStrs){
                Format lFormat = new Format(lFormatStr);
                lFormats.add(lFormat);
            }
        }
        
        //Populate the list of streams for the video
        String lStreamList = lArgMap.get("url_encoded_fmt_stream_map");
        if(null != lStreamList){
            String lStreamStrs[] = lStreamList.split(",");
            ArrayList<VideoStream> lStreams = new ArrayList<VideoStream>();
            for(String lStreamStr : lStreamStrs){
                VideoStream lStream = new VideoStream(lStreamStr);
                lStreams.add(lStream);
            }    
            
            //Search for the given format in the list of video formats
            // if it is there, select the corresponding stream
            // otherwise if fallback is requested, check for next lower format
            int lFormatId = Integer.parseInt(pYouTubeFmtQuality);
            
            Format lSearchFormat = new Format(lFormatId);
            while(!lFormats.contains(lSearchFormat) && pFallback ){
                int lOldId = lSearchFormat.getId();
                int lNewId = getSupportedFallbackId(lOldId);
                
                if(lOldId == lNewId){
                    break;
                }
                lSearchFormat = new Format(lNewId);
            }
            
            int lIndex = lFormats.indexOf(lSearchFormat);
            if(lIndex >= 0){
                VideoStream lSearchStream = lStreams.get(lIndex);
                lUriStr = lSearchStream.getUrl();
            }
            
        }        
        //Return the URI string. It may be null if the format (or a fallback format if enabled)
        // is not found in the list of formats for the video
        return lUriStr;
    }
	
	protected static String extractYoutubeId(String url) throws MalformedURLException {
	    String id = null;
	    try  {
	        String query = new URL(url).getQuery();
	        if (query != null) {
	            String[] param = query.split("&");
	            for (String row : param) {
	                String[] param1 = row.split("=");
	                if (param1[0].equals("v")) {
	                    id = param1[1];
	                }
	            }
	        } else {
	            if (url.contains("embed")) {
	                id = url.substring(url.lastIndexOf("/") + 1);
	            }
	        }
	    }
	    catch (Exception ex) {
	        Log.e("Exception", ex.toString());
	    }
	    return id;
	}
	
    public static int getSupportedFallbackId(int pOldId){
        final int lSupportedFormatIds[] = {13,  //3GPP (MPEG-4 encoded) Low quality  
                                          17,  //3GPP (MPEG-4 encoded) Medium quality  
                                          18,  //MP4  (H.264 encoded) Normal quality
                                          22,  //MP4  (H.264 encoded) High quality
                                          37   //MP4  (H.264 encoded) High quality
                                          };
        int lFallbackId = pOldId;
        for(int i = lSupportedFormatIds.length - 1; i >= 0; i--){
            if(pOldId == lSupportedFormatIds[i] && i > 0){
                lFallbackId = lSupportedFormatIds[i-1];
            }            
        }
        return lFallbackId;
    }
    
    class Format {

        protected int mId;
        
        /**
         * Construct this object from one of the strings in the "fmt_list" parameter
         * @param pFormatString one of the comma separated strings in the "fmt_list" parameter
         */
        public Format(String pFormatString){
            String lFormatVars[] = pFormatString.split("/");
            mId = Integer.parseInt(lFormatVars[0]);
        }
        /**
         * Construct this object using a format id
         * @param pId id of this format
         */
        public Format(int pId){
            this.mId = pId;
        }
        
        /**
         * Retrieve the id of this format
         * @return the id
         */
        public int getId(){
            return mId;
        }
        
        /** (non-Javadoc)
         * @see java.lang.Object#equals(java.lang.Object)
         */
        @Override
        public boolean equals(Object pObject) {
            if(!(pObject instanceof Format)){
                return false;
            }
            return ((Format)pObject).mId == mId;
        }
    }
    
    class VideoStream {
        
        protected String mUrl;
        
        /**
         * Construct a video stream from one of the strings obtained  
         *     from the "url_encoded_fmt_stream_map" parameter if the video_info  
         * @param pStreamStr - one of the strings from "url_encoded_fmt_stream_map"
         */
        public VideoStream(String pStreamStr){
            String[] lArgs=pStreamStr.split("&");
            Map<String,String> lArgMap = new HashMap<String, String>();
            for(int i=0; i<lArgs.length; i++){
                String[] lArgValStrArr = lArgs[i].split("=");
                if(lArgValStrArr != null){
                    if(lArgValStrArr.length >= 2){
                        lArgMap.put(lArgValStrArr[0], lArgValStrArr[1]);
                    }
                }
            }
            mUrl = lArgMap.get("url");
        }
        public String getUrl(){
            return mUrl;
        }
    }
}
