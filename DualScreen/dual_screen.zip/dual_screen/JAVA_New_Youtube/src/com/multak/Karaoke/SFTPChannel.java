package com.multak.Karaoke;
  
import java.io.File;  
import java.io.FileInputStream;  
import java.io.FileOutputStream;  
import java.util.Map;  
import java.util.Properties;  
import java.util.Vector;  
import android.util.Log;  

  
import com.jcraft.jsch.Channel;  
import com.jcraft.jsch.ChannelSftp;  
import com.jcraft.jsch.JSch;  
import com.jcraft.jsch.JSchException;  
import com.jcraft.jsch.Session;  
import com.jcraft.jsch.SftpException;  
  
/** 
 * @author : lzq 
 * @group : huchi 
 * @Date : 2015-2-26 上午10:13:30 
 * @Comments : 通过SFTP，读取数�? 
 * @Version : 1.0.0 
 */  
public class SFTPChannel {  
  
    Session session = null;  
    Channel channel = null;  
  
    String TAG = "SFTPChannel";
  
    /** 
     * @MethodName : getChannel 
     * @Description : 得到Channel 
     * @param sftpDetails 
     * @param timeout 
     *            超时时间 
     * @return 
     * @throws JSchException 
     */  
    public ChannelSftp getChannel(Map<String, String> sftpDetails, int timeout)  
            throws JSchException {  
  
        String ftpHost = sftpDetails.get(SFTPConstants.SFTP_REQ_HOST);  
        String port = sftpDetails.get(SFTPConstants.SFTP_REQ_PORT);  
        String ftpUserName = sftpDetails.get(SFTPConstants.SFTP_REQ_USERNAME);  
        String ftpPassword = sftpDetails.get(SFTPConstants.SFTP_REQ_PASSWORD);  
  
        JSch jsch = new JSch(); // 创建JSch对象  
        session = jsch.getSession(ftpUserName, ftpHost, Integer.parseInt(port)); // 根据用户名，主机ip，端口获取一个Session对象  
        Log.d(TAG,"Session created.");  
        if (ftpPassword != null) {  
            session.setPassword(ftpPassword); // 设置密码  
        }  
        Properties config = new Properties();  
        config.put("StrictHostKeyChecking", "no");  
        session.setConfig(config); // 为Session对象设置properties  
        session.setTimeout(timeout); // 设置timeout时间  
        session.connect(); // 通过Session建立链接  
        Log.d(TAG,"Session connected.");  
  
        Log.d(TAG,"Opening Channel.");  
        channel = session.openChannel("sftp"); // 打开SFTP通道  
        channel.connect(); // 建立SFTP通道的连�?  
        Log.d(TAG,"Connected successfully to ftpHost = " + ftpHost + ",as ftpUserName = "  
                + ftpUserName + ", returning: " + channel);  
        return (ChannelSftp) channel;  
    }  
  
    /** 
     * @MethodName : closeChannel 
     * @Description : 关闭channel 
     * @throws Exception 
     */  
    public void closeChannel() throws Exception {  
        if (channel != null) {  
            channel.disconnect();  
        }  
        if (session != null) {  
            session.disconnect();  
        }  
    }  
  
    /** 
     * @MethodName : getSFTPChannel 
     * @Description : 得到SFTPChannel 类实例对�? 
     * @return 
     */  
    public SFTPChannel getSFTPChannel() {  
        return new SFTPChannel();  
    }  
      
    /** 
     * @MethodName  : download 
     * @Description : 下载文件 
     * @param directory  下载目录 
     * @param downloadFile 下载的文�? 
     * @param saveFile 存在本地的路�? 
     * @param sftp  
     */  
    public void download(String directory, String downloadFile, String saveFile, ChannelSftp sftp) {  
        try {  
            sftp.cd(directory);  
            File file = new File(saveFile);  
            sftp.get(downloadFile, new FileOutputStream(file));  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
      
    /** 
     * @MethodName  : upload 
     * @Description : 上传文件 
     * @param directory  上传的目�? 
     * @param uploadFile  要上传的文件 
     * @param sftp 
     */  
    public void upload(String directory, String uploadFile, ChannelSftp sftp) {  
        try {  
            sftp.cd(directory);  
            File file = new File(uploadFile);  
            sftp.put(new FileInputStream(file), file.getName());  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
      
    /** 
     * @MethodName  : delete 
     * @Description :  删除文件 
     * @param directory 要删除文件所在目�? 
     * @param deleteFile 要删除的文件 
     * @param sftp 
     */  
    public void delete(String directory, String deleteFile, ChannelSftp sftp) {  
        try {  
            sftp.cd(directory);  
            sftp.rm(deleteFile);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
      
    /** 
     * @MethodName  : listFiles 
     * @Description : 列出目录下的文件 
     * @param directory  要列出的目录 
     * @param sftp sftp 
     * @return 
     * @throws SftpException 
     */  
    public Vector listFiles(String directory, ChannelSftp sftp) throws SftpException {  
        return sftp.ls(directory);  
    }  
      
} 