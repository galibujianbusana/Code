package com.multak.Karaoke;
public class SFTPConstants {  
    public static final String SFTP_REQ_HOST = "host"; //IP地址  
    public static final String SFTP_REQ_PORT = "port"; //端口  
    public static final String SFTP_REQ_USERNAME = "username";   
    public static final String SFTP_REQ_PASSWORD = "password";  
    public static final String SFTP_PARTNER = "partner"; //商户�?  
} 