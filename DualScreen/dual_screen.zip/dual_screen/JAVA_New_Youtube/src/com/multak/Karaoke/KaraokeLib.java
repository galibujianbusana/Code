﻿package com.multak.Karaoke;

import java.io.File;

import com.multak.MK8507MOA.MainActivity;

import android.app.Instrumentation;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Handler;
import android.util.Log;

public class KaraokeLib {
	private static String TAG = "KaraokeLib";

	public static AudioTrack audioTrackJava = null;
	public static AudioRecord audioRecordJava = null;
	public static AudioManager mAudioManager = null;
	
	public static Handler mHandler = null;
	public static int mBuffersize;
	public static int nativeSamplerate;
	public static int monoFlag;
	
	public static Thread  Recordthread;
	public static Thread  Trackthread;
	
	public static byte[] mReadBuffer;
	public static int 	 mReadPos;
	public static int 	 mReadBuffersize;
	public static int 	 mMaxReadLength;
	
	public static int g_bufferSizeOutBytes;
	public static int g_bufferSizeInBytes;
	
	public static int	CurrentSamplerateRecord;
	
	public static MediaRecorder mMediaRecorder;// MediaRecorder对象
	public static File mRecAudioFile = null;
	public static String CurrentRecFilePath;

	static {
		nativeSamplerate = 48000;
		mHandler = new Handler();
		monoFlag = 2;
		g_bufferSizeInBytes = 4096*2*2;
		g_bufferSizeOutBytes = 4096*2*2;
		
		//System.load("/system/lib/libKaraokeLib.so");
		System.loadLibrary("KaraokeLib");	
    }
	
	public static MyListener myListener = null; 

	public static void myControlUART(int n) {
		//Log.w(TAG, String.format("myControlUART %d", n));
		if(myListener != null) {
			myListener.ControlUART(n);
		}
	}
	
	public static void MsgToVga(int iparam1, int iparam2, int iparam3, 
			int iparam4, int iparam5, int iparam6, int iparam7, int iparam8,
			String strparam1, String strparam2, String strparam3, String strparam4) {

		KaraokeVGALib.recvMsgFromHDMI(iparam1, iparam2, iparam3,
				  iparam4, iparam5, iparam6, iparam7, iparam8,
				  strparam1, strparam2, strparam3, strparam4);
		return;
	}
	
	public static void InitAudioRecord() {
		Log.i(TAG, String.format("init audio rec, %d, %d", Karaoke.LocalSampleRate, monoFlag));
	}
	
	public static void InitAudioTrack() {
		Log.i(TAG, String.format("init audio track, %d", Karaoke.LocalSampleRateOut));

		int bufferSizeInBytes = AudioTrack.getMinBufferSize(Karaoke.LocalSampleRateOut * 100, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);  

		if(audioTrackJava == null)
		{
			if(bufferSizeInBytes < (4096 * 2 * 2))
			{
				bufferSizeInBytes = 4096 * 2 * 2;	
			}
			
			g_bufferSizeOutBytes = bufferSizeInBytes;
			try
			{		
				audioTrackJava = new AudioTrack(AudioManager.STREAM_MUSIC, Karaoke.LocalSampleRateOut * 100, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT, bufferSizeInBytes, AudioTrack.MODE_STREAM);
				audioTrackJava.setStereoVolume(1.0f, 1.0f);
				audioTrackJava.play();
			}
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
		}
	}
	
	public static void StopAudioTrack() {
		Log.i(TAG, String.format("StopAudioTrack"));
 		if(audioTrackJava != null) {
			audioTrackJava.stop();
			audioTrackJava.release();
			audioTrackJava = null;
		}
	}
	
	public static void StopAudioRecord() {
		Log.i(TAG, String.format("StopAudioRecord"));
	}
	
	public static void InitAudioRecordThread() {
		Recordthread = new Thread(new Runnable() {
            public void run() {
            	CurrentSamplerateRecord = Karaoke.LocalSampleRate;
            	//android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
				Log.i(TAG, String.format("1, %d, %d, %d", Karaoke.LocalSampleRate, nativeSamplerate, monoFlag));
				    
				if(monoFlag == 1) {
					mBuffersize= AudioRecord.getMinBufferSize(Karaoke.LocalSampleRate * 100,  AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
				} else {
					mBuffersize= AudioRecord.getMinBufferSize(Karaoke.LocalSampleRate * 100,  AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
				}
					
				Log.w(TAG, String.format("%d",mBuffersize));
			    if(mBuffersize < (4096 * 2 * monoFlag)) {
			    	mBuffersize = (4096 * 2 * monoFlag);
			    }
			    
			    g_bufferSizeInBytes = mBuffersize;
			    if(audioRecordJava == null) {
				    try {
				    	if(monoFlag == 1) {
				    		audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
				    				Karaoke.LocalSampleRate * 100, AudioFormat.CHANNEL_IN_MONO, 
				    					AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
						} else {
				    		audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
				    				Karaoke.LocalSampleRate * 100, AudioFormat.CHANNEL_IN_STEREO, 
				    					AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
				    	}
				    	Log.i(TAG, "Start Rec");
				    	
				    	audioRecordJava.startRecording(); //remove for voice
				    	audioRecordJava.stop(); //remove for voice
				    	
				    } catch(Exception e) {
			    	Log.i(TAG, "exception");
				    	e.printStackTrace();
				    	
				    	if(audioRecordJava != null) {
				    		audioRecordJava.stop();
				    		audioRecordJava.release();
				    		audioRecordJava = null;
				    	}
				    	
				    	Karaoke.singStatusChanged = 1;
				    	Karaoke.LocalSampleRate = 160;
				    	
				    	if(monoFlag == 1) {
				    		mBuffersize= AudioRecord.getMinBufferSize(Karaoke.LocalSampleRate * 100,  AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);	
				    		monoFlag = 2;
						} else {
				    		mBuffersize= AudioRecord.getMinBufferSize(Karaoke.LocalSampleRate * 100,  AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);					    		
				    		monoFlag = 1;
				    	}
				    	
				    	Log.i(TAG, String.format("mono2 %d",mBuffersize));
					    if(mBuffersize < (4096 * 2 * monoFlag))  {
					    	mBuffersize = (4096 * 2 * monoFlag);
					    }
					    g_bufferSizeInBytes = mBuffersize;
					    if(audioRecordJava == null) {
					    	if(monoFlag == 1) {
					    		audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
					    				Karaoke.LocalSampleRate * 100, AudioFormat.CHANNEL_IN_MONO, 
					    							AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
							} else {
					    		audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
					    				Karaoke.LocalSampleRate * 100, AudioFormat.CHANNEL_IN_STEREO, 
						    							AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
					    	}
					    }
				    }
			    }
            }
		});
		Recordthread.start();
	}
	
	public static void InitAudioTrackThread() {
		Trackthread = new Thread(new Runnable(){
            public void run() {
					int bufferSizeInBytes = AudioTrack.getMinBufferSize(Karaoke.LocalSampleRateOut * 100, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);  
					if(audioTrackJava == null){
						
					Log.w(TAG, String.format("bufferSizeInBytes%d",bufferSizeInBytes));
					if(bufferSizeInBytes < (4096 * 2 * 2)) {
						bufferSizeInBytes = (4096 * 2 * 2);	
					}
					g_bufferSizeOutBytes = bufferSizeInBytes;
					try {		
						audioTrackJava = new AudioTrack(AudioManager.STREAM_MUSIC, Karaoke.LocalSampleRateOut * 100, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT, bufferSizeInBytes, AudioTrack.MODE_STREAM);
						audioTrackJava.setStereoVolume(1.0f, 1.0f);
						//audioTrackJava.play();
					} catch(Exception e) {
				    	e.printStackTrace();
				    }
				}
			}
		});
		Trackthread.start();
	}
	
	public static void StopAudioTrackThread() {
		Log.i(TAG, String.format("StopAudioTrackThread"));
		Trackthread.stop();
 		if(audioTrackJava != null) {
			audioTrackJava.stop();
			audioTrackJava.release();
			audioTrackJava = null;
		}
	}
	
	public static void StopAudioRecordThread() {
		Log.i(TAG, String.format("StopAudioRecordThread"));
		Recordthread.stop();
 		if(audioRecordJava != null) {
 			audioRecordJava.stop();
 			audioRecordJava.release();
			audioRecordJava = null;
		}
	}
	
	public static void changeVolume(float leftVolume, float rightVoume) {
		if(audioTrackJava != null) {
			audioTrackJava.setStereoVolume(leftVolume, rightVoume);
		}
	}
	
	public static void changeRecordSampleRate(int SampleRate) {
		if(SampleRate != CurrentSamplerateRecord) {
		 	CurrentSamplerateRecord = SampleRate;
	 		new Thread(new Runnable(){
	 			public void run() {
	 				Recordthread.stop();
	 		 		if(audioRecordJava != null){
	 		 			audioRecordJava.stop();
	 		 			audioRecordJava.release();
	 		 			audioRecordJava = null;
	 				}
			 		if(audioRecordJava == null) {
				    	if(monoFlag == 1) {
				    		audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
				    				CurrentSamplerateRecord * 100, AudioFormat.CHANNEL_IN_MONO, 
				    					AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
						} else {
				    		audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
				    				CurrentSamplerateRecord * 100, AudioFormat.CHANNEL_IN_STEREO, 
				    					AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
				    	}
				    	Log.w(TAG, "Start Rec");
				    	audioRecordJava.startRecording();
			 		}		
	            }
	 		}).start();
		}
	}
	
	public static int audioCB(final byte[] mArr, final int offset, final int size) {
	    return audioTrackJava.write(mArr, offset, size);
	}
	
	public static int audioRecordRead(final byte[] mArr, final int size) {
	    return size;
	}
	
	public static int AudioTrackPlay(int n) {
		Log.i(TAG, String.format("AudioTrackPlay"));
		if(audioRecordJava != null) {
			audioRecordJava.startRecording();
		}
		if(audioTrackJava != null) {
			audioTrackJava.play();
		}
		return 0;
	}
	
	public static int AudioTrackPause(int n) {
		Log.i(TAG, String.format("AudioTrackPause"));
		if(audioTrackJava != null) {
			audioTrackJava.stop();
		}
		if(audioRecordJava != null) {
			audioRecordJava.stop();
		}
		return 0;
	}
	
	public static int MediaRecordStart() {
		try {
			// ①Initial：实例化MediaRecorder对象 
	        mMediaRecorder = new MediaRecorder();
	        // ②setAudioSource/setVedioSource
	        mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);//设置麦克风
	        // ②设置输出文件的格式：THREE_GPP/MPEG-4/RAW_AMR/Default
	         // THREE_GPP(3gp格式，H263视频/ARM音频编码)、MPEG-4、RAW_AMR(只支持音频且音频编码要求为AMR_NB)
	         //
	        mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
	        // ②设置音频文件的编码：AAC/AMR_NB/AMR_MB/Default 
	        mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
	        // ②设置输出文件的路径      
	        File mRecAudioPath = new File(Karaoke.HappyKTVFilePath + "/Rec");
	        try {
	            mRecAudioFile = File.createTempFile("rec_", ".amr", mRecAudioPath);
	        } catch (Exception e) {
	            e.printStackTrace(); 
	        }
	        CurrentRecFilePath = mRecAudioFile.getAbsolutePath();
	        mMediaRecorder.setOutputFile(CurrentRecFilePath);
	        // ③准备 
	        mMediaRecorder.prepare();
	        // ④开始 
	        mMediaRecorder.start();
		} catch(Exception e) {
			Log.w(TAG, "Record Init Fail");
		}
		
		return 0;
	}
	
	public static int MediaRecordEnd() {
		try {
        	if(mRecAudioFile != null) {
 	        	mMediaRecorder.stop();
 	        	// ⑥释放MediaRecorder 
 	        	mMediaRecorder.release();
 	        	mMediaRecorder = null;
 	        }
    	} catch(Exception e) {
    		e.printStackTrace();
    	}	
		return 0;
	}
	
	public static void simulateKey(final int KeyCode) {
		new Thread () {
			public void run () {
				try {
					Instrumentation inst=new Instrumentation();
					inst.sendKeyDownUpSync(KeyCode);
				} catch(Exception e) {
					Log.e("Exception when sendKeyDownUpSync", e.toString());
				}
			}
		}.start();
	}
	
	static int SetSystemVol(int intvol) {
		boolean mute = (intvol==0)? true:false;
		if(mute != MainActivity.mAudioManager.isStreamMute(AudioManager.STREAM_MUSIC)) {
			MainActivity.mAudioManager.setStreamMute(AudioManager.STREAM_MUSIC, mute);
		}
		
		if(!mute) {
			int maxvol = MainActivity.mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
			int setvol = intvol *  maxvol / 100;
			MainActivity.mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, setvol, 0);
			return setvol;
		}
		
		return 0;
	}
	
	//render
    public static native int init(int width, int height, String sopath, String sourcepath);
    public static native short step();
    public static native void exit();

	// Keyboard and motion input
	public static native void queueKeyEvent(int key, int state);
	public static native void queueMotionEvent(int action, float x, float y, float pressure);
	public static native void queueTrackballEvent(int action, float x, float y);

	//status
	public static native boolean isInitFinish();
	public static native void setStatus(int TypeID, int nNum, int nType);
    public static native void setEnv(int nsample, int mono, int minBufferSize, int minBufferInSize, int nsampleOut);
        
    public static native String getWebUrl(int FileID);
    public static native String getGLString(int type, int FileID);
    public static native void setGLString(int type, int FileID, String glString);
    public static native int getSongScore(int FileID);

    public static native void initMultakDevice();
    public static native void removeMultakDevice(int type, String path);
    public static native void addMultakDevice(int type, String path);
    public static native void restartMultakDevice();

    public static native void setNetworkState(int state);
	public static native void setMediaStatus(int TypeID, int status, int errorcode);
	public static native void setOFN(int flag);
	public static native void setMute(boolean flag);

	public static native void addCameraPic(String _path);
	public static native String getHotSpotName();
	public static native String getHotSpotPassword();
	
	public static native void recvMsgFromVGA(int iparam1, int iparam2, int iparam3,
			int iparam4, int iparam5, int iparam6, int iparam7,  int iparam8,
			String strparam1, String strparam2, String strparam3, String strparam4);
}
