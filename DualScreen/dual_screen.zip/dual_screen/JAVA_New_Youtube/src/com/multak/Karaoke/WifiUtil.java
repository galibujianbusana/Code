package com.multak.Karaoke;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;

public class WifiUtil {  
		  
	    public static final int WIFI_AP_STATE_DISABLING = 10;  
	    public static final int WIFI_AP_STATE_DISABLED = 11;  
	    public static final int WIFI_AP_STATE_ENABLING = 12;  
	    public static final int WIFI_AP_STATE_ENABLED = 13;  
	    public static final int WIFI_AP_STATE_FAILED = 14;  
	    
	    public boolean stratWifiAp(WifiManager wifiManager, String name, String password) {
	        Method method1 = null;  
	        try {  
	            method1 = wifiManager.getClass().getMethod("setWifiApEnabled", WifiConfiguration.class, boolean.class);  
	            WifiConfiguration netConfig = new WifiConfiguration();
	            netConfig.SSID = name;  
	            netConfig.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);  
	            netConfig.allowedProtocols.set(WifiConfiguration.Protocol.RSN);  
	            netConfig.allowedProtocols.set(WifiConfiguration.Protocol.WPA);  
	            netConfig.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);  
	            netConfig.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);  
	            netConfig.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);  
	            netConfig.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);  
	            netConfig.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
	            netConfig.preSharedKey = password;  
	            method1.invoke(wifiManager, netConfig, true);
	            return true;
	        } catch (Exception e) {  
	            // TODO Auto-generated catch block   
	            e.printStackTrace();  
	            return false;
	        }
	    }  
	  
	    public void closeWifiAp(WifiManager wifiManager) {
			if (getWifiApState(wifiManager) == WIFI_AP_STATE_ENABLED) {
				try {
					Method method = wifiManager.getClass().getMethod("getWifiApConfiguration");
					method.setAccessible(true);
					WifiConfiguration config = (WifiConfiguration) method.invoke(wifiManager);
					
					Method method2 = wifiManager.getClass().getMethod("setWifiApEnabled", WifiConfiguration.class, boolean.class);
					method2.invoke(wifiManager, config, false);
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	    
	    public int getWifiApState(WifiManager wifiManager) {  
	        try {  
	            Method method = wifiManager.getClass().getMethod("getWifiApState");  
	            int i = (Integer) method.invoke(wifiManager);  
	            //Log.i("wifi state:  " + i);  
	            return i;  
	        } catch (Exception e) {  
	            //Log.i("Cannot get WiFi AP state" + e);  
	            return WIFI_AP_STATE_FAILED;  
	        }  
	    }  
	}