package com.multak.Karaoke;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

public class SystemUt {


	/**
	 * 0 相等�?1大于�?-1 小于
	 * 
	 * @param p1
	 * @param p2
	 * @return
	 */
	public static int compareToVersion(String version1, String version2) {
		/*String[] _Version1 = version1.split("\\.");
		String[] _Version2 = version2.split("\\.");
		if (_Version1.length != 2 || _Version2.length != 2) {
			Log.i("TestDownload", "服务器：" + version1 + " 当前�?" + version2 + " ret 0");
			return 0;
		}
		int v1 = Integer.parseInt(_Version1[0]) * 1000 + Integer.parseInt(_Version1[1]);
		int v2 = Integer.parseInt(_Version2[0]) * 1000 + Integer.parseInt(_Version2[1]);
		*/
		String[] _Version1 = version1.split("v|\\.");
		String[] _Version2 = version2.split("v|\\.");
		if (_Version1.length != 3 || _Version2.length != 3) {
			Log.i("TestDownload", "服务器：" + version1 + " 当前�?" + version2 + " ret 0");
			return 0;
		}
		int v1 = Integer.parseInt(_Version1[1]) * 1000 + Integer.parseInt(_Version1[2]);
		int v2 = Integer.parseInt(_Version2[1]) * 1000 + Integer.parseInt(_Version2[2]);
		if (v1 > v2) {
			Log.i("TestDownload", "服务器：" + version1 + " 当前�?" + version2 + "  v1:" + v1 + "  v2:" + v2 + "  ret:1");
			return 1;
		} else if (v1 < v2) {
			Log.i("TestDownload", "服务器：" + version1 + " 当前�?" + version2 + "  v1:" + v1 + "  v2:" + v2 + "  ret:-1");
			return -1;
		}
		Log.i("TestDownload", "服务器：" + version1 + " 当前�?" + version2 + "  v1:" + v1 + "  v2:" + v2 + "  ret:0");
		return 0;

	}

	public static void installApk(String path, final Context mContxt) {
		Intent intent = new Intent();
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);  
		Log.e("installApk", "file.exists()true"); 
		intent.setAction(Intent.ACTION_VIEW);
		intent.setDataAndType(Uri.fromFile(new File(path)), "application/vnd.android.package-archive");
		mContxt.startActivity(intent);
	}


	public static String getHTML(String url) {
		try {
			URL newUrl = new URL(url);
			URLConnection connect = newUrl.openConnection();
			connect.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
			DataInputStream dis = new DataInputStream(connect.getInputStream());
			BufferedReader in = new BufferedReader(new InputStreamReader(dis, "UTF-8"));// 目标页面编码为UTF-8
			String html = "";
			String readLine = null;
			while ((readLine = in.readLine()) != null) {
				html = html + readLine+"\n";
			}
			in.close();
			 Log.i("TestDownload","html:\n"+html);
			return html;
		} catch (Exception me) {
			
		}
		
		return "";
	}

	public static String getHTML1(String uri) {
		try {
			URL newUrl = new URL(uri);
			URLConnection connect = newUrl.openConnection();
			connect.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
			DataInputStream dis = new DataInputStream(connect.getInputStream());
			BufferedReader in = new BufferedReader(new InputStreamReader(dis, "UTF-8"));// 目标页面编码为UTF-8
			String html = "";
			String readLine = null;
			while ((readLine = in.readLine()) != null) {
				html = html + readLine;
			}
			in.close();
			 Log.i("TestDownload","html:\n"+html);
			return html;
		} catch (Exception me) {
			
		}
		
		return "";
	}

	
	
	
	
	public static boolean HTMLDownload(String url,String fpath) {
		try {
			URL newUrl = new URL(url);
			File file = new File(fpath);
			boolean update = false;
			byte[] bytes = new byte[1024];
			URLConnection connect = newUrl.openConnection();
			byte[] buf2 = new byte[16];
			InputStream input=connect.getInputStream();
			OutputStream output=null; 
			String cmp1;
			String cmp2;
			/*
			if(file.exists() == false)
			{	
				update = true;
			//	input.read(buf2);
			}
			else
			{
				BufferedReader in = new BufferedReader(new FileReader(file));
				char[] buf1 = new char[16];
				in.read(buf1);
				cmp1 = buf1.toString();
				Log.i("TestDownload","local list file info " + cmp1);
				
				
				//input.read(buf2);
				cmp2 = buf2.toString();
				Log.i("TestDownload","server list file info " + cmp2);
				
				
				
				if(cmp1 != cmp2)
					update = true;
			}
			*/
			//if(update == true)
			{
				if(file.exists())
				{
					file.delete();
				}	
				file.createNewFile();
				output=new FileOutputStream(file);
			//	output.write(buf2,0,16);
				int len;
				while ((len=input.read(bytes))!= -1) {
					output.write(bytes,0,len);
				}
				output.flush(); 
			}
			//else
			//	Log.i("TestDownload","same version,no need update");
			
			//connect.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
			//DataInputStream dis = new DataInputStream(connect.getInputStream());
			//BufferedReader in = new BufferedReader(new InputStreamReader(dis, "UTF-8"));// 目标页面编码为UTF-8
			//BufferedWriter out = new BufferedWriter(new FileWriter(file));
			//int len = 0;
			//while( (len = in.read(bytes))!= -1)
			//{
			//	out.write(bytes);
			//}
			//String html = "";
			//String readLine = null;
			//while ((readLine = in.readLine()) != null) {
			//	html = html + readLine+"\n";
			//}
			//in.close();
			//out.close();
			
			// Log.i("TestDownload","html:\n"+html);
			return true;
		} catch (Exception me) {
			Log.e("TestDownlaod",me.getMessage());
		}
		
		return false;
	}
	
}
