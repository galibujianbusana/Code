package com.multak.Karaoke;

import android.app.Activity;
import android.content.Context;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.android.grafika.gles.EglCore;
import com.android.grafika.gles.WindowSurface;
import com.google.android.youtube.player.YouTubePlayerView;
import com.multak.MK8507MOA.R;
import com.multak.server.CustomerInfo;
import com.multak.server.OKSServer;
import com.multak.Karaoke.JavaVideoLib;
import com.squareup.picasso.Picasso;

public class KaraokeVGA {
	private static String TAG = "KaraokeVGA";
	private Context mcontext;
	
	//karaoke view
	//public static GLSurfaceView mGLSurfaceViewEx = null;
	public static SurfaceView mGLSurfaceViewEx2 = null;
	public static KaraokeRendererEx2 mRendererEx2 = null;
	private static EglCore mEglCoreVGA;
	public static WindowSurface mDisplayUIVGA;
	
	public static SurfaceView mVideoPreviewView = null;
	public static SurfaceView mVideoSurfaceViewEx = null;
	private static MediaPlayer mMediaPlayer = null;
	
	private static ImageView mProgress = null;
	public static ImageView mYoutubeTitle = null;
	public static FrameLayout mYoutubeView = null;
	
	private static Animation mProgressRotate = null;
    private static boolean mProgressNeedRefresh = true;

    public static ProgressBar mProgrressBar;  
    
    public static YouTubePlayerView mYouTubePlayerView_ex = null;
    
	private static Handler mHandler = new Handler();
	public static String previewURL = "";
	public KaraokeVGA(Context context) {
		mcontext = context;
	}
	
	public void initKaraokeView() {
    	//mGLSurfaceViewEx = (GLSurfaceView) ((Activity) mcontext).findViewById(R.id.karaokeView_Vga);
		//KaraokeRendererEx kr = new KaraokeRendererEx(mcontext);
		//mGLSurfaceViewEx.setRenderer(kr);
		mEglCoreVGA = new EglCore(null, EglCore.FLAG_RECORDABLE);
		mGLSurfaceViewEx2 = (SurfaceView) ((Activity) mcontext).findViewById(R.id.karaokeView_Vga);
		mGLSurfaceViewEx2.setZOrderMediaOverlay(true);
		if (mGLSurfaceViewEx2 != null) {
			mGLSurfaceViewEx2.getHolder().setFormat(PixelFormat.TRANSPARENT);
			mGLSurfaceViewEx2.getHolder().addCallback(new SurfaceHolder.Callback() {
                public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                    Log.v(TAG, "vgaui format=" + format + ", width=" + width + ", height=" + height);
                }
                
                public void surfaceCreated(SurfaceHolder holder) {
                    Log.v(TAG, "vgaui create");
                    mDisplayUIVGA = new WindowSurface(mEglCoreVGA, holder.getSurface(), false);
                    mRendererEx2 = new KaraokeRendererEx2(mcontext);
                }

                public void surfaceDestroyed(SurfaceHolder holder) {
                    Log.v(TAG, "surfaceDestroyed");
                }
            });
     	}
		startVGARenderThread();
		
		mVideoSurfaceViewEx = (SurfaceView) ((Activity) mcontext).findViewById(R.id.mediaplayerEx_view);
		JavaVideoLib.setDoubleScreen(true, mVideoSurfaceViewEx);
		
		mVideoPreviewView = (SurfaceView) ((Activity) mcontext).findViewById(R.id.mediaplayer_view);
		mVideoPreviewView.setZOrderOnTop(true);
		mVideoPreviewView.setVisibility(View.VISIBLE);
		
		mProgress = (ImageView) ((Activity) mcontext).findViewById(R.id.progress_view);
		mProgress.setVisibility(View.INVISIBLE);
		mProgressRotate = AnimationUtils.loadAnimation(mcontext, R.anim.rotate);
		
		//0313
		mYoutubeView = (FrameLayout)((Activity)mcontext).findViewById(R.id.youtube_view);
		
		mYoutubeTitle = (ImageView)((Activity)mcontext).findViewById(R.id.youtube_title);
		SetYoutubteTitleMin();
		
		mYoutubeView.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Log.i("YouTube","mYoutubeView onClick");
				android.widget.FrameLayout.LayoutParams lp = (android.widget.FrameLayout.LayoutParams) mYoutubeView.getLayoutParams();
				if(lp.width > 446){
					lp.width = 446;
					lp.height = 233;
					lp.leftMargin = 814;
			    	lp.topMargin = 20;
				}else{
					lp.width = 1280;
					lp.height = 720;
					lp.leftMargin = 0;
			    	lp.topMargin = 0;
					
				}
				mYoutubeView.setLayoutParams(lp);
			}
			
		});
		
		
		//Uri uri = Uri.parse("https://i.ytimg.com/vi/xCOOlXvuo14/0.jpg");
		
		//Log.i("mYoutubeTitle","mYoutubeTitle");
		//Picasso.with(mYoutubeTitle.getContext()).load(uri).placeholder(R.drawable.loading_thumbnail).error(R.drawable.no_thumbnail).into(mYoutubeTitle);
		
		
		mProgrressBar = (ProgressBar) ((Activity) mcontext).findViewById(R.id.progressBar1);
		//mProgrressBar.setVisibility(View.VISIBLE);
		//mProgrressBar.setVisibility(View.INVISIBLE);
		
		//mYouTubePlayerView_ex = new YouTubePlayerView(mcontext);
		//((FrameLayout)((Activity) mcontext).findViewById(R.id.YoutubeEx_view)).addView(mYouTubePlayerView_ex);
		//Karaoke.mYoutubeService.setYoutubeView_ex(mYouTubePlayerView_ex);
		//mYouTubePlayerView_ex.setVisibility(View.INVISIBLE);
		
		
		KaraokeVGALib.setEnv();
	}	
	public static void SetYoutubteTitleMin()
	{
		android.widget.FrameLayout.LayoutParams lp = (android.widget.FrameLayout.LayoutParams) mYoutubeView.getLayoutParams();
		Log.i("YouTube","lp min" + lp.width + " " + lp.height + " " + lp.leftMargin + " " + lp.topMargin);
		lp.width = 1;
		lp.height = 1;
		mYoutubeView.setLayoutParams(lp);
	}
	public static void SetYoutubteTitleNorm()
	{
		android.widget.FrameLayout.LayoutParams lp = (android.widget.FrameLayout.LayoutParams) mYoutubeView.getLayoutParams();
		Log.i("YouTube","lp norm" + lp.width + " " + lp.height + " " + lp.leftMargin + " " + lp.topMargin);
		lp.width = 446;
		lp.height = 233;
		lp.leftMargin = 814;
    	lp.topMargin = 20;
		mYoutubeView.setLayoutParams(lp);
	}
	public static void SetYoutubteTitleMax()
	{
		android.widget.FrameLayout.LayoutParams lp = (android.widget.FrameLayout.LayoutParams) mYoutubeView.getLayoutParams();
		lp.width = 1280;
		lp.height = 720;
		lp.leftMargin = 0;
    	lp.topMargin = 0;
		mYoutubeView.setLayoutParams(lp);
	}
	public void startVGARenderThread() {
		new Thread(new Runnable() {
			public void run() {
				while(mRendererEx2 == null) {
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				if (mGLSurfaceViewEx2 != null) {
					mDisplayUIVGA.makeCurrent();
					mRendererEx2.onSurfaceChanged(1, mGLSurfaceViewEx2.getWidth(), mGLSurfaceViewEx2.getHeight());
					mDisplayUIVGA.swapBuffers();
				}
				
				while(true) {
					if(Karaoke.bgPicExit == true) {
						if(mDisplayUIVGA != null) {
							mDisplayUIVGA.release();
							mDisplayUIVGA = null;
						}
						if(mEglCoreVGA != null) {
							mEglCoreVGA.release();
							mEglCoreVGA = null;
						}
						break;
					}
					try {
						Thread.sleep(10);
						if (mGLSurfaceViewEx2 != null ) {
							mDisplayUIVGA.makeCurrent();
							mRendererEx2.onDrawFrame(1); //������Sleep
							mDisplayUIVGA.swapBuffers();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
	}
	
	// video preview 
	private static void setProgressEnable(boolean arg0) {
		if(arg0) {
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					if(mProgress != null) {
						mProgress.setVisibility(View.VISIBLE);
						mProgress.startAnimation(mProgressRotate);
						if(mProgressNeedRefresh) {
							mProgressNeedRefresh = false;
							mProgress.requestLayout();
						}
					}
				}
			});
		} else {
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					if(mProgress != null) {
						mProgress.clearAnimation();
						mProgress.setVisibility(View.INVISIBLE);
					}
				}
			});
		}
	}
	public static void mm_myControlUARTSnd(int n)
	{
		KaraokeVGALib.mmm_myControlUARTSnd(n);
	}
	
	public static void stoppreview()
	{
		if(mMediaPlayer != null) {
			mMediaPlayer.stop();
			mMediaPlayer.reset();
			mMediaPlayer.release();
			mMediaPlayer = null;
			previewURL = "";
			KaraokeVGALib.setGLString(10, 0, "");
		}
	}
	private static String mVideoUrl;
	public void startPreview() {
		Log.d(TAG, "startPreview");
	
		if(mMediaPlayer == null) {
			mMediaPlayer = new MediaPlayer();
			if(mMediaPlayer == null || mVideoPreviewView == null) {
				return;
			}
			
			mMediaPlayer.setOnInfoListener(new OnInfoListener() {
				@Override
				public boolean onInfo(MediaPlayer arg0, int arg1, int arg2) {
					// TODO Auto-generated method stub
					if (arg1 == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
						setProgressEnable(true);
					} else if (arg1 == MediaPlayer.MEDIA_INFO_BUFFERING_END) {
						setProgressEnable(false);
					}
					return false;
				}
			});
			
			mMediaPlayer.setOnErrorListener(new OnErrorListener() {
				@Override
				public boolean onError(MediaPlayer mp, int what, int extra) {
					// TODO Auto-generated method stub
					Log.d(TAG, "onError");
					deinitPreview();
					return false;
				}
			});

			mMediaPlayer.setOnPreparedListener(new OnPreparedListener() {
				public void onPrepared(MediaPlayer mp) {
					// TODO Auto-generated method stub
					Log.d(TAG, "onPrepared");
					mMediaPlayer.setParameter(0x208, 3);
					mMediaPlayer.start();
					KaraokeVGALib.setVideoStatus(3, 0);
				}
			});

			mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
				@Override
				public void onCompletion(MediaPlayer arg0) {
					// TODO Auto-generated method stub
					Log.d(TAG, "onCompletion");
					deinitPreview();
				}   
			}); 
			
			mMediaPlayer.setDisplay(mVideoPreviewView.getHolder());
			mMediaPlayer.setScreenOnWhilePlaying(true);
			try {
				mVideoUrl = KaraokeVGALib.getWebUrl(3);
				if(mVideoUrl.startsWith("/mnt")) {
					previewURL = mVideoUrl;
					KaraokeVGALib.setGLString(10, 0, previewURL);
					//mMediaPlayer.setDataSource(mcontext, Uri.parse(mVideoUrl), null);
					//mMediaPlayer.prepareAsync();
					//Log.i("preview","previewRUL " + mVideoUrl + " playingURL " + JavaVideoLib.PlayingURL);
					//Log.i("preview","previewRUL len " + mVideoUrl.length() + " playingURL len " + JavaVideoLib.PlayingURL.length());
					
					
					//if(JavaVideoLib.PlayingURL.equals(previewURL) == true)
					//{
					//	Log.w(TAG,"same URL,skip");
					//	return;
					//}
					
					if(mVideoUrl.endsWith(".OKF") || mVideoUrl.endsWith(".okf"))
					{
						Log.i("OKServer","Geturl = " + mVideoUrl);
		        		CustomerInfo.SetCommonKey("af8893c5");
		        		//CustomerInfo.SetDecodeKey("MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKRffOFS2gljPZa8FVMi+yL0yBUZCIFsDs0KTL3wNQ0gSMJeoTNb13InPUxxvy9F1jdePenXxf/KoE46AJM/q3rf3qD0o/3XjklVnzYNgLZ7W6aCvLRnNeNY5j+9yrABYVRbLaUgWySegH6SBLnsjtMZmWchrSzLDEPtYlJoowwBAgMBAAECgYAEISwDgy/cJYSiGVaV0J6rmae/M/JNQhg7GYOlD/hdPI7nZzY4kpmekhLNrVvmxaPknzcB/XxJeV8+p+Fk0aguszodYigki6gieruXpoBYKTA6bDhnjlgx7g3jOfpaba7v9Lr5bTbt05vLhYG9B45dN1ro5LFP0rlnE505+RB0gwJBAOYLx//njOO3BLj5Ctx5/fs+9qzxS0leAnxUyE06N4Zt5HYGx/Gkz7l4LxYjGCAjrMj1qNbewIr60fNuWYZby3MCQQC26u4PKfJEMlvggWphTdQD+jr/uUEKmi/2e/dr9xpUpUk7YIXtlod/e/fmqBkpkYLeut8VNgx32dBZ1n61RxW7AkBHESCqB8hYmLOWySj3z6AMu/jMmIZflfFCo5Z1dSSuHMjVRWcDWZzqeRxixFixpRO9yVZtescUqEOv5kk13qnNAkB2JIz3/Fa+12viOJRWHqeWnhNnQecRiv75i54F/Mbj7xG6qSA3kWcY3yABuYbvA03sv/QARjWNX4Cj1ddnDG+rAkEAiATC1mgz7nOmnBlTypKyfaCK+cEbnrFXeRePKIcT+08y1spX9D1ivZ+8dXLsNSfM1GS9TNCYav9yrVXVcSyxxA==");
		        		//Log.i("OKServer","Server url = " + OKSServer.getUriFromFileOKF(mVideoUrl, "MTVServer1"));
		        		String url = OKSServer.getUriFromFileOKF(mVideoUrl, "MTVServer1");
		        		Log.i("OKServer","Server url = " + url);
		        		mMediaPlayer.setDataSource(mcontext, Uri.parse(url), null);
					}
					else
						mMediaPlayer.setDataSource(mcontext, Uri.parse(mVideoUrl), null);
					
					mMediaPlayer.prepareAsync();
					
				} else {
					setProgressEnable(true);
					new Thread(new Runnable() {
						@Override
						public void run() {
							// TODO Auto-generated method stub
							Log.w("YouTube", mVideoUrl);
							try {
								String VideoID = mVideoUrl;
								String url = "";
								for(int i = 0; i < 3; i++) {
									url = Karaoke.mYoutubeService.calculateYouTubeUrl(mVideoUrl);
									//url = Karaoke.mYoutubeService.GetYoutbeWebUrl(mVideoUrl);
									if(!url.equals("")) {
										break;
									}
								}
								if(mMediaPlayer != null && VideoID == mVideoUrl) {
								//	mMediaPlayer.setDataSource(mcontext, Uri.parse(url), null);
								//	mMediaPlayer.prepareAsync();
									
									setProgressEnable(false);
								}
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								deinitPreview();
							}
						}
					}).start();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void stopPreview() {
		Log.d(TAG, "stopPreview");
		if(mMediaPlayer != null) {
			mMediaPlayer.stop();
			deinitPreview();
		}
	}
	
	private static void deinitPreview() {
		setProgressEnable(false);
		mProgressNeedRefresh = true;
		if(mMediaPlayer != null) {
			mMediaPlayer.reset();
			mMediaPlayer.release();
			mMediaPlayer = null;
			mVideoPreviewView.setVisibility(View.INVISIBLE);
			mHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					mVideoPreviewView.setVisibility(View.VISIBLE);
				}			
			}, 500);
		}
		KaraokeVGALib.setVideoStatus(3, 1);
		previewURL = "";
		KaraokeVGALib.setGLString(10, 0, "");
	}
}
