/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.multak.Karaoke;

import javax.microedition.khronos.opengles.GL10;
import com.multak.MultakStandard.BaseHelper;

import android.content.Context;
import android.opengl.EGLConfig;
import android.util.Log;

public class KaraokeRendererEx2{
    private static String TAG = "KaraokeRendererEx";
	private int m_width;
	private int m_height;
	private String RootDirName = Karaoke.HappyKTVFilePath;
	
	enum EMULShellState {
		eMULShellInitApp,
		eMULShellInitInstance,
		eMULShellRender,
		eMULShellReleaseView,
		eMULShellReleaseOS,
		eMULShellQuitApp,
		eMULShellExit
	};
	
	private static EMULShellState m_AllStates[] = {
		EMULShellState.eMULShellInitApp, 
		EMULShellState.eMULShellInitInstance,
		EMULShellState.eMULShellRender,
		EMULShellState.eMULShellReleaseView,
		EMULShellState.eMULShellReleaseOS,
		EMULShellState.eMULShellQuitApp,
		EMULShellState.eMULShellExit
	};
	
	EMULShellState m_state;
	EMULShellState m_laststate = EMULShellState.eMULShellExit;
	int nGameType;
	
	private Context mContext;
    	
    public KaraokeRendererEx2(Context context) {
    	mContext = context;
    }
    
    public void SetListener(MyListener listener) {
    	
	}

    public void onDrawFrame(int flag) {
    	if(Karaoke.RenderStatusEx == 0)
    		return;
    	short r = KaraokeVGALib.step();
    	if(r < 0xFF && r >= 0) {
    		//BaseHelper.log(TAG, String.format("GameStep %d", r));
        	m_state = m_AllStates[r];
        	if(m_laststate != m_state) {
        		BaseHelper.log(TAG, String.format("GameStep %d", r));
        		m_laststate = m_state;
        		
        		if(m_state == EMULShellState.eMULShellExit) {
        			KaraokeVGALib.exit();
        		}
        	}
    	} else {
    		Log.w(TAG, String.format("Game init"));
    		if(Karaoke.m_SkyKTVStateEx == Karaoke.SkyKTVState.SkyKTV_Init) {
    			nGameType = KaraokeVGALib.init(m_width, m_height, "", RootDirName);
    			KaraokeVGALib.setStatus(6,803,464);
    			Karaoke.m_SkyKTVStateEx = Karaoke.SkyKTVState.SkyKTV_Start;
    		}
    	}
    }

    public void onSurfaceChanged(int flag, int width, int height) {
        // Ignore the passed-in GL10 interface, and use the GLES20
        // class's static methods instead.
    	Log.w(TAG, String.format("W: %d, H: %d", width, height));
    	
    	m_width = width;
    	m_height = height;

    	if(m_width < m_height) {
    		
    	} else {
    		if(Karaoke.m_SkyKTVStateEx != Karaoke.SkyKTVState.SkyKTV_Start) {
    			Log.w(TAG, "Karaoke.m_SkyKTVStateEx != Karaoke.SkyKTVState.SkyKTV_Start");
	    		Karaoke.m_SkyKTVStateEx = Karaoke.SkyKTVState.SkyKTV_Init;
    		}
    	}
    }

    public void onSurfaceCreated(GL10 glUnused, EGLConfig config) {
    	Log.w(TAG, "onSurfaceCreated");
 
    }
}
