package com.multak.Karaoke;

import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;

import com.multak.MultakStandard.BaseHelper;

public class KaraokeViewEx extends GLSurfaceView {
    private static String TAG = "Karaoke";
    private static final boolean DEBUG = false;
	protected boolean useSoftInput = false;
	protected boolean hideSoftInputWhenDone = true;
	private Context mContext;
	
    //XML define
    public KaraokeViewEx(Context context,AttributeSet paramAttributeSet) {
    	super(context, paramAttributeSet);
    	mContext = context;
    	init(true, 8, 8);
    }
    
    public KaraokeViewEx(Context context) {
        super(context);
        mContext = context;
        init(true, 8, 8);
    }

    public KaraokeViewEx(Context context, boolean translucent, int depth, int stencil) {
        super(context);
        mContext = context;
        init(translucent, depth, stencil);
    }
    
	int flag = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		Log.d("Key", "onKeyDown=" + keyCode + " " + event.getDisplayLabel() + " " + event.getUnicodeChar() + " " + event.getNumber());
		return false;
	}
	
	public boolean onTouchEvent(MotionEvent event) {
		/* Perhaps we should pass integers down to reduce the number of float computations */
		//Log.d("Key", "onTouchEvent action=" + event.getAction() + " x=" + event.getX() + " y=" + event.getY() + " pressure=" + event.getPressure() + "size = " + event.getSize());		
		return queueMotionEvent(event.getAction(), event.getX(), event.getY(), event.getPressure());
	}

	
	public boolean onTrackballEvent(MotionEvent event) {
		//Log.d("Key", "onTrackballEvent action=" + event.getAction() + " x=" + event.getX() + " y=" + event.getY());
		return queueTrackballEvent(event.getAction(), event.getX(), event.getY());
	}
	

	public boolean queueKeyEvent(final int qKeyCode, final int state) {
		if(qKeyCode == 0) 
			return true;

		/* Make sure all communication with Quake is done from the Renderer thread */
        queueEvent(new Runnable() {
            public void run() {
            	KaraokeVGALib.queueKeyEvent(qKeyCode, state);
            }
        });
        return true;
	}

	private boolean queueMotionEvent(final int action, final float x, final float y, final float pressure)
	{
		/* Make sure all communication with Quake is done from the Renderer thread */
        queueEvent(new Runnable(){
            public void run() {
            	KaraokeVGALib.queueMotionEvent(action, x, y, pressure);
            }
        });
        return true;
	}
	
	private boolean queueTrackballEvent(final int action, final float x, final float y)
	{
		/* Make sure all communication with Quake is done from the Renderer thread */
        queueEvent(new Runnable() {
            public void run() {
            	KaraokeVGALib.queueTrackballEvent(action, x, y);
            }
        });
        return true;
	}

	private int androidKeyCodeToMultak(int aKeyCode, KeyEvent event) {	
		/* Convert non-ASCII keys by hand */
		switch(aKeyCode) {
			/* For now map the focus buttons to F1 and let the user remap it in game.
			 * This should allow some basic movement on the Nexus One if people map it to forward.
			 * At least on the Milestone the camera button itself is shared with the Focus one. You have
			 * to press focus first and then you hit camera, this leads to the following event sequence which
			 * I don't handle right now: focus_down -> camera_down -> camera_up -> focus_up.
			 */
		}

		/* Let Android do all the character conversion for us. This way we don't have
		 * to care about modifier keys and specific keyboard layouts.
		 * TODO: add some more filtering
		 */
		int uchar = event.getUnicodeChar();
		if(uchar < 127)
			return uchar;

		return 0;
	}

    private void init(boolean translucent, int depth, int stencil) {

    	/* By default, GLSurfaceView() creates a RGB_565 opaque surface.
         * If we want a translucent one, we should change the surface's
         * format here, using PixelFormat.TRANSLUCENT for GL Surfaces
         * is interpreted as any 32-bit surface with alpha by SurfaceFlinger.
         */
    	this.getHolder().setFormat(PixelFormat.TRANSLUCENT);

        /* Setup the context factory for 2.0 rendering.
         * See ContextFactory class definition below
         */
        setEGLContextFactory(new ContextFactory());

        /* We need to choose an EGLConfig that matches the format of
         * our surface exactly. This is going to be done in our
         * custom config chooser. See ConfigChooser class definition
         * below.
         */
        setEGLConfigChooser(translucent ?
                             new ConfigChooser(8, 8, 8, 8, depth, stencil) :
                             new ConfigChooser(5, 6, 5, 0, depth, stencil) );
    }
    
    private static class ContextFactory implements GLSurfaceView.EGLContextFactory {
        private static int EGL_CONTEXT_CLIENT_VERSION = 0x3098;
        public EGLContext createContext(EGL10 egl, EGLDisplay display, EGLConfig eglConfig) {
            BaseHelper.log(TAG, "creating OpenGL ES 2.0 context");
            checkEglError("Before eglCreateContext", egl);
            int[] attrib_list = {EGL_CONTEXT_CLIENT_VERSION, 2, EGL10.EGL_NONE };
            EGLContext context = egl.eglCreateContext(display, eglConfig, EGL10.EGL_NO_CONTEXT, attrib_list);
            checkEglError("After eglCreateContext", egl);
            return context;
        }

        public void destroyContext(EGL10 egl, EGLDisplay display, EGLContext context) {
            egl.eglDestroyContext(display, context);
        }
    }

    private static void checkEglError(String prompt, EGL10 egl) {
        int error;
        while ((error = egl.eglGetError()) != EGL10.EGL_SUCCESS) {
            Log.e(TAG, String.format("%s: EGL error: 0x%x", prompt, error));
        }
    }

    private static class ConfigChooser implements GLSurfaceView.EGLConfigChooser {

        public ConfigChooser(int r, int g, int b, int a, int depth, int stencil) {
            mRedSize = r;
            mGreenSize = g;
            mBlueSize = b;
            mAlphaSize = a;
            mDepthSize = depth;
            mStencilSize = stencil;
        }

        /* This EGL config specification is used to specify 2.0 rendering.
         * We use a minimum size of 4 bits for red/green/blue, but will
         * perform actual matching in chooseConfig() below.
         */
  
        private static int EGL_OPENGL_ES2_BIT = 4;
        private static int[] s_configAttribs2 =
        {
            EGL10.EGL_RED_SIZE, 8,
            EGL10.EGL_GREEN_SIZE, 8,
            EGL10.EGL_BLUE_SIZE, 8,
            EGL10.EGL_ALPHA_SIZE, 8,
            EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
            EGL10.EGL_NONE
        };

        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {

            /* Get the number of minimally matching EGL configurations
             */
            int[] num_config = new int[1];
            egl.eglChooseConfig(display, s_configAttribs2, null, 0, num_config);

            int numConfigs = num_config[0];

            if (numConfigs <= 0) {
                throw new IllegalArgumentException("No configs match configSpec");
            }
 
            /* Allocate then read the array of minimally matching EGL configs
             */
            EGLConfig[] configs = new EGLConfig[numConfigs];
            egl.eglChooseConfig(display, s_configAttribs2, configs, numConfigs, num_config);

            if (DEBUG) {
                 printConfigs(egl, display, configs);
            }
            /* Now return the "best" one
             */
            return chooseConfig(egl, display, configs);
        }

        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
            for(EGLConfig config : configs) {
                int d = findConfigAttrib(egl, display, config,
                        EGL10.EGL_DEPTH_SIZE, 0);
                int s = findConfigAttrib(egl, display, config,
                        EGL10.EGL_STENCIL_SIZE, 0);

                // We need at least mDepthSize and mStencilSize bits
                if (d < mDepthSize || s < mStencilSize)
                    continue;

                // We want an *exact* match for red/green/blue/alpha
                int r = findConfigAttrib(egl, display, config, EGL10.EGL_RED_SIZE, 0);
                int g = findConfigAttrib(egl, display, config, EGL10.EGL_GREEN_SIZE, 0);
                int b = findConfigAttrib(egl, display, config, EGL10.EGL_BLUE_SIZE, 0);
                int a = findConfigAttrib(egl, display, config, EGL10.EGL_ALPHA_SIZE, 0);

                if (r == mRedSize && g == mGreenSize && b == mBlueSize && a == mAlphaSize)
                    return config;
            }
            return null;
        }

        private int findConfigAttrib(EGL10 egl, EGLDisplay display, EGLConfig config, int attribute, int defaultValue) {
            if (egl.eglGetConfigAttrib(display, config, attribute, mValue)) {
                return mValue[0];
            }
            return defaultValue;
        }

        private void printConfigs(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
            int numConfigs = configs.length;
            BaseHelper.log(TAG, String.format("%d configurations", numConfigs));
            for (int i = 0; i < numConfigs; i++) {
                BaseHelper.log(TAG, String.format("Configuration %d:\n", i));
                printConfig(egl, display, configs[i]);
            }
        }

        private void printConfig(EGL10 egl, EGLDisplay display, EGLConfig config) {
            int[] attributes = {
                EGL10.EGL_BUFFER_SIZE,
                EGL10.EGL_ALPHA_SIZE,
                EGL10.EGL_BLUE_SIZE,
                EGL10.EGL_GREEN_SIZE,
                EGL10.EGL_RED_SIZE,
                EGL10.EGL_DEPTH_SIZE,
                EGL10.EGL_STENCIL_SIZE,
                EGL10.EGL_CONFIG_CAVEAT,
                EGL10.EGL_CONFIG_ID,
                EGL10.EGL_LEVEL,
                EGL10.EGL_MAX_PBUFFER_HEIGHT,
                EGL10.EGL_MAX_PBUFFER_PIXELS,
                EGL10.EGL_MAX_PBUFFER_WIDTH,
                EGL10.EGL_NATIVE_RENDERABLE,
                EGL10.EGL_NATIVE_VISUAL_ID,
                EGL10.EGL_NATIVE_VISUAL_TYPE,
                0x3030, // EGL10.EGL_PRESERVED_RESOURCES,
                EGL10.EGL_SAMPLES,
                EGL10.EGL_SAMPLE_BUFFERS,
                EGL10.EGL_SURFACE_TYPE,
                EGL10.EGL_TRANSPARENT_TYPE,
                EGL10.EGL_TRANSPARENT_RED_VALUE,
                EGL10.EGL_TRANSPARENT_GREEN_VALUE,
                EGL10.EGL_TRANSPARENT_BLUE_VALUE,
                0x3039, // EGL10.EGL_BIND_TO_TEXTURE_RGB,
                0x303A, // EGL10.EGL_BIND_TO_TEXTURE_RGBA,
                0x303B, // EGL10.EGL_MIN_SWAP_INTERVAL,
                0x303C, // EGL10.EGL_MAX_SWAP_INTERVAL,
                EGL10.EGL_LUMINANCE_SIZE,
                EGL10.EGL_ALPHA_MASK_SIZE,
                EGL10.EGL_COLOR_BUFFER_TYPE,
                EGL10.EGL_RENDERABLE_TYPE,
                0x3042 // EGL10.EGL_CONFORMANT
            };
            String[] names = {
                "EGL_BUFFER_SIZE",
                "EGL_ALPHA_SIZE",
                "EGL_BLUE_SIZE",
                "EGL_GREEN_SIZE",
                "EGL_RED_SIZE",
                "EGL_DEPTH_SIZE",
                "EGL_STENCIL_SIZE",
                "EGL_CONFIG_CAVEAT",
                "EGL_CONFIG_ID",
                "EGL_LEVEL",
                "EGL_MAX_PBUFFER_HEIGHT",
                "EGL_MAX_PBUFFER_PIXELS",
                "EGL_MAX_PBUFFER_WIDTH",
                "EGL_NATIVE_RENDERABLE",
                "EGL_NATIVE_VISUAL_ID",
                "EGL_NATIVE_VISUAL_TYPE",
                "EGL_PRESERVED_RESOURCES",
                "EGL_SAMPLES",
                "EGL_SAMPLE_BUFFERS",
                "EGL_SURFACE_TYPE",
                "EGL_TRANSPARENT_TYPE",
                "EGL_TRANSPARENT_RED_VALUE",
                "EGL_TRANSPARENT_GREEN_VALUE",
                "EGL_TRANSPARENT_BLUE_VALUE",
                "EGL_BIND_TO_TEXTURE_RGB",
                "EGL_BIND_TO_TEXTURE_RGBA",
                "EGL_MIN_SWAP_INTERVAL",
                "EGL_MAX_SWAP_INTERVAL",
                "EGL_LUMINANCE_SIZE",
                "EGL_ALPHA_MASK_SIZE",
                "EGL_COLOR_BUFFER_TYPE",
                "EGL_RENDERABLE_TYPE",
                "EGL_CONFORMANT"
            };
            int[] value = new int[1];
            for (int i = 0; i < attributes.length; i++) {
                int attribute = attributes[i];
                String name = names[i];
                if ( egl.eglGetConfigAttrib(display, config, attribute, value)) {
                    BaseHelper.log(TAG, String.format("  %s: %d\n", name, value[0]));
                } else {
                    // BaseHelper.log(TAG, String.format("  %s: failed\n", name));
                    while (egl.eglGetError() != EGL10.EGL_SUCCESS);
                }
            }
        }

        // Subclasses can adjust these values:
        protected int mRedSize;
        protected int mGreenSize;
        protected int mBlueSize;
        protected int mAlphaSize;
        protected int mDepthSize;
        protected int mStencilSize;
        private int[] mValue = new int[1];
    }
    
    /**
	 * Enable soft input area
	 * @param enable
	 */
	public void enableSoftInput(boolean enable) {
		this.useSoftInput = enable;
		
        setFocusable(enable);
        setFocusableInTouchMode(enable);
	}

	/**
	 * Hide soft input window when IME_ACTION_DONE is performed.
	 * @param hide
	 */
	/*public void hideSoftInputWhenDone(boolean hide) {
		this.hideSoftInputWhenDone = hide;
	}*/

	/**
	 * Show soft input to interact with the view.
	 */
	public void showSoftInput() {
		//showSoftInput(InputMethodManager.SHOW_IMPLICIT);
		showSoftInput(0);
	}
	
	/**
	 * Show soft input to interact with the view with given flags.
	 * @param flags Provides additional operating flags.
	 */
	public void showSoftInput(int flags) {
        InputMethodManager manager = (InputMethodManager)
        	getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        manager.showSoftInput(this, flags);
	}
	
	/**
	 * Hide soft input
	 */
	public void hideSoftInput() {
		hideSoftInput(0);
	}
	
	/**
	 * Hide soft input with given flags
	 * @param flags
	 */
	public void hideSoftInput(int flags) {
		InputMethodManager im = (InputMethodManager)
			getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
		im.hideSoftInputFromWindow(getWindowToken(), flags);
	}
	
	/**
	 * Returns true if the view is currently active in the input method.
	 * @return true if the view is currently active in the input method
	 */
	public boolean isSoftInputActive() {
		InputMethodManager im = (InputMethodManager)
			getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
		return im.isActive(this);
	}
	
	/**
	 * This method toggles the input method window display.
	 * @param showFlags Provides additional operating flags
	 * @param hideFlags Provides additional operating flags
	 */
	public void toggleSoftInput(int showFlags, int hideFlags) {
		InputMethodManager im = (InputMethodManager)
			getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
		im.toggleSoftInput(showFlags, hideFlags);
	}

	/**
	 * Create a new InputConnection for an InputMethod to interact with the view.
	 */
	
	public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
		if (!useSoftInput) return super.onCreateInputConnection(outAttrs);
		
		outAttrs.initialCapsMode = 0;
		outAttrs.initialSelEnd = outAttrs.initialSelStart = -1;
		outAttrs.inputType = (InputType.TYPE_CLASS_TEXT |
				InputType.TYPE_TEXT_VARIATION_NORMAL |
				InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE);
		outAttrs.imeOptions = (EditorInfo.IME_ACTION_DONE |
				EditorInfo.IME_FLAG_NO_EXTRACT_UI);

		return onLoadInputConnection();
	}
	
	/**
	 * Load InputConnection to interact with the view.
	 * @return InputConnection
	 */
	protected InputConnection onLoadInputConnection() {
		return new TextInputConnection(this);
	}
	
	/**
	 * TextInputConnection to activate soft input.
	 */
	private class TextInputConnection extends BaseInputConnection {
		public TextInputConnection(View view) {
			super(view, false);
		}

		public boolean commitText(CharSequence text, int newCursorPosition) {
			Log.w("Input", (String)text);
			
			return super.commitText(text, newCursorPosition);
		}
	}
}