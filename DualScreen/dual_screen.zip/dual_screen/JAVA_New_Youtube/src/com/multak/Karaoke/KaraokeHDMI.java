package com.multak.Karaoke;

import java.util.Timer;
import java.util.TimerTask;

import com.google.android.youtube.player.YouTubePlayerView;
import com.multak.MK8507MOA.MainActivity;
import com.multak.MK8507MOA.R;

import android.app.Presentation;
import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class KaraokeHDMI extends Presentation {
    private static String TAG = "KaraokeHDMI";
    
    private Context mcontext;

    //karaoke view
	public static GLSurfaceView mGLSurfaceView = null;
	public static SurfaceView mVideoSurfaceView = null;
	public static SurfaceView mMediaSurfaceView = null;
	public static SurfaceView mPicSurfaceView = null;
	public static CameraPicture mCameraPicture = null;

	public static ImageView mProgressImageView = null;
	public static YouTubePlayerView mYouTubePlayerView = null;
	
	//system vol
	private int mLastvol = 0;
	private Timer mTimerSystemVol;
	private TimerTask mTimerTaskSystemVol;
	    
    public KaraokeHDMI(Context context, Display display) {
        super(context, display);
        mcontext = context; 
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	// Be sure to call the super class.
    	super.onCreate(savedInstanceState);
    	
    	setContentView(R.layout.karaoke_hdmi);
    	
    	initKaraokeView();

    	Karaoke.RenderStatus = 1;
		KaraokeLib.setEnv(Karaoke.LocalSampleRate, KaraokeLib.monoFlag,
				KaraokeLib.g_bufferSizeOutBytes,
				KaraokeLib.g_bufferSizeInBytes, Karaoke.LocalSampleRateOut);
		
		Karaoke.FinishKaraokeStartFlag++;
    }

	private void initKaraokeView() {
		mGLSurfaceView = (GLSurfaceView)findViewById(R.id.karaokeView_Hdmi);
		KaraokeRenderer kr = new KaraokeRenderer(mcontext);
		mGLSurfaceView.setRenderer(kr);
		kr.SetListener(MainActivity.mKaraoke);
		mGLSurfaceView.setZOrderOnTop(true);
		
		mPicSurfaceView = (SurfaceView)findViewById(R.id.camera_surface_view);
		
		mVideoSurfaceView = (SurfaceView)findViewById(R.id.javavideo_view);
		mVideoSurfaceView.setVisibility(View.VISIBLE);
		JavaVideoLib.setView(mVideoSurfaceView);

		mMediaSurfaceView = (SurfaceView)findViewById(R.id.mediaplayer_view);
		SurfaceHolder mSurfaceHolder = mMediaSurfaceView.getHolder();
		mSurfaceHolder.setFormat(PixelFormat.TRANSPARENT);
		MediaPlayerLib.SetMediaSurface(mSurfaceHolder.getSurface(), mSurfaceHolder, mMediaSurfaceView);	
		
		mProgressImageView = (ImageView)findViewById(R.id.progress_view);
		JavaVideoLib.setView(mProgressImageView, AnimationUtils.loadAnimation(mcontext, R.anim.rotate));
		mProgressImageView.setVisibility(View.INVISIBLE);
		
		mYouTubePlayerView = new YouTubePlayerView(mcontext);
		((FrameLayout)findViewById(R.id.framelayoutyoutube)).addView(mYouTubePlayerView);
		Karaoke.mYoutubeService.setYoutubeView(mYouTubePlayerView);
		mYouTubePlayerView.setVisibility(View.INVISIBLE);
		
		startSystemVolSyncRender();
		JavaVideoLib.CreateEXO();
	}
	
	public void startSystemVolSyncRender() {
		mTimerSystemVol = new Timer();    
        mTimerTaskSystemVol = new TimerTask() {
        	int curVol = -1;
            @Override
            public void run() {  
            	curVol = Integer.parseInt(KaraokeLib.getGLString(10,0));
            	if (mLastvol != curVol) {
                	KaraokeLib.SetSystemVol(curVol);
            		mLastvol = curVol;
            	}
            }    
        };
        mTimerSystemVol.schedule(mTimerTaskSystemVol, 0, 500);
	}
}