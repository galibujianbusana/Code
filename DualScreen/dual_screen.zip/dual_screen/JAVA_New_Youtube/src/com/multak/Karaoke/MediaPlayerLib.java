﻿package com.multak.Karaoke;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;

import com.multak.Karaoke.MyListener;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN) public class MediaPlayerLib{

	public static MediaCodec mediaCodec = null;
	public static ByteBuffer[] inputBuffers;
	public static ByteBuffer[] outputBuffers;
	public static int inputBufferIndex;
	public static int outputBufferIndex;
	public static long mLastPresentationTimeUs = 0;
	public static Surface mySurface;
	public static SurfaceHolder myholder;
	public static int InitVmStatus = 0;
	public static SurfaceView mView;
	public static Handler handler = new Handler();

	//音频编码
	private static final String AUDIO_MIME_TYPE = "audio/mp4a-latm";

	private static MediaFormat audioFormat;
	private static MediaCodec mAudioEncoder = null;
	private static MediaCodec.BufferInfo mAudioBufferInfo;
	public static int inputAudioBufferIndex;
	private static BufferedOutputStream outputStream = null;   
	public static int profile = 2;  //AAC LC
	public static int freqIdx = 3;  //4-44.1KHz  48KHz
	public static int chanCfg = 2;  //CPE

	public static ByteBuffer outByteBuffer = null;
	//音频编码 end
	
	public static int FindCodec[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	public static String FindCodecName[] = {"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};

	@TargetApi(Build.VERSION_CODES.JELLY_BEAN) 
	public static ByteBuffer GetInputBuffer(int timeoutUs)
	{
		if(mediaCodec == null)
			return null;
		inputBuffers = mediaCodec.getInputBuffers();
		int n = 0;

		do {
			inputBufferIndex = mediaCodec.dequeueInputBuffer(100000);
			if(inputBufferIndex < 0) {
				try {
					Thread.sleep(5);
					n++;
					if(n == 5) {
						return null;
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} while (inputBufferIndex < 0);

		return inputBuffers[inputBufferIndex];
	}

	public static int GetInputBufferIndex() {
		return inputBufferIndex;
	}

	public static int GetOutputBufferIndex() {
		return outputBufferIndex;
	} 

	@TargetApi(Build.VERSION_CODES.JELLY_BEAN) 
	public static void queueInputBuffer(int index, int size, int timeoutUs) {
		if(mediaCodec == null)
			return;
		mediaCodec.queueInputBuffer(index, 0, size, timeoutUs, 0);
	}

	public static void releaseOutputBuffer(int index, boolean flag) {
		if(mediaCodec == null)
			return;
		
		try {
			mediaCodec.releaseOutputBuffer(index, flag);
		} catch(Exception e) {

		}
	}

	@TargetApi(Build.VERSION_CODES.JELLY_BEAN) 
	public static long GetOutputBuffer(int timeoutUs) {
		if(mediaCodec == null)
			return 0;
		
		outputBuffers = mediaCodec.getOutputBuffers();
		MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
		outputBufferIndex = mediaCodec.dequeueOutputBuffer(bufferInfo, timeoutUs);

		if (bufferInfo.presentationTimeUs < mLastPresentationTimeUs) {

			bufferInfo.presentationTimeUs = mLastPresentationTimeUs;
		}
		mLastPresentationTimeUs = bufferInfo.presentationTimeUs;

		return bufferInfo.presentationTimeUs;
	}

	public static void SetMediaSurface(Surface _surface, SurfaceHolder _holder, SurfaceView _view) {
		mySurface = _surface;
		myholder = _holder;
		mView = _view;
	}
	
	private static int sleepdelay  = 0;
	@TargetApi(Build.VERSION_CODES.JELLY_BEAN) 
	public static int StartMediaCodec(int nID, int w, int h) {
		myControlUART(0x310000);
		handler.post(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Log.i("MediaPlayerLib", "setVisibility VISIBLE");
				mView.setVisibility(View.VISIBLE);
				sleepdelay = 1;
			}			
		});
		
		while(sleepdelay == 0) {
			
		}
		sleepdelay = 0;
		
		String mime = "";
		if(nID == 0) {
			mime = "video/avc";
		} else if(nID == 1) {
			mime = "video/x-vnd.on2.vp8";
		} else if(nID == 2) {
			mime = "video/x-vnd.on2.vp9";
		} else if(nID == 3) {
			mime = "video/3gpp";
		} else if(nID == 4) {
			mime = "video/mp4v-es";
		} else if(nID == 5) {
			mime = "video/mpeg2";
		} else if(nID == 6) {
			mime = "video/mpeg1";
		} else if(nID == 7) {
			mime = "video/x-ms-mpeg4v1";
		} else if(nID == 8) {
			mime = "video/x-ms-mpeg4v2";
		} else if(nID == 9) {
			mime = "video/divx";
		} else if(nID == 10) {
			mime = "video/xvid";
		} else if(nID == 11) {
			mime = "video/wmv1";
		} else if(nID == 12) {
			mime = "video/wmv2";
		} else if(nID == 13) {
			mime = "video/jpeg";
		}
		
		MediaCodecInfo codecInfo = null;
		if(FindCodec[nID] == 0)
		{
			//查找CodecName
			int numCodecs = MediaCodecList.getCodecCount();
			for (int i = 0; i < numCodecs && codecInfo == null; i++) {
				MediaCodecInfo info = MediaCodecList.getCodecInfoAt(i);

				if (info.isEncoder()) {
					continue;
				}
				String[] types = info.getSupportedTypes();
				boolean found = false;
				for (int j = 0; j < types.length && !found; j++) {
					if (types[j].equals(mime)) {
						if(types[j].equals("video/avc") 
								&& info.getName().equals("OMX.google.h264.decoder")) {

						} else if (types[j].equals("video/mp4v-es") 
								&& info.getName().equals("OMX.google.mpeg4.decoder")) {

						} else {
							found = true;
						}
					}
				}
				if (!found)
					continue;
				codecInfo = info;
			}

			if(codecInfo != null) {
				FindCodec[nID] = 1;
				FindCodecName[nID] = codecInfo.getName();
			}
		}
		Log.w("MEDIACODEC", "Found " + FindCodecName[nID] + ", " + mime + ", " + w + ", " + h);

		try {
			if(FindCodecName[nID].length() == 0) {
				return 0;
			} else {
				mediaCodec = MediaCodec.createByCodecName(FindCodecName[nID]);
			}

			MediaFormat mediaFormat = MediaFormat.createVideoFormat(mime, w, h);  
			mediaCodec.configure(mediaFormat, mySurface, null, 0); 

			mediaCodec.start(); 
			mLastPresentationTimeUs = 0;
		} catch(Exception ee) {
			ee.printStackTrace();
		}
		return 1;
	}

	@TargetApi(Build.VERSION_CODES.JELLY_BEAN) 
	public static void StopMediaCodec() {
		if(mediaCodec == null)
			return;
		
		mediaCodec.flush();
		mediaCodec.stop();
		mediaCodec.release();
		mediaCodec = null;

		handler.post(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Log.i("MediaPlayerLib", "setVisibility INVISIBLE");
				mView.setVisibility(View.INVISIBLE);
			}			
		});
		myControlUART(MyListener.MSG_ID_MEDIACODEC_STOP);
	}

	public static MyListener myListener = null; 

	public static void myControlUART(int n) {
		if(myListener != null) {
			myListener.onMsgNotify(n);
		} else {
			Log.e("KaraokeLib", "Some mesg cannot send to Java yet");
		}
	}

	//aac encode
	public static void touch(File f) {
		try {
			if(!f.exists())
				f.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void addADTStoPacket(byte[] packet, int packetLen) {
		// fill in ADTS data
		packet[0] = (byte)0xFF;
		packet[1] = (byte)0xF9;
		packet[2] = (byte)(((profile-1)<<6) + (freqIdx<<2) +(chanCfg>>2));
		packet[3] = (byte)(((chanCfg&3)<<6) + (packetLen>>11));
		packet[4] = (byte)((packetLen&0x7FF) >> 3);
		packet[5] = (byte)(((packetLen&7)<<5) + 0x1F);
		packet[6] = (byte)0xFC;
	}

	@TargetApi(Build.VERSION_CODES.JELLY_BEAN) 
	public static void AudioEncode_Prepare(String FilePath, int SampleRate, int Channel, int BitRate, int MaxInputSize) {
		if(FilePath.length() != 0) {
			File f = new File(FilePath);
			touch(f);
			try {
				outputStream = new BufferedOutputStream(new FileOutputStream(f));
				Log.e("AudioEncoder", "outputStream initialized");
			} catch (Exception e){
				e.printStackTrace();
			}
		}

		mAudioBufferInfo = new MediaCodec.BufferInfo();

		audioFormat = new MediaFormat();
		audioFormat.setString(MediaFormat.KEY_MIME, AUDIO_MIME_TYPE);
		audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
		audioFormat.setInteger(MediaFormat.KEY_SAMPLE_RATE, SampleRate);
		audioFormat.setInteger(MediaFormat.KEY_CHANNEL_COUNT, Channel);
		audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, BitRate);
		audioFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, MaxInputSize);

		chanCfg = Channel;
		switch(SampleRate) {
		case 96000:
			freqIdx = 0x0;
			break;
		case 88200:
			freqIdx = 0x1;
			break;
		case 64000:
			freqIdx = 0x2;
			break;
		case 48000:
			freqIdx = 0x3;
			break;
		case 44100:
			freqIdx = 0x4;
			break;        	
		case 32000:
			freqIdx = 0x5;
			break; 
		case 24000:
			freqIdx = 0x6;
			break; 
		case 22050:
			freqIdx = 0x7;
			break; 
		case 16000:
			freqIdx = 0x8;
			break;  
		case 2000:
			freqIdx = 0x9;
			break; 
		case 11025:
			freqIdx = 0xa;
			break; 
		case 8000:
			freqIdx = 0xb;
			break;         	
		}

		try {
			mAudioEncoder = MediaCodec.createEncoderByType(AUDIO_MIME_TYPE);
			mAudioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
			mAudioEncoder.start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.w("MEDIA_AUDIO", "AudioEncode_Prepare");
	}

	public static void AudioEncoder_Stop() {
		//stopReceived = true;
		//eosReceived = true;

		try {
			if (mAudioEncoder != null) {
				mAudioEncoder.flush();
				mAudioEncoder.stop();
				mAudioEncoder.release();
				mAudioEncoder = null;
			}

			if(outputStream != null)
			{	 
				outputStream.flush();
				outputStream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		Log.w("MEDIA_AUDIO", "AudioEncoder_Stop");
	}

	public static ByteBuffer GetAudioInputBuffer() {
		try {
			ByteBuffer[] inputBuffers = mAudioEncoder.getInputBuffers();
			inputAudioBufferIndex = mAudioEncoder.dequeueInputBuffer(-1);
			if (inputAudioBufferIndex >= 0) {
				return inputBuffers[inputAudioBufferIndex];
			}
		} catch (Throwable t) {
			t.printStackTrace();
		}
		Log.w("MEDIA_AUDIO", "GetAudioInputBuffer failed");
		return null;
	}

	public static ByteBuffer OfferAudioEncoder(int nLength, int presentationTimeUs) {
		outByteBuffer = null;
		ArrayList<byte[]> listOutData = new ArrayList<byte[]>(); 
		int totalSize = 0;

		try {
			mAudioEncoder.queueInputBuffer(inputAudioBufferIndex, 0, nLength, presentationTimeUs, 0);
		} catch (Throwable t) {
			t.printStackTrace();
		}
		
		//Encode输出
		final int TIMEOUT_USEC = 100;
		ByteBuffer[] encoderOutputBuffers = mAudioEncoder.getOutputBuffers();
		while (true) {
			int encoderStatus = mAudioEncoder.dequeueOutputBuffer(mAudioBufferInfo, TIMEOUT_USEC);
			if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
				// no output available yet
				break;      // out of while
			} else if (encoderStatus == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
				// not expected for an encoder
				encoderOutputBuffers = mAudioEncoder.getOutputBuffers();
				Log.w("MEDIA_AUDIO", "OfferAudioEncoder =======2");
			} else if (encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
				// should happen before receiving buffers, and should only happen once
				MediaFormat newFormat = mAudioEncoder.getOutputFormat();
				Log.w("MEDIA_AUDIO", "OfferAudioEncoder =======3");
			} else if (encoderStatus < 0) {
				Log.w("MEDIA_AUDIO", "unexpected result from encoder.dequeueOutputBuffer: " +
						encoderStatus);
				Log.w("MEDIA_AUDIO", "OfferAudioEncoder =======4");
			} else {
				ByteBuffer encodedData = encoderOutputBuffers[encoderStatus];
				if (encodedData == null) {
					Log.w("MEDIA_AUDIO", "OfferAudioEncoder =======5");
				}

				if ((mAudioBufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
					// The codec config data was pulled out and fed to the muxer when we got
					// the INFO_OUTPUT_FORMAT_CHANGED status.  Ignore it.
					Log.w("MEDIA_AUDIO", "OfferAudioEncoder =======6");
					mAudioBufferInfo.size = 0;
				}

				if (mAudioBufferInfo.size != 0) {
					int outBitsSize   = mAudioBufferInfo.size;
					int outPacketSize = outBitsSize + 7;    // 7 is ADTS size

					encodedData.position(mAudioBufferInfo.offset);
					encodedData.limit(mAudioBufferInfo.offset + mAudioBufferInfo.size);

					byte[] outData = new byte[outPacketSize];
					addADTStoPacket(outData, outPacketSize);

					encodedData.get(outData, 7, outBitsSize);
					encodedData.position(mAudioBufferInfo.offset);

					if(outputStream != null) {
						try {
							//Log.w("MEDIA_AUDIO", "OfferAudioEncoder 3=="+outData.length);
							outputStream.write(outData, 0, outData.length);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else {
						listOutData.add(outData);
						totalSize += outData.length;
					}
				}

				mAudioEncoder.releaseOutputBuffer(encoderStatus, false);

				if ((mAudioBufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
					break;      // out of while
				}
			}
		}

		if(outputStream == null && listOutData.size() > 0) {
			outByteBuffer = ByteBuffer.allocateDirect(totalSize);
			for (byte[] tempArr : listOutData) {  
				outByteBuffer.put(tempArr);
			}
		}

		return outByteBuffer;
	}
	//aac encode end
}
