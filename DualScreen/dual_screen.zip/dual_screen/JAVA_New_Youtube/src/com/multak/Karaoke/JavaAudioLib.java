package com.multak.Karaoke;

import java.io.File;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.util.Log;

public class JavaAudioLib {

	//AudioPlayer Use

	public static AudioTrack audioTrackJava = null;
	public static AudioRecord audioRecordJava = null;

	public static int mBuffersize;

	private static int mBufferBaseSize = 4096*4;
	public static int g_bufferSizeOutBytes = mBufferBaseSize*2;
	public static int g_bufferSizeInBytes = mBufferBaseSize*2;

	public static int	CurrentSamplerateRecord;

	public static MediaRecorder mMediaRecorder;// MediaRecorder瀵硅薄
	public static File mRecAudioFile = null;
	public static String CurrentRecFilePath;
	public static int audioRecordJavaError = 0;

	public static int m_InChannels = 2;
	public static int m_OutChannels = 2;
	public static int m_InSampleRate = 48000;
	public static int m_OutSampleRate = 48000;

	public static int m_DefaultSampleRate = 44100;

	private static boolean tryInitAudioRecord() {
		try  {
			CurrentSamplerateRecord = m_InSampleRate;
			Log.w("JNIServiceLib", String.format("1, %d, %d", m_InSampleRate, m_InChannels));

			if(m_InChannels == 1) {
				mBuffersize= AudioRecord.getMinBufferSize(m_InSampleRate,  AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
			} else {
				mBuffersize= AudioRecord.getMinBufferSize(m_InSampleRate,  AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
			}

			Log.w("JNIServiceLib", String.format("%d",mBuffersize));
			if(mBuffersize < (mBufferBaseSize * m_InChannels)) {
				mBuffersize = (mBufferBaseSize * m_InChannels);
			}
			g_bufferSizeInBytes = mBuffersize;
			if(audioRecordJava == null) {
				try {
					if(m_InChannels == 1) {
						audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
								m_InSampleRate, AudioFormat.CHANNEL_IN_MONO, 
								AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
					} else {
						audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
								m_InSampleRate, AudioFormat.CHANNEL_IN_STEREO, 
								AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
					}

					audioRecordJava.startRecording(); //remove for voice
					audioRecordJava.stop(); //remove for voice
					Log.w("JNIServiceLib", "Start Rec");
					return true;

				} catch(Exception e) {
					Log.w("JNIServiceLib", "exception");
					e.printStackTrace();

					if(audioRecordJava != null) {
						try {
							audioRecordJava.stop();
							audioRecordJava.release();
							audioRecordJava = null;
						} catch(Exception e2) {
							audioRecordJava.release();
							audioRecordJava = null;
							audioRecordJavaError = 1;
						}
					}
					return false;									
				}
			} else {
				return true;
			}
		} catch(Exception e) {
			return false;
		}
	}

	public static void initAudioRecord(int inChannels, int inRate) {
		if (audioRecordJava == null){
			if (inChannels > 0)
				m_InChannels = inChannels;
			else
				m_InChannels = 1;
			if (inRate > 0)
				m_InSampleRate = inRate;
			else
				m_InSampleRate = 48000;
			if (!tryInitAudioRecord()) {
				m_InSampleRate = 32000;
				if (!tryInitAudioRecord()) {
					m_InChannels = 2;
					m_InSampleRate = 48000;
					if (!tryInitAudioRecord()) {
						m_InSampleRate = 32000;
						tryInitAudioRecord();
					}
				}
			}
		}
	}

	public static void initAudioTrack(int outChannels, int outRate) {
		Log.w("JNIServiceLib", "initAudioTrack begin");
		if (outRate > 0)
			m_OutSampleRate = outRate;
		if (m_OutSampleRate != m_InSampleRate)
			m_OutSampleRate = m_InSampleRate;
		
		Log.w("JNIServiceLib", "initAudioTrack " + m_OutSampleRate);
		
		int bufferSizeInBytes = AudioTrack.getMinBufferSize(m_OutSampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);  
		if(audioTrackJava == null) {
			Log.w("JNIServiceLib", String.format("bufferSizeInBytes%d",bufferSizeInBytes));
			if(bufferSizeInBytes < (mBufferBaseSize * 2)) {
				bufferSizeInBytes = (mBufferBaseSize * 2);	
			}
			g_bufferSizeOutBytes = bufferSizeInBytes;
			try {		
				audioTrackJava = new AudioTrack(AudioManager.STREAM_MUSIC, m_OutSampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT, bufferSizeInBytes, AudioTrack.MODE_STREAM);
				audioTrackJava.setStereoVolume(1.0f, 1.0f);
				//audioTrackJava.play();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		Log.w("JNIServiceLib", "initAudioTrack end");
	}

	public static void deinitAudioTrack() {
		if(audioTrackJava != null) {
			audioTrackJava.stop();
			audioTrackJava.release();
			audioTrackJava = null;
		}
	}

	public static void deinitAudioRecord() {
		if(audioRecordJava != null) {
			audioRecordJava.stop();
			audioRecordJava.release();
			audioRecordJava = null;
		}
	}

	public static void changeVolume(float leftVolume, float rightVoume) {
		if(audioTrackJava != null) {
			audioTrackJava.setStereoVolume(leftVolume, rightVoume);
		}
	}

	public static void changeRecordSampleRate(int SampleRate) {
		if(SampleRate != CurrentSamplerateRecord) {
			CurrentSamplerateRecord = SampleRate;
			new Thread(new Runnable() {
				public void run() {
					//Recordthread.stop();
					if(audioRecordJava != null) {
						audioRecordJava.stop();
						audioRecordJava.release();
						audioRecordJava = null;
					}
					if(audioRecordJava == null) {
						if(m_InChannels == 1) {
							audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
									CurrentSamplerateRecord * 100, AudioFormat.CHANNEL_IN_MONO, 
									AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
						} else {
							audioRecordJava = new AudioRecord(MediaRecorder.AudioSource.MIC, 
									CurrentSamplerateRecord * 100, AudioFormat.CHANNEL_IN_STEREO, 
									AudioFormat.ENCODING_PCM_16BIT, mBuffersize);
						}
						Log.w("JNIServiceLib", "Start Rec");

						audioRecordJava.startRecording();
					}
				}
			}).start();
		}
	}

	public static int audioCB(final byte[] mArr, final int offset, final int size) {
		if (audioTrackJava != null)
			return audioTrackJava.write(mArr, offset, size);
		else
			return 0;
	}

	public static int audioRecordRead(final byte[] mArr, final int size) {
		if(audioRecordJava != null)
			return audioRecordJava.read(mArr, 0, size);
		else
			return 0;
	}

	public static int AudioTrackPlay(int n) {
		if(audioRecordJava != null) {
			audioRecordJava.startRecording();
		}
		if(audioTrackJava != null) {
			audioTrackJava.play();
		}
		return 0;
	}

	public static int AudioTrackPause(int n) {
		if(audioTrackJava != null) {
			audioTrackJava.flush();
			audioTrackJava.stop();
		}
		if(audioRecordJava != null) {
			audioRecordJava.stop();
		}
		return 0;
	}
}
