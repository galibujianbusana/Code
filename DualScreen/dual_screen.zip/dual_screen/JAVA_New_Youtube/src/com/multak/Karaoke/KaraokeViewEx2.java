package com.multak.Karaoke;

import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;

import com.multak.MultakStandard.BaseHelper;

public class KaraokeViewEx2 extends SurfaceView {
    private static String TAG = "Karaoke";
    private static final boolean DEBUG = false;
	protected boolean useSoftInput = false;
	protected boolean hideSoftInputWhenDone = true;
	private Context mContext;
	
    //XML define
    public KaraokeViewEx2(Context context,AttributeSet paramAttributeSet) {
    	super(context, paramAttributeSet);
    	mContext = context;
    }
    
    public KaraokeViewEx2(Context context) {
        super(context);
        mContext = context;
    }

    public KaraokeViewEx2(Context context, boolean translucent, int depth, int stencil) {
        super(context);
        mContext = context;
    }
    
	int flag = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		Log.d("Key", "onKeyDown=" + keyCode + " " + event.getDisplayLabel() + " " + event.getUnicodeChar() + " " + event.getNumber());
		return false;
	}
	
	public boolean onTouchEvent(MotionEvent event) {
		/* Perhaps we should pass integers down to reduce the number of float computations */
		//Log.d("Key", "onTouchEvent action=" + event.getAction() + " x=" + event.getX() + " y=" + event.getY() + " pressure=" + event.getPressure() + "size = " + event.getSize());		
		return queueMotionEvent(event.getAction(), event.getX(), event.getY(), event.getPressure());
	}

	
	public boolean onTrackballEvent(MotionEvent event) {
		//Log.d("Key", "onTrackballEvent action=" + event.getAction() + " x=" + event.getX() + " y=" + event.getY());
		return queueTrackballEvent(event.getAction(), event.getX(), event.getY());
	}
	

	public boolean queueKeyEvent(final int qKeyCode, final int state) {
		if(qKeyCode == 0) 
			return true;

       	KaraokeVGALib.queueKeyEvent(qKeyCode, state);
        return true;
	}

	private boolean queueMotionEvent(final int action, final float x, final float y, final float pressure)
	{
       	KaraokeVGALib.queueMotionEvent(action, x, y, pressure);
        return true;
	}
	
	private boolean queueTrackballEvent(final int action, final float x, final float y)
	{
       	KaraokeVGALib.queueTrackballEvent(action, x, y);
        return true;
	}

	private int androidKeyCodeToMultak(int aKeyCode, KeyEvent event) {	
		/* Convert non-ASCII keys by hand */
		switch(aKeyCode) {
			/* For now map the focus buttons to F1 and let the user remap it in game.
			 * This should allow some basic movement on the Nexus One if people map it to forward.
			 * At least on the Milestone the camera button itself is shared with the Focus one. You have
			 * to press focus first and then you hit camera, this leads to the following event sequence which
			 * I don't handle right now: focus_down -> camera_down -> camera_up -> focus_up.
			 */
		}

		/* Let Android do all the character conversion for us. This way we don't have
		 * to care about modifier keys and specific keyboard layouts.
		 * TODO: add some more filtering
		 */
		int uchar = event.getUnicodeChar();
		if(uchar < 127)
			return uchar;

		return 0;
	}

}