package com.multak.Karaoke;

public interface MyListener {
	public void FinishActivity();
	public void ControlUART(int n);
	public void ControlUARTJava(int n);
	public void ControlUARTJavaS(int n, String content);
	
	public static final int MSG_ID_ERROR_CODE = 1;
	public static final int MSG_ID_ERROR_STRING = 2;
	
	public static final int MSG_ID_DATA_READY = 10;
	public static final int MSG_ID_SHOW_INFO = 20;
	
	public static final int MSG_ID_RELOAD = 31;
	public static final int DELAY_TO_RELOAD = 10000;
	public static final int MSG_ID_MEDIACODEC_STOP = 20000;
	public static final int MSG_ID_YOUTUBE_DOWNLOAD = 154;
	
	public void onMsgNotify(int n);
	
	
	public void onMsgNotify(int what, Object obj, String token);
}
