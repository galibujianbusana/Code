package com.multak.Karaoke;

public class YouTubeListItem {
	public String m_videoID = "";
	public String m_videoName = "";
	public String m_videoThumbUrl = "";
}
