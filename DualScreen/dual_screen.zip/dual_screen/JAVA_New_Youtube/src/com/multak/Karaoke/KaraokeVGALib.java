package com.multak.Karaoke;


public class KaraokeVGALib {
	
	static {
		System.loadLibrary("VGALib");
    }
	
	public static MyListener myListener = null;
	
	public static void mmm_myControlUARTSnd(int n) {
	//public static void myControlUARTSnd(int n) {
		if(myListener != null) {
			myListener.ControlUART(n);
		}
	}

	public static void myControlUARTSnd(int n) {
		if(myListener != null) {
			myListener.ControlUART(n);
		}
	}

	
	public static void MsgToHDMI(int iparam1, int iparam2, int iparam3, 
			int iparam4, int iparam5, int iparam6, int iparam7, int iparam8,
			String strparam1, String strparam2, String strparam3, String strparam4) {

		KaraokeLib.recvMsgFromVGA(iparam1, iparam2, iparam3,
				  iparam4, iparam5, iparam6, iparam7, iparam8,
				  strparam1, strparam2, strparam3, strparam4);
		return;
	}
	
	public static void queueMotionEventEx(int action, float x, float y, float pressure) {
		float width = x;
		float height = y;
		queueMotionEvent(action, width, height, pressure);
	}
	
	//render
    public static native int init(int width, int height, String sopath, String sourcepath);
    public static native short step();
    public static native void exit();
    
	// Keyboard and motion input
	public static native void queueKeyEvent(int key, int state);
	public static native void queueMotionEvent(int action, float x, float y, float pressure);
	public static native void queueTrackballEvent(int action, float x, float y);

	public static native void setStatus(int TypeID, int nNum, int nType);
	public static native void setSubStatus(int TypeID, int index, String Name, int Type);
	public static native void setEnv();
	
    public static native String getWebUrl(int FileID);
    
    public static native void setGLString(int type, int FileID, String glString);
    public static native String getGLString(int type, int FileID);
    
    public static native void initMultakDevice();
    public static native void removeMultakDevice(int type, String path);
    public static native void addMultakDevice(int type, String path);
    public static native void restartMultakDevice();
    
	public static native void setVideoStatus(int type, int subType);
	public static native int getCurrentMode(int TypeID);
	public static native String getTips(int TipID);
	
	public static native void setYoutube(int type, String strparam1, String strparam2, String strparam3);

	public static native void recvMsgFromHDMI(int iparam1, int iparam2, int iparam3,
					int iparam4, int iparam5, int iparam6, int iparam7,  int iparam8,
					String strparam1, String strparam2, String strparam3, String strparam4);
}
