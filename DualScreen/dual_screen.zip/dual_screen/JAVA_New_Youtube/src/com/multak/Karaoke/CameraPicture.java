package com.multak.Karaoke;

import java.io.File;
import java.io.FileOutputStream;

import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

public class CameraPicture implements Callback {
	private Camera mCamera;
	private int mWidth;
	private int mHeight;
	private String mPath;
	private SurfaceHolder mSurfaceHolder;
	
	public static boolean CameraWork = false;
	public static int CameraIndex = 1;
	public static String CameraSavePath = "";
	
	public int CameraPicture_Init (SurfaceView mSurfaceView, String Savepath, int Width, int Height) {
		if (mCamera != null && CameraWork == true) {
			return 2;
		}
		try {
			mCamera = getCameraInstance();

			mWidth = Width;
			mHeight = Height;
			CameraSavePath = Savepath;
			mSurfaceHolder = mSurfaceView.getHolder();		
			mSurfaceHolder.addCallback(this);
		} catch (Exception exception) {
			mCamera.release();
			mCamera = null;
		}
		if (mCamera != null) {
			try {
				mCamera.setPreviewDisplay(mSurfaceHolder);
				mCamera.startPreview();
				CameraWork = true;
				new Thread(new Runnable() {
					public void run() {
						while(CameraWork == true)
						{
							try {
								String path = CameraSavePath + String.format("%06d.pmk", CameraIndex);
								CameraPicture_Take(path);
					            CameraIndex++;
					            if(CameraIndex > 400)
					            {
					            	CameraIndex = 1;
					            }
					            Thread.sleep(8000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					}
				}).start();
				return 1;
			} catch (Exception e) { 
				e.printStackTrace(); 
			} 
	    }
		KaraokeLib.addCameraPic("");
		return 0;
	}
	
	public void CameraPicture_Finish () {
		mWidth = 0;
		mHeight = 0;
		CameraWork = false;
		if (mCamera != null) { 
	    	try {
	    		mCamera.stopPreview(); 
	    	} catch (Exception e) { 
	    		e.printStackTrace(); 
	    	}
			mCamera.release();
			mCamera = null;
	    } 
		KaraokeLib.addCameraPic("");
	}
	
	public void CameraPicture_Take (String Path) {
		mPath = Path;
		mCamera.takePicture(null, null, jpegCallback);
	}
	
	private PictureCallback jpegCallback = new PictureCallback() { 
	    public void onPictureTaken(byte[] _data, Camera _camera) {
            try {
            	File f = new File(mPath);
            	FileOutputStream fos = new FileOutputStream(f.getAbsolutePath());
            	fos.write(_data, 0, _data.length);
            	fos.flush();
            	fos.close();  
           	
	            KaraokeLib.addCameraPic(mPath);
	            
	            mCamera.startPreview();
            } catch (Exception e) {
            	e.printStackTrace();
            	mWidth = 0;
        		mHeight = 0;
        		CameraWork = false;
        		mCamera = null;
            }
            mCamera.startPreview();
	    } 
	};

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		
	}
		
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
	   
	}
	
	/** A safe way to get an instance of the Camera object. */
    public static Camera getCameraInstance(){
        Camera camera = null;
        try {
        	camera = Camera.open(); // attempt to get a Camera instance
            if(camera != null) {
	            Camera.Parameters mParameters = camera.getParameters();
	            mParameters.setPictureSize(1280, 720);
	            camera.setParameters(mParameters);
            }
        } catch (Exception e) {
            // Camera is not available (in use or does not exist)
        }

        return camera; // returns null if camera is unavailable
    }

}