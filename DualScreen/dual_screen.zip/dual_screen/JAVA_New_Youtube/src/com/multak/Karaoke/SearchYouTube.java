package com.multak.Karaoke;


import android.util.Log;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

/*
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.repackaged.com.google.common.base.Joiner;

import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.GeoPoint;
import com.google.api.services.youtube.model.ResourceId;
import com.google.api.services.youtube.model.SearchListResponse;
import com.google.api.services.youtube.model.SearchResult;
import com.google.api.services.youtube.model.Thumbnail;
import com.google.api.services.youtube.model.Video;
import com.google.api.services.youtube.model.VideoListResponse;
*/
//import com.google.common.io.BaseEncoding;
/*
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.repackaged.com.google.common.base.Joiner;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.GeoPoint;
import com.google.api.services.youtube.model.SearchListResponse;
import com.google.api.services.youtube.model.SearchResult;
import com.google.api.services.youtube.model.Thumbnail;
import com.google.api.services.youtube.model.Video;
import com.google.api.services.youtube.model.VideoListResponse;
import com.google.common.io.BaseEncoding;*/

public class SearchYouTube {
	//https://i.ytimg.com/vi/sOfplMzlTq0/0.jpg
	//https://www.youtube.com/results?search_query=
	
	String strPrefixSearch = "https://www.youtube.com/results?search_query=";
	String strCondition;
	public VideoSearchList videoList = new VideoSearchList();
	
	String googleUrl = "https://accounts.google.com/ServiceLoginAuth";
	
	private List<String> cookies;
	private HttpsURLConnection conn;

	private final String USER_AGENT = "Mozilla/5.0";
	
	private int SearchFlag = 0;
	private String TempFolder = "";
	private List<String> pageUrlList = new ArrayList<String>();
	private List<Integer> pageUrlOK = new ArrayList<Integer>();
	public int searchReady = 0;
	
	private int currentSearchNo = -1;
	
	public static boolean LoginGoogle = false;
	
	private void sendPost(String url, String postParams) throws Exception
	{
		URL obj = new URL(url);
		conn = (HttpsURLConnection) obj.openConnection();
	
		// Acts like a browser
		conn.setUseCaches(false);
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Host", "accounts.google.com");
		conn.setRequestProperty("User-Agent", USER_AGENT);
		conn.setRequestProperty("Accept",
			"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		
		if(cookies != null)
		{
			for (String cookie : this.cookies) {
				conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
			}
		}
		conn.setRequestProperty("Connection", "keep-alive");
		conn.setRequestProperty("Referer", "https://accounts.google.com/ServiceLoginAuth");
		conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		conn.setRequestProperty("Content-Length", Integer.toString(postParams.length()));
	
		conn.setDoOutput(true);
		conn.setDoInput(true);
	
		// Send post request
		DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
		wr.writeBytes(postParams);
		wr.flush();
		wr.close();
	
		int responseCode = conn.getResponseCode();
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + postParams);
		System.out.println("Response Code -----------: " + responseCode);
	
		BufferedReader in =
	             new BufferedReader(new InputStreamReader(conn.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
	
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
		// System.out.println(response.toString());
	}

	private String GetPageContent(String url) throws Exception 
	{

		URL obj = new URL(url);
		conn = (HttpsURLConnection) obj.openConnection();

		// default is GET
		conn.setRequestMethod("GET");

		conn.setUseCaches(false);

		// act like a browser
		conn.setRequestProperty("User-Agent", USER_AGENT);
		conn.setRequestProperty("Accept",
			"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		if (cookies != null) {
			for (String cookie : this.cookies) {
				conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
			}
		}
		int responseCode = conn.getResponseCode();
		//System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code 1: " + responseCode);

		BufferedReader in =
	            new BufferedReader(new InputStreamReader(conn.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// Get the response cookies
		setCookies(conn.getHeaderFields().get("Set-Cookie"));

		return response.toString();

	}
	
	private void GetPageContentToFile(String url, String filePath) throws Exception 
	{
		Log.i("Search","GetPageContentToFile" + url);
		URL obj = new URL(url);
		conn = (HttpsURLConnection) obj.openConnection();

		// default is GET
		conn.setRequestMethod("GET");

		conn.setUseCaches(false);

		// act like a browser
		conn.setRequestProperty("User-Agent", USER_AGENT);
		conn.setRequestProperty("Accept",
			"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		if (cookies != null) {
			for (String cookie : this.cookies) {
				conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
			}
		}
		int responseCode = conn.getResponseCode();
		//System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code 2: " + responseCode);

		BufferedReader in =
	            new BufferedReader(new InputStreamReader(conn.getInputStream()));
		String inputLine;
		//StringBuffer response = new StringBuffer();
	 	FileOutputStream fs = new FileOutputStream(filePath);

		while ((inputLine = in.readLine()) != null) {
			fs.write(inputLine.getBytes());
			fs.write('\n');
			//response.append(inputLine);
		}
		in.close();
		fs.close();
		// Get the response cookies
		setCookies(conn.getHeaderFields().get("Set-Cookie"));

		//return response.toString();

	}

	public String getFormParams(String html, String username, String password)
			throws UnsupportedEncodingException 
	{

		//System.out.println("Extracting form's data...");

		Document doc = Jsoup.parse(html);

		// Google form id
		Element loginform = doc.getElementById("gaia_loginform");
		Elements inputElements = loginform.getElementsByTag("input");
		List<String> paramList = new ArrayList<String>();
		for (Element inputElement : inputElements) {
			String key = inputElement.attr("name");
			String value = inputElement.attr("value");

			if (key.equals("Email"))
				value = username;
			else if (key.equals("Passwd"))
				value = password;
			paramList.add(key + "=" + URLEncoder.encode(value, "UTF-8"));
		}

		// build parameters list
		StringBuilder result = new StringBuilder();
		for (String param : paramList) {
			if (result.length() == 0) {
				result.append(param);
			} else {
				result.append("&" + param);
			}
		}
		return result.toString();
	}

	public List<String> getCookies() 
	{
		return cookies;
	}

	public void setCookies(List<String> cookies) 
	{
		this.cookies = cookies;
	}
	
	public SearchYouTube(String _condition, String _tempFolder)
	{
		Log.i("Multak", "SearchYouTube");
		strCondition = _condition; 
		TempFolder = _tempFolder;
	}
	
	public void ClearSearch()
	{
		searchReady = 0;
		
		videoList.ClearSearchItem();
		SearchFlag = 0;
		try {
			String ss = URLEncoder.encode(strCondition, "UTF-8");
			File f = new File(TempFolder + "/" + ss + ".html");
			if(f.exists() == true)
			{
				f.delete();
			}
			for(int i = 0 ; i < pageUrlList.size(); i++)
			{
				File f2 = new File(TempFolder + "/" + ss + "_" + i + ".html");
				if(f2.exists() == true)
				{
					f2.delete();
				}
			}
			
		} catch (Exception e) {

			e.printStackTrace();
		}
		pageUrlList.clear();
		pageUrlOK.clear();
	}
	
	public void StartSearch()
	{
		if(SearchFlag == 1)
		{
			return;
		}
		SearchFlag = 1;
		
		new Thread(new Runnable() {
			public void run() {
				Document doc;
				try {
					searchReady = 0;
					//Log.i("Multak", "SearchYouTube " + strCondition);
					
					String ss = URLEncoder.encode(strCondition, "UTF-8");
					String FilePath = TempFolder + "/" + ss + ".html";
					File f = new File(FilePath);
					if(f.exists() == true)
					{
						
						f.delete();
					}	
						
						
					{
						CookieHandler.setDefault(new CookieManager());
/*
						if(LoginGoogle == false)
						{
							// 1. Send a "GET" request, so that you can extract the form's data.
							String page = GetPageContent(googleUrl);
							String postParams = getFormParams(page, "gsam12@multak.com", "googledeveloper##");
						//	String postParams = getFormParams(page, "guxxxmmm@gmail.com", "guxm8132");	
							// 2. Construct above post's content and then send a POST request for
							// authentication
							sendPost(googleUrl, postParams);
							
							LoginGoogle = true;
						}
						*/
						GetPageContentToFile(strPrefixSearch + ss, FilePath);
						//Log.i("Multak", "[Search]");
						f = new File(FilePath);
					}
					
					doc = Jsoup.parse(f, "UTF-8");
					
					//String title = doc.title();
					//Log.i("Multak", "[Found TITLE2]" + title);
					
					Elements elements = doc.select("ol[class=item-section]");
					Elements elementsList = elements.select("a[href^=/watch?v=][title]");
					
					for (Element temp : elementsList) {  
			            //parmas.put(temp.attr("name"), temp.attr("value"));// 鎶婃墍鏈夊彇鍑虹殑input锛屽彇鍑哄叾name锛屾斁鍏ap涓�
						//Log.i("Multak", "[QUERY]" + temp.attr("href"));
						//Log.i("Multak", "[]" + temp.attr("title"));
						
						VideoSearchList.YouTubeItem item = new VideoSearchList.YouTubeItem();
						item.id = new VideoSearchList.YouTubeItem._id();
						item.snippet = new VideoSearchList.YouTubeItem._snippet();
						item.snippet.thumbnails = new VideoSearchList.YouTubeItem._snippet._thumbnails();
						item.snippet.thumbnails.high = new VideoSearchList.YouTubeItem._snippet._thumbnails._high();
						
						
						String[] stringsplit = temp.attr("href").replace("/watch?v=", "").split("&");
						//item.id.videoId = temp.attr("href").replace("/watch?v=", "");
						item.id.videoId = stringsplit[0];
						item.snippet.title = temp.attr("title");
						//item.snippet.thumbnails.high.url = "https://i.ytimg.com/vi/" + item.id.videoId + "/0.jpg";
						//String[] sstr = item.id.videoId.split("&list=");
						
						item.snippet.thumbnails.high.url = "https://i.ytimg.com/vi/" + item.id.videoId + "/0.jpg";
						//item.snippet.thumbnails.high.url = "https://i.ytimg.com/vi/" + sstr[0] + "/0.jpg";
						item.snippet.thumbnails.high.width = 480;
						item.snippet.thumbnails.high.height = 360;
						
						videoList.AddSearchItem(item);
						Log.i("Search","videoList size " + videoList.GetSearchCount());
			        } 
					
					//String html = elements.html();
					//Log.i("Multak", "[Found HTMLA]" + html);
					
					Elements elements2 = doc.select("div[class^=branded-page-box]");
					Log.i("Search","elements2 size " + elements2.size());
					Elements elementsPageList = elements2.select("a[href^=/results?]");
					Log.i("Search","elementsPageList size " + elementsPageList.size());
					for (Element temp : elementsPageList) {  
						String url = "https://www.youtube.com" + temp.attr("href");
						Log.i("Search","pageUrlList " + url);
						pageUrlList.add(url);
					}
					if(f.exists())
					{
						f.delete();
					}
					searchReady = 1;
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					searchReady = 2;
				}
				
			}
        }).start();
	}
	
	public void SearchPage(int pageNo)
	{
		Log.i("Search","SearchPage 1");
		if(currentSearchNo >= 0)
		{
			return;
		}
		Log.i("Search","SearchPage 2");
		if(pageUrlOK.contains(currentSearchNo) == true)
		{
			return;
		}
		Log.i("Search","SearchPage 3");
		if(pageNo >= 0 && pageNo < pageUrlList.size())
		{
			Log.i("Search","SearchPage 4");
			currentSearchNo = pageNo;
			searchReady = 0;
			new Thread(new Runnable() {
				public void run() {
					Document doc;
					try {
						
						String ss = URLEncoder.encode(strCondition, "UTF-8");
						String FilePath = TempFolder + "/" + ss + "_" + currentSearchNo + ".html";
						File f = new File(FilePath);
						
						
						if(f.exists() == true)
						{
							
							f.delete();
						}
						
						
						{
							/*
							if(LoginGoogle == false)
							{
								CookieHandler.setDefault(new CookieManager());
	
								// 1. Send a "GET" request, so that you can extract the form's data.
								String page = GetPageContent(googleUrl);
								String postParams = getFormParams(page, "gsam12@multak.com", "googledeveloper##");
								//String postParams = getFormParams(page, "guxxxmmm@gmail.com", "guxm8132");
								// 2. Construct above post's content and then send a POST request for
								// authentication
								sendPost(googleUrl, postParams);
								
								LoginGoogle = true;
							}*/
							Log.i("Search","SearchPage 5");
							GetPageContentToFile(pageUrlList.get(currentSearchNo), FilePath);
							f = new File(FilePath);
						}
						
						doc = Jsoup.parse(f, "UTF-8");
						
						//String title = doc.title();
						//Log.i("Multak", "[Found TITLE2]" + title);
						
						Elements elements = doc.select("ol[class=item-section]");
						Elements elementsList = elements.select("a[href^=/watch?v=][title]");
						
						for (Element temp : elementsList) {  
				            //parmas.put(temp.attr("name"), temp.attr("value"));// 鎶婃墍鏈夊彇鍑虹殑input锛屽彇鍑哄叾name锛屾斁鍏ap涓�
							//Log.i("Multak", temp.attr("href"));
							//Log.i("Multak", temp.attr("title"));
							Log.i("Search","SearchPage 6");
							VideoSearchList.YouTubeItem item = new VideoSearchList.YouTubeItem();
							item.id = new VideoSearchList.YouTubeItem._id();
							item.snippet = new VideoSearchList.YouTubeItem._snippet();
							item.snippet.thumbnails = new VideoSearchList.YouTubeItem._snippet._thumbnails();
							item.snippet.thumbnails.high = new VideoSearchList.YouTubeItem._snippet._thumbnails._high();
							
							//item.id.videoId = temp.attr("href").replace("/watch?v=", "");
							String[] stringsplit = temp.attr("href").replace("/watch?v=", "").split("&");
							//item.id.videoId = temp.attr("href").replace("/watch?v=", "");
							item.id.videoId = stringsplit[0];

							item.snippet.title = temp.attr("title");
							//String[] sstr = item.id.videoId.split("&list=");
							
							item.snippet.thumbnails.high.url = "https://i.ytimg.com/vi/" + item.id.videoId + "/0.jpg";
							//item.snippet.thumbnails.high.url = "https://i.ytimg.com/vi/" + sstr[0] + "/0.jpg";
							item.snippet.thumbnails.high.width = 480;
							item.snippet.thumbnails.high.height = 360;
							
							videoList.AddSearchItem(item);
							Log.i("Search","videoList size11 " + videoList.GetSearchCount());
				        } 
						pageUrlOK.add(currentSearchNo);
						if(f.exists())
						{
							f.delete();
						}	
						searchReady = 1;
						currentSearchNo = -1;
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						searchReady = 2;
						currentSearchNo = -1;
					} 
				}
	        }).start();
		}
		
	}
	
}


