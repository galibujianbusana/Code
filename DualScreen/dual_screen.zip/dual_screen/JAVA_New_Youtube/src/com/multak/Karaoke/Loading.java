﻿package com.multak.Karaoke;


import java.io.File;

import com.multak.MultakStandard.BaseHelper;
import com.multak.MK8507MOA.R;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;

public class Loading extends View {
	
	private String infoString1 = "" ;
	private String infoString2 = "" ;
	public MyListener Loadinglistener ;
	
	public int m_width = 0;
	public int m_height = 0;
	
	public static int nTimes = 0;
	
	public SharedPreferences m_prefs;
	
	public String MyktvPath="51karapk";
	public int ShowFlag = 0;
	public Bitmap bm;
	
	private static Handler mHandler = new Handler();
	public Loading(Context context, int w, int h) {
		super(context);
		try 
		{
			File ff = new File("/mnt/sda2/KARAOKE/advertisement/loading.png");
			if(ff.exists() == true) {
				ShowFlag = 1;
				BitmapFactory.Options options = new BitmapFactory.Options();
				options.outHeight = 200;
    		    options.inJustDecodeBounds = false;
    		    options.inSampleSize = 1;
    		    bm = BitmapFactory.decodeFile("/mnt/sda2/KARAOKE/advertisement/loading.png", options);
    		    bm = Bitmap.createScaledBitmap(bm, w, h, true);
			} else {
				this.setBackgroundResource(R.drawable.loading);
			}	
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			ShowFlag = 0;
			this.setBackgroundResource(R.drawable.loading);
		}
		
		this.setFocusable(true);
		this.setPadding(0, 0, 0, 0);
		
		m_width = w;
		m_height = h;
		nTimes = 0;
		BaseHelper.log("Logo", String.format("Screen %d, %d", m_width, m_height));
		
		mHandler.postDelayed(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Loadinglistener.ControlUARTJava(1);
			}
		}, 2000);
	}
	
	public void setVisibility(int visibility) {
		super.setVisibility(visibility);
	}

	public void setLoadingListener(MyListener listener) {
		this.Loadinglistener = listener;
	}
	
	public void setLoadingTitle(String title1, String title2){
		this.infoString1 = title1;
		this.infoString2 = title2;
	}
	
	public void setKTVPath(String ktvPath) {
		
	}
	
	protected void onDraw(Canvas canvas) {
		nTimes++;
		Paint paint = new Paint();
		paint.setColor(Color.BLACK);
		paint.setAntiAlias(true);
		
		if(ShowFlag == 0) {
			paint.setTextSize(15);
			paint.setTextAlign(Paint.Align.CENTER);
			canvas.drawText(infoString1, (717.0f + 20.0f) * (m_width / 800.0f), (65.0f + 10.0f) * (m_height / 480.0f), paint);
		} else {
			canvas.drawBitmap(bm, 0, 0, paint);
			paint.setTextSize(15);
			paint.setTextAlign(Paint.Align.CENTER);
			canvas.drawText(infoString1, (717.0f) * (m_width / 800.0f), (65.0f) * (m_height / 480.0f), paint);
		}
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		BaseHelper.log("Logo", "Onkey event");
		
		switch(keyCode) {
		case KeyEvent.KEYCODE_BACK:
			break;
		}
		return true;
	}

}
