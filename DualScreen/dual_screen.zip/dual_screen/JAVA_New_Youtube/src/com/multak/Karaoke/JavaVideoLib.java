package com.multak.Karaoke;

import java.util.TimerTask;

import com.android.grafika.gles.EglCore;
import com.android.grafika.gles.FullFrameRect;
import com.android.grafika.gles.Texture2dProgram;
import com.android.grafika.gles.WindowSurface;


import com.multak.server.CustomerInfo;
import com.multak.server.OKSServer;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.graphics.SurfaceTexture.OnFrameAvailableListener;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.TrackInfo;
import android.net.Uri;
import android.opengl.GLES20;
import android.os.BatteryStats.Timer;
import android.os.Handler;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.Toast;
import com.multak.Karaoke.KaraokeVGA;
import com.multak.MK8507MOA.MainActivity;
import com.multak.MK8507MOA.R;
import com.squareup.picasso.Picasso;

import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveVideoTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.util.Util;


public class JavaVideoLib {
	private static String TAG = "JavaVideoLib";

	public static final int m_stopped = 0;
	public static final int m_parsing = 1;
	public static final int m_parsed = 2;
	public static final int m_playing = 3;
	public static final int m_paused = 4;
	public static final int m_stopping = 5;
	
	private static MediaPlayer m_mp = null;
	private static SimpleExoPlayer mediaPlayerBoth = null;
	private static SurfaceView m_view = null;
	private static SurfaceView m_viewSecond = null;
	private static Context m_context = null;
	private static SurfaceHolder m_holder = null;
	private static SurfaceHolder m_holderSecond = null;
	
	private static int m_cur_audio_channel = 0;
	private static int m_cur_audio_track = 0;
	private static int m_total_audio_track = 0;
	private static int m_playState = 0;
	private static int m_setnoaudio = 0;
	private static int m_curhandle = 0;
	
	private static boolean m_multiScreen = false;
	private static EglCore mEglCore = null;
	private static WindowSurface mDisplaySurfaceHDMI = null;
	private static WindowSurface mDisplaySurfaceVGA = null;
	private static SurfaceTexture mVideoTexture = null;
	public static Surface mVideoSurface = null;
	private static FullFrameRect mFullFrameBlit = null;
    private static float[] mTmpMatrix = new float[16];
    private static int mTextureId = 0;
	private static OnErrorListener m_OnErrListener = null;
	
	private static ImageView m_progress = null;
	private static Animation m_progressRotate = null;

    //for youtube
    private static String m_YouTubeVideoId;
    private static boolean m_UseYouTubePlayer = false;
    private static boolean m_progressNeedRefresh = true;
    public static boolean m_UseYouTubeEXO = false;
    
	private static Handler mHandler = new Handler();
	
	public static String PlayingURL = "";
	public static String lastBGVURL = "";
	public static int BGVSeekTime = 0;
	public static int mSeekFlag = 0;
	
	final public static int YTRetryCNT = 20;

	private static final int VISIBLE = 0;

	private static final int INVISIBLE = 0;

	private static final int GONE = 0;
	
	public static int YTRetry = YTRetryCNT;
	public static boolean YTPlayErr = false;
	
	public static String backurl = "";
	public static int backfiletype = 0;
	public static int backhandle = 0;
	
	public static Thread ThYoutubePlay = null;
	public static Timer TmYoutubePlay = null;
	public static TimerTask TmTaskYoutubePlay = null;
	
	private static void setProgressEnable(boolean arg0) {
		if(arg0) {
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					if(m_progress != null) {
						m_progress.setVisibility(View.VISIBLE);
						m_progress.startAnimation(m_progressRotate);
						Log.i(TAG,"setProgressEnable 1");
						if(m_progressNeedRefresh) {
							m_progressNeedRefresh = false;
							m_progress.requestLayout();
							Log.i(TAG,"m_progressNeedRefresh");
						}
					}
				}
			});
		} else {
			mHandler.post(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					if(m_progress != null) {
						Log.i(TAG,"setProgressEnable 0");
						m_progress.clearAnimation();
						m_progress.setVisibility(View.INVISIBLE);
					}
				}
			});
		}
	}
	
	public static void init() {
		Log.w(TAG, "JavaVideoLib.init");
		if (m_mp == null) {
			m_mp = new MediaPlayer();
		} else {
			Log.w(TAG, "JavaVideoLib.init called already");
			return;
		}

		
		
		
		
		m_mp.setOnInfoListener(new OnInfoListener() {
			@Override
			public boolean onInfo(MediaPlayer arg0, int arg1, int arg2) {
				// TODO Auto-generated method stub
				if (arg1 == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
					setProgressEnable(true);
				} else if (arg1 == MediaPlayer.MEDIA_INFO_BUFFERING_END) {
					setProgressEnable(false);
				}
				return false;
			}
		});
		
		m_mp.setOnErrorListener(new OnErrorListener() {
			@Override
			public boolean onError(MediaPlayer mp, int what, int extra) {
				// TODO Auto-generated method stub
				Log.d(TAG, "onError what = " + what);
				Log.d(TAG, "onError extra = " + extra);
				if (m_OnErrListener  != null) {
					m_OnErrListener.onError(mp, what, extra);
				}
				try
				{
					
					if(m_YouTubeVideoId != null)
					{
						if(!m_YouTubeVideoId.endsWith(".OKF") && !m_YouTubeVideoId.endsWith(".OKS")) {
							YTPlayErr = true;
							

							Log.d(TAG, "Retry left !!! " + YTRetry);
							if(YTRetry > 0)
								KaraokeLib.setStatus(8,0,0);
							else
								KaraokeLib.setStatus(8,1,0);
							return false;
						} 
						
					}	
					
					
				}catch(Exception e)
				{
					e.printStackTrace();
					
				}
				
				deinit();
				return false;
			}
		});

		m_mp.setOnPreparedListener(new OnPreparedListener() {
			public void onPrepared(MediaPlayer mp) {
				// TODO Auto-generated method stub
				Log.d(TAG, "onPrepared");
				m_cur_audio_track = -1;
				m_total_audio_track = 0;
				m_cur_audio_channel = 0;
				if (android.os.Build.VERSION.SDK_INT >= 16) {
					TrackInfo[] m_tracks = m_mp.getTrackInfo();
					for (TrackInfo t : m_tracks) {
						if (t.getTrackType() == TrackInfo.MEDIA_TRACK_TYPE_AUDIO) {
							m_total_audio_track++;
						}
					}
				}
								
				Log.w(TAG, "Java video init finish " + m_setnoaudio);
				if(m_setnoaudio == 1) {
					m_mp.setParameter(0x208, 3);
				} else {
					m_mp.setParameter(0x208, 0);
				}
				m_playState = m_parsed;
			}
		});

		m_mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {   
			// @Override   
			public void onCompletion(MediaPlayer arg0) {   
				// TODO Auto-generated method stub
				Log.d(TAG, "onCompletion");
				if(m_UseYouTubePlayer ||m_UseYouTubeEXO) {
					return;
				}
				if(PlayingURL.startsWith("/mnt"))
				{
					if(PlayingURL.endsWith(".OKF") || PlayingURL.endsWith(".okf"))
					{
						
					}
					else //bgv
					{
						BGVSeekTime = 0;
					
					}	
					
				}	
				deinit();
			}   
		});  
	}
	public static void CreateEXO(){
		
		
		
	}
	
	
	public static void playretry()
	{
		Log.d(TAG, "YouTube Play error,retry or use google play");
		if(--YTRetry >= 0){
			Log.d(TAG, "Retry left " + YTRetry);
			
			
			new Thread(new Runnable(){

				@Override
				public void run() {
					// TODO Auto-generated method stub
					try {
			            Thread.sleep(2000);
			        } catch (InterruptedException e) {
						e.printStackTrace();
			        }
					Log.d(TAG, "backurl " + backurl);
					Log.d(TAG, "backfiletype " + backfiletype);
					Log.d(TAG, "backhandle " + backhandle);
					play(backurl,backfiletype,backhandle);
				}
				
			}).start();
			
		}else{
			YTRetry = YTRetryCNT;

		}
	}
	public static void deinit() {
		setProgressEnable(false);
		if (m_mp != null) {
			Log.d(TAG, "deinit");
			m_mp.reset();
			m_mp.release();
			m_mp = null;
			try {
	            Thread.sleep(300);
	        } catch (InterruptedException e) {
				e.printStackTrace();
	        }
			m_playState = m_stopped;
			PlayingURL = "";
			Log.d(TAG, "deinit end");
			
			if(YTPlayErr == true)
			{
				
				playretry();
			}else{
				YTRetry = YTRetryCNT;
			}
				
		}
		
	}
	
	public static void setOnErrListener(OnErrorListener listener) {
		m_OnErrListener = listener;
	}
	
	public static void setDoubleScreen(boolean bMultiScreen, SurfaceView secondView) {
		m_multiScreen = bMultiScreen;
		m_viewSecond = secondView;
		if(m_multiScreen == true && secondView != null) {
	    	mEglCore = new EglCore(null, EglCore.FLAG_RECORDABLE);
			m_holderSecond = m_viewSecond.getHolder();
			m_holderSecond.addCallback(new SurfaceHolder.Callback() {
		        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		            Log.v(TAG, "vga format=" + format + ", width=" + width + ", height=" + height);
		        }

		        public void surfaceCreated(SurfaceHolder holder) {
		        	Log.v(TAG, "vga create");
					if(mDisplaySurfaceVGA == null) {
						mDisplaySurfaceVGA = new WindowSurface(mEglCore, holder.getSurface(), false);
			       		mDisplaySurfaceVGA.makeCurrent();
			        	mFullFrameBlit = new FullFrameRect(new Texture2dProgram(Texture2dProgram.ProgramType.TEXTURE_EXT));
			        	mTextureId = mFullFrameBlit.createTextureObject();
			        	mVideoTexture = new SurfaceTexture(mTextureId);
			        	mVideoSurface = new Surface(mVideoTexture);
			        	mVideoTexture.setOnFrameAvailableListener(new OnFrameAvailableListener() {
							@Override
							public void onFrameAvailable(SurfaceTexture arg0) {
								if(mDisplaySurfaceVGA != null) {
									mDisplaySurfaceVGA.makeCurrent();
									mVideoTexture.updateTexImage();
									mVideoTexture.getTransformMatrix(mTmpMatrix);
			
							        int viewWidth = m_viewSecond.getWidth();
							        int viewHeight = m_viewSecond.getHeight();
							        GLES20.glViewport(0, 0, viewWidth, viewHeight);
							        mFullFrameBlit.drawFrame(mTextureId, mTmpMatrix);
							        mDisplaySurfaceVGA.swapBuffers();    
							        
							        if(mDisplaySurfaceHDMI != null) {
							        	mDisplaySurfaceHDMI.makeCurrent();
							            viewWidth = m_view.getWidth();
							            viewHeight = m_view.getHeight();
							            GLES20.glViewport(0, 0, viewWidth, viewHeight);
							            
							            mFullFrameBlit.drawFrame(mTextureId, mTmpMatrix);
							            mDisplaySurfaceHDMI.swapBuffers();
							    	}
								}
							}
	                	});
					}
		        }

		        public void surfaceDestroyed(SurfaceHolder holder) {
		        	Log.v(TAG, "vga Destroyed");
		        	if(mDisplaySurfaceVGA != null) {
	                	 mDisplaySurfaceVGA.release();
	                	 mDisplaySurfaceVGA = null;
	            	 }
	                 if (mVideoSurface != null) {
	                	 mVideoSurface.release();
	                	 mVideoSurface = null;
	                 }
	                 if (mVideoTexture != null) {
	                	 mVideoTexture.release();
	                	 mVideoTexture = null;
	                 }
	                 if (mFullFrameBlit != null) {
	                     mFullFrameBlit.release(false);
	                     mFullFrameBlit = null;
	                 }
	                 if (mEglCore != null) {
	                     mEglCore.release();
	                     mEglCore = null;
	                 }
		        }
	        });
		}
	}
	
	public static void setView(SurfaceView view) {
		m_view = view;
		m_holder = m_view.getHolder();
		m_context = m_view.getContext();
		if(m_multiScreen == true) {
			m_holder.addCallback(new SurfaceHolder.Callback() {
		        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		            Log.v(TAG, "hdmi format=" + format + ", width=" + width + ", height=" + height);
		        }

		        public void surfaceCreated(SurfaceHolder holder) {
		        	Log.v(TAG, "hdmi create");
		        	mDisplaySurfaceHDMI = new WindowSurface(mEglCore, holder.getSurface(), false);
		        }

		        public void surfaceDestroyed(SurfaceHolder holder) {
	                 if(mDisplaySurfaceHDMI != null) {
	                	 mDisplaySurfaceHDMI.release();
	                	 mDisplaySurfaceHDMI = null;
	            	 }
		        }
			});
		}
	}
	
	public static void setView(ImageView view, Animation anim) {
		m_progress = view;
		m_progressRotate = anim;
	}
	
	public static int changeAudio(int index, int handle) {
		if(m_curhandle != handle) {
			return -1;
		}
		if(m_UseYouTubePlayer ||m_UseYouTubeEXO) {
			return -1;
		}
		
		if (m_mp == null) {
			return -1;
		} else if (m_setnoaudio == 1) {
			return -2;
		}
		Log.d(TAG, "changeAudio");

		index = (index+1)%2;
		if (m_total_audio_track > 1) {
			if (android.os.Build.VERSION.SDK_INT >= 16) {
				int n = 0;
				int aid = 0;
				TrackInfo[] m_tracks = m_mp.getTrackInfo();
				for (TrackInfo t : m_tracks) {
					if (t.getTrackType() == TrackInfo.MEDIA_TRACK_TYPE_AUDIO) {
						if (index == aid) {
							if (m_cur_audio_track != n) {
								m_cur_audio_track = n;
								m_mp.selectTrack(n);
							}
							Log.d(TAG, "track: " + n);
							return 0;
						}
						aid++;
					}
					n++;
				}
			}
		} else {
			m_cur_audio_channel = index;
			if (m_cur_audio_channel == 0) {			
				m_mp.setParameter(0x208, 1);
				Log.d(TAG, "channel: " + m_cur_audio_channel);
				return 0;
			} else if (m_cur_audio_channel == 1) {
				m_mp.setParameter(0x208, 2);
				Log.d(TAG, "channel: " + m_cur_audio_channel);
				return 0;
			}
		}
		return -1;
	}

	public static int getAudioTrackCnt(int handle) {
		if(m_curhandle != handle) {
			return 0;
		}
		if(m_UseYouTubePlayer || m_UseYouTubeEXO){
			return 0;
		}
		
		if (m_mp == null) {
			return 0;
		}
		return m_total_audio_track;
	}
	
	public static int getCurTime(int handle) {
		if(m_curhandle != handle) {
			return -1;
		}
		if(m_UseYouTubePlayer || m_UseYouTubeEXO){
			return -1;
		}

		if (m_mp != null && m_mp.isPlaying()) {
			return m_mp.getCurrentPosition();
		}
		return -1;
	}

	public static int getTotalTime(int handle) {
		if(m_curhandle != handle) {
			return -1;
		}
		if(m_UseYouTubePlayer || m_UseYouTubeEXO){
			return -1;
		}
		
		if (m_mp != null && m_mp.isPlaying()) {
			return m_mp.getDuration();
		}
		return -1;
	}

	public static void seek(int msec, int handle) {
		if(m_curhandle != handle) {
			return;
		}
		if(m_UseYouTubePlayer || m_UseYouTubeEXO){
			return;
		}

		if (m_mp != null) {
			m_mp.seekTo(msec);
			Log.d(TAG, "SEEK: " + msec);
		}
	}
	public static int laststate = 0;
	public static int getState(int handle) {
		if(m_curhandle == handle) {
			if(laststate != m_playState){
			
				Log.d(TAG, "getState: " + m_playState);
			
			}
			if(m_UseYouTubeEXO && laststate == m_parsed)
			{
				//m_UseYouTubeEXO
				//Log.d(TAG,"exostatus " + MainActivity.mediaPlayerBoth.getCurrentPosition());
				//if(MainActivity.mediaPlayerBoth.getCurrentPosition() > 0)
					m_playState = m_playing;
			}
			laststate = m_playState;
			return m_playState;
		}
		return m_stopped;
	}

	public static void setVol(int vol, int handle) {
		if(m_curhandle != handle) {
			return;
		}
		if(m_UseYouTubePlayer || m_UseYouTubeEXO){
			return;
		} 
		
		if (m_mp != null) {
			m_mp.setVolume((float)83/100.0f,(float)83/100.0f);
			Log.d(TAG, "SETVOL: " + 83);
		}
		
		
	}
	
	public static void setNoAudio(int on, int handle) {
		if(m_curhandle != handle) {
			return;
		}
		if(m_UseYouTubePlayer || m_UseYouTubeEXO){
			return;
		} 
		
		m_setnoaudio = on;
		if (m_mp != null) {
			if(on == 1) {
				m_mp.setParameter(0x208, 3);
			} else {
				m_mp.setParameter(0x208, 0);
			}
			Log.d(TAG, "set no audio " + on);
		}
	}
	
	public static void resume(int handle) {
		if(m_curhandle != handle) {
			return;
		}
		if(m_UseYouTubePlayer){
			Karaoke.mYoutubeService.resume();
			return;
		}
		if(m_UseYouTubeEXO){
			//MainActivity.EXOResume();
			return;
		}
		if (m_mp != null) {
			m_mp.start();
			m_playState = m_playing;
			Log.d(TAG, "RESUME");
		}
		
	}

	public static void pause(int handle) {
		if(m_curhandle != handle) {
			return;
		}
		if(m_UseYouTubePlayer){
			Karaoke.mYoutubeService.pause();
			return;
		}
		if(m_UseYouTubeEXO){
			//MainActivity.EXOPause();
			return;
		}
		if (m_mp != null) {
			m_mp.pause();
			m_playState = m_paused;
			Log.d(TAG, "PAUSE");
		}
		
	}
	
	public static void stopproc()
	{
		if (m_mp != null) {
			
			if(PlayingURL.startsWith("/mnt"))
			{
				if(PlayingURL.endsWith(".OKF") || PlayingURL.endsWith(".okf") || PlayingURL.startsWith("/mnt/sda3"))
				{
					
				}
				else //bgv
				{
					
					BGVSeekTime = m_mp.getCurrentPosition();
					Log.i(TAG,"BGV stop time " + BGVSeekTime);
				}	
				
			}	
			m_playState = m_stopping;
			if(!m_UseYouTubePlayer)
				m_mp.stop();
			deinit();
			Log.d(TAG, "STOP");
		}
	}
	public static void stop(int handle) {
		if(m_curhandle != handle) {
			return;
		}
		if(m_UseYouTubePlayer){
			Karaoke.mYoutubeService.stop();
			return;
		}
		if(m_UseYouTubeEXO){
			//MainActivity.EXOStop();
			return;
		}
		if(!m_UseYouTubePlayer)
			stopproc();
		
	}
	
	public void setInitSeek(int mstime) {
		BGVSeekTime = mstime;
		mSeekFlag = 1;
		return;
	}
	public static void start(int handle) {
		if(m_curhandle != handle) {
			return;
		}
		if(m_UseYouTubePlayer || m_UseYouTubeEXO ) {
			return;
		}
		
		if (m_mp != null) {
			
			if(mSeekFlag == 1)
			{
				mSeekFlag = 0;
				m_mp.seekTo(BGVSeekTime);
				
			}	
			m_mp.start();
			m_playState = m_playing;
			Log.d(TAG, "START");
		}
		
	}
	

	
	public static int play(String url, int filetype, int handle) {
		int ret = -1;
		
		
//test
	//	if(true){
			
	//		return 0;
	//	}
		Log.i(TAG,"status befor play a " + m_playState);
		try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
			e.printStackTrace();
        }	
		m_curhandle = handle;
		

		Log.i(TAG,"status befor play b " + m_playState);
		
		
		
		
		
		
		
		if (m_holder == null) {
			Log.d(TAG, "=================================");
			Log.d(TAG, "=> ERROR: call setView() before play()");
			Log.d(TAG, "=================================");
			return ret;
		}
		
		
		
		YTPlayErr = false;
		m_UseYouTubePlayer = false;
		m_UseYouTubeEXO = false;
		if(url.startsWith("/mnt"))
			init();
		if(url.startsWith("/mnt")){
			
			if(m_multiScreen == false) {
				m_mp.setDisplay(m_holder);
				
			} else {
				m_mp.setSurface(mVideoSurface);
				
			}
			
		}
		
		m_playState = m_parsing;
		
		try {
			if(url.startsWith("/mnt")) {
				setProgressEnable(false);
				PlayingURL = url;
				
				Karaoke.mYoutubeService.HideYoubuteView();
				//KaraokeHDMI.mVideoSurfaceView.setVisibility(View.VISIBLE);
				
				
				mHandler.postDelayed(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						Log.i("YouTube","mYoutubeTitle invisibility");

						//0313
						KaraokeVGA.SetYoutubteTitleMin();
					}
				}, 200);
				if(url.endsWith(".OKF") || url.endsWith(".okf"))
				{
					
					Log.i("OKServer","Geturl 1 = " + url);
	        		CustomerInfo.SetCommonKey("af8893c5");
	        		//CustomerInfo.SetDecodeKey("MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKRffOFS2gljPZa8FVMi+yL0yBUZCIFsDs0KTL3wNQ0gSMJeoTNb13InPUxxvy9F1jdePenXxf/KoE46AJM/q3rf3qD0o/3XjklVnzYNgLZ7W6aCvLRnNeNY5j+9yrABYVRbLaUgWySegH6SBLnsjtMZmWchrSzLDEPtYlJoowwBAgMBAAECgYAEISwDgy/cJYSiGVaV0J6rmae/M/JNQhg7GYOlD/hdPI7nZzY4kpmekhLNrVvmxaPknzcB/XxJeV8+p+Fk0aguszodYigki6gieruXpoBYKTA6bDhnjlgx7g3jOfpaba7v9Lr5bTbt05vLhYG9B45dN1ro5LFP0rlnE505+RB0gwJBAOYLx//njOO3BLj5Ctx5/fs+9qzxS0leAnxUyE06N4Zt5HYGx/Gkz7l4LxYjGCAjrMj1qNbewIr60fNuWYZby3MCQQC26u4PKfJEMlvggWphTdQD+jr/uUEKmi/2e/dr9xpUpUk7YIXtlod/e/fmqBkpkYLeut8VNgx32dBZ1n61RxW7AkBHESCqB8hYmLOWySj3z6AMu/jMmIZflfFCo5Z1dSSuHMjVRWcDWZzqeRxixFixpRO9yVZtescUqEOv5kk13qnNAkB2JIz3/Fa+12viOJRWHqeWnhNnQecRiv75i54F/Mbj7xG6qSA3kWcY3yABuYbvA03sv/QARjWNX4Cj1ddnDG+rAkEAiATC1mgz7nOmnBlTypKyfaCK+cEbnrFXeRePKIcT+08y1spX9D1ivZ+8dXLsNSfM1GS9TNCYav9yrVXVcSyxxA==");
	        		//Log.i("OKServer","Server url 1 = " + OKSServer.getUriFromFileOKF(url, "MTVServer1"));
	        		url = OKSServer.getUriFromFileOKF(url, "MTVServer1");
	        		Log.i("OKServer","Server url 1 = " + url);
	        		m_mp.setDataSource(m_context, Uri.parse(url), null);
	        		m_mp.prepareAsync();
				}
				else//bgv
				{
					m_mp.setDataSource(m_context, Uri.parse(url), null);
					m_mp.prepareAsync();
					if(url.startsWith("/mnt/sda3"))
					{
						mSeekFlag = 0;
					}
					else
					{
						if(url.equals(lastBGVURL) == false)
						{
							
							BGVSeekTime = 0;
							mSeekFlag = 0;
						}
						else
							mSeekFlag = 1;

						lastBGVURL = url;
						
					}	
					
				}	
					
				
				
			} else {
				backurl = url;
				backfiletype = filetype;
				backhandle = handle;

				
				
				//ThYoutubePlay = new Thread(new ThYoutubePlay(),"ThYoutubePlay");
				//ThYoutubePlay.setDaemon(true);
				//ThYoutubePlay.start();
				
				m_YouTubeVideoId = url;
				setProgressEnable(false);
				
				new Thread(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						
						//m_UseYouTubePlayer = true;
						//Karaoke.mYoutubeService.playYoutubeVideo(m_YouTubeVideoId);
						
						try {
							Log.w("YouTube", m_YouTubeVideoId);
							
							mHandler.postDelayed(new Runnable() {
								@Override
								public void run() {
									// TODO Auto-generated method stub
									KaraokeVGA.SetYoutubteTitleNorm();
									
									Uri uri = Karaoke.MapYPIC.get(m_YouTubeVideoId);
									if(uri != null){
										Log.i("YouTube","Ypic " + uri);
										Picasso.with(KaraokeVGA.mYoutubeTitle.getContext()).load(uri).placeholder(R.drawable.loading_thumbnail).error(R.drawable.no_thumbnail).into(KaraokeVGA.mYoutubeTitle);
									}
									/*
									YouTubeListAdapter adapter = (YouTubeListAdapter)Karaoke.mGridView.getAdapter();
									YouTubeListItem item = adapter.findItemData(m_YouTubeVideoId);
									if(item != null){
										Log.i("YouTube","Ypic " + item.m_videoThumbUrl);
										Uri uri = Uri.parse(item.m_videoThumbUrl);
										
										
					
										
										Picasso.with(KaraokeVGA.mYoutubeTitle.getContext()).load(uri).placeholder(R.drawable.loading_thumbnail).error(R.drawable.no_thumbnail).into(KaraokeVGA.mYoutubeTitle);
									}*/
								}
							}, 200);
							
							
							
								/*String uri = "";
								for(int i = 0; i < 3; i++) {
									uri = Karaoke.mYoutubeService.calculateYouTubeUrl(m_YouTubeVideoId);
									
									if(!uri.equals("")) {
										break;
									}
								}
								if(!uri.equals("")) {

									m_UseYouTubeEXO = true;
									Log.i(TAG,"EXO uri " + uri);
									Karaoke.mYoutubeService.playYoutubeEXO(uri);
									setProgressEnable(false);
								} else {
									m_UseYouTubePlayer = true;
									Karaoke.mYoutubeService.playYoutubeVideo(m_YouTubeVideoId);
								}*/
									Log.i(TAG,"m_YouTubeVideoId " + m_YouTubeVideoId);
								m_UseYouTubePlayer = true;
								Karaoke.mYoutubeService.playYoutubeVideo(m_YouTubeVideoId);
								KaraokeVGALib.setStatus(2,-1,0);
							
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							m_UseYouTubePlayer = true;
							Karaoke.mYoutubeService.playYoutubeVideo(m_YouTubeVideoId);
						}
					}
				}).start();
				
				
				
				/*
				new Thread(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						
						
						
						try {
							Log.w("YouTube", m_YouTubeVideoId);
							
							if(YTRetry == 0){
								m_UseYouTubePlayer = true;
								Karaoke.mYoutubeService.playYoutubeVideo(m_YouTubeVideoId);
							}
							else{
								String uri = "";
								for(int i = 0; i < 5; i++) {
									uri = Karaoke.mYoutubeService.calculateYouTubeUrl(m_YouTubeVideoId);
									
									if(!uri.equals("")) {
										break;
									}
								}
								if(!uri.equals("")) {
									m_mp.setDataSource(m_context, Uri.parse(uri), null);
									m_mp.prepareAsync();
									
									setProgressEnable(false);
								} else {
									m_UseYouTubePlayer = true;
									Karaoke.mYoutubeService.playYoutubeVideo(m_YouTubeVideoId);
								}
								
							}
							
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							m_UseYouTubePlayer = true;
							Karaoke.mYoutubeService.playYoutubeVideo(m_YouTubeVideoId);
						}
					}
				}).start();
				*/
			}
			ret = 0;
			Log.d(TAG, "PLAY");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}
	/*
	static boolean YUrlReady = false;
	static class ThYoutubePlay implements Runnable{
		@Override
		public void run(){
			//while(true){
				Log.i(TAG,"ThYoutubePlay ");
				
					
					try {
						Log.w("YouTube", m_YouTubeVideoId);
						
							YUrlReady = false;
							String uri = "";
							for(int i = 0; i < 5; i++) {
								uri = Karaoke.mYoutubeService.calculateYouTubeUrl(m_YouTubeVideoId);
								
								if(!uri.equals("")) {
									break;
								}
							}
							YUrlReady = true;
							Log.i("Youtube","YUrl " + uri);
							if(!uri.equals("")) {

								m_UseYouTubeEXO = true;
								Log.i(TAG,"EXO uri " + uri);
								Karaoke.mYoutubeService.playYoutubeEXO(uri);
								setProgressEnable(false);
							} else {
								m_UseYouTubePlayer = true;
								Karaoke.mYoutubeService.playYoutubeVideo(m_YouTubeVideoId);
							}
							
						
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						m_UseYouTubePlayer = true;
						Karaoke.mYoutubeService.playYoutubeVideo(m_YouTubeVideoId);
					}
				}
					
					
				//} 
	}
		*/

	public static int getYouTubePlayerStatus()
	{
		return m_playState;
	}
	public static void setYouTubePlayerStatus (int status) {
		if(m_UseYouTubePlayer) {
			if(m_playState == m_stopped) {
				deinit();
			} else {
				m_playState = status;
			}
		}
	}

	public static void setYouTubeEXOStatus (int status) {
		if(m_UseYouTubeEXO) {
			Log.i(TAG,"YouTubeEXO status " + status);
			if(status == m_stopping) {
				Log.i(TAG,"YouTubeEXO m_stopping aaa");
				m_playState = status;
				deinit();
			} else {
				m_playState = status;
			}
		}
	}
	
	public static void youTubePlayerOnError () {
		if(m_UseYouTubePlayer) {
			m_playState = m_parsed;
			mHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					deinit();
				}
			}, 200);
		}
	}
	public static void youTubeEXOOnError () {
		if(m_UseYouTubeEXO) {
			m_playState = m_parsed;
			/*YTPlayErr = true;
			

			Log.d(TAG, "Retry left !!! " + YTRetry);
			if(YTRetry > 0)
				KaraokeLib.setStatus(8,0,0);
			else
				KaraokeLib.setStatus(8,1,0);*/
			mHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					//deinit();
					//MainActivity.EXOStop();
				}
			}, 200);
		}
	}
}
