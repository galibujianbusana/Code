package com.multak.Karaoke;

public class MultakRunnable implements Runnable {

	public int m_IntParam;
	public String m_StrParam;
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
}
