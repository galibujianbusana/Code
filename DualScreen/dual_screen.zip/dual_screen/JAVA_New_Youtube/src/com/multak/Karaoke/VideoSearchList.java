package com.multak.Karaoke;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

import android.util.Log;


public class VideoSearchList{
	private List<YouTubeItem> items = new ArrayList<YouTubeItem>();
	private List<String> videoIDList = new ArrayList<String>();
	
	public void AddSearchItem(YouTubeItem item)
	{
		Log.i("Search","AddSearchItem " + item.id.videoId);
		if(videoIDList.contains(item.id.videoId) == false)
		{
			Log.i("Search","AddSearchItem11 " + item.id.videoId);
			videoIDList.add(item.id.videoId);
			items.add(item);
		}
	}
	
	public void ClearSearchItem()
	{
		videoIDList.clear();
		items.clear();
	}
	
	public YouTubeItem GetSearchItem(int pos)
	{
		if(pos >= 0 && pos < items.size())
		{
			return items.get(pos);
		}
		
		return null;
	}
	
	public int GetSearchCount()
	{
		return items.size();
	}
	
	public static String access = "";
	

	public static class YouTubeItem
	{
		public _id id;
		public _snippet snippet;
		
		public static class _id
		{
			public String videoId;
		}
		
		public static class _snippet
		{
			public String title;
			public _thumbnails thumbnails;
			
			public static class _thumbnails
			{
				public _high high;
				public static class _high
				{
					public String url;
					public int width;
					public int height;
				}
			}
		}
		
	}
}