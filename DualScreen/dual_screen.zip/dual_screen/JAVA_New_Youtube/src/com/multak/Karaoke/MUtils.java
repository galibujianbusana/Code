package com.multak.Karaoke;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.security.GeneralSecurityException;
import java.util.Enumeration;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import android.net.Uri;

public class MUtils
{
	static int sActiveTabIndex = -1;
	
	public static Uri g_uri;

    public static void deleteDir(File dir) { 
        if (dir == null || !dir.exists() || !dir.isDirectory()) 
            return; // 检查参数 
        for (File file : dir.listFiles()) { 
            if (file.isFile()) 
                file.delete(); // 删除所有文件 
            else if (file.isDirectory()) 
                deleteDir(file); // 递规的方式删除文件夹 
        } 
        dir.delete();// 删除目录本身 
    } 
    
    public static void copyFile(String oldPath, String newPath) { 
        try { 
            int bytesum = 0; 
            int byteread = 0; 
            File oldfile = new File(oldPath); 
            if (oldfile.exists()) { //文件存在时 
                InputStream inStream = new FileInputStream(oldPath); //读入原文件 
                FileOutputStream fs = new FileOutputStream(newPath); 
                byte[] buffer = new byte[1444];
                while ( (byteread = inStream.read(buffer)) != -1) { 
                    bytesum += byteread; //字节数 文件大小 
                    System.out.println(bytesum); 
                    fs.write(buffer, 0, byteread); 
                } 
                inStream.close(); 
            } 
        } 
        catch (Exception e) { 
            System.out.println("复制单个文件操作出错"); 
            e.printStackTrace();
        } 

    } 
    
    public static void deleteFile(String FilePath) 
    {
    	File file = new File(FilePath);
    	if (file.exists()) { // 判断文件是否存在
    		if (file.isFile()) { // 判断是否是文件
    			file.delete(); // delete()方法 你应该知道 是删除的意思;
    		} else if (file.isDirectory()) { // 否则如果它是一个目录
    		
    		} else {
    			
    		}
    	}
    }
    
    public static void copyFolder(String oldPath, String newPath) { 

        try { 
            (new File(newPath)).mkdirs(); //如果文件夹不存在 则建立新文件夹 
            File a=new File(oldPath); 
            String[] file=a.list(); 
            File temp=null; 
            for (int i = 0; i < file.length; i++) { 
                if(oldPath.endsWith(File.separator)) { 
                    temp=new File(oldPath+file[i]); 
                }  else { 
                    temp=new File(oldPath+File.separator+file[i]); 
                } 

                if(temp.isFile()) { 
                    FileInputStream input = new FileInputStream(temp); 
                    FileOutputStream output = new FileOutputStream(newPath + "/" + 
                            (temp.getName()).toString()); 
                    byte[] b = new byte[1024 * 5]; 
                    int len; 
                    while ( (len = input.read(b)) != -1) { 
                        output.write(b, 0, len); 
                    } 
                    output.flush(); 
                    output.close(); 
                    input.close(); 
                } 
                if(temp.isDirectory()){//如果是子文件夹 
                    copyFolder(oldPath+"/"+file[i],newPath+"/"+file[i]); 
                } 
            } 
        } 
        catch (Exception e) { 
            System.out.println("复制整个文件夹内容操作出错"); 
            e.printStackTrace();
        } 
    }
    
    public static String computeSignature(String baseString, String keyString) throws GeneralSecurityException, UnsupportedEncodingException {
        SecretKey secretKey = null;
        byte[] keyBytes = keyString.getBytes();
        secretKey = new SecretKeySpec(keyBytes, "HmacSHA256");
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKey);
        
        byte[] text = baseString.getBytes();
        byte[] digest = mac.doFinal(text);
        
        BigInteger hash = new BigInteger(1, digest);
        String enc = hash.toString(16);
        if ((enc.length() % 2) != 0) {
                enc = "0" + enc;
        }
        return enc.toLowerCase();
    }
    
    public static String getLocalIpAddress() {    
    	try {    
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {    
                 NetworkInterface intf = en.nextElement();    
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {    
                     InetAddress inetAddress = enumIpAddr.nextElement();    
                    if (!inetAddress.isLoopbackAddress()) {    
                        return inetAddress.getHostAddress().toString();    
                     }    
                 }    
             }    
         } catch (SocketException ex) {    
             //Log.e(TAG, ex.toString());    
         }    
        return null;    
    }   
    
    /**
     * 获得某域名的IP地址
     * @param domain 域名
     * @return
     */
	public static InetAddress[] getServerIP(String domain) {
		InetAddress[] myServer = null;
		try {
			myServer = InetAddress.getAllByName(domain);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return myServer;
	}
}
