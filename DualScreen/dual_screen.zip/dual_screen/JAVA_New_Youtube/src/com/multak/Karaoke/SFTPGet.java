

package com.multak.Karaoke;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import android.util.Log;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.SftpATTRS;

public class SFTPGet {
	static String TAG = "SFTPGet";
	
    public SFTPChannel getSFTPChannel() {
        return new SFTPChannel();
    }
    public static boolean isEmpty(String s) {  
        return s == null || "".equals(s.trim());  
    }
    
    public static long DownloadFileSize(String IP,String DIR,String src) throws Exception {
        long ret = -1;
    	SFTPGet test = new SFTPGet();

        Map<String, String> sftpDetails = new HashMap<String, String>();
        // 设置主机ip，端口，用户名，密码
        sftpDetails.put(SFTPConstants.SFTP_REQ_HOST, IP);//"124.158.9.11");
        sftpDetails.put(SFTPConstants.SFTP_REQ_USERNAME, "orchestra");
        sftpDetails.put(SFTPConstants.SFTP_REQ_PASSWORD, "{qNZdM-E6c9}c-5sU$");
        sftpDetails.put(SFTPConstants.SFTP_REQ_PORT, "22");
        
        SFTPChannel channel = test.getSFTPChannel();
        ChannelSftp chSftp = channel.getChannel(sftpDetails, 120000);
        
        
        //Vector list;
        SftpATTRS attr;
        
        

        
        try {
        boolean isCd = false;
        if (!isEmpty(DIR)) {  
        	chSftp.cd(DIR);  
            isCd = true;  
        }  	
        attr = chSftp.stat(src);
        long fileSize = attr.getSize();
        ret = fileSize;
        Log.i(TAG,"source file length " + fileSize);
        
        
        
       
            
            
            if(isCd)
            	chSftp.cd("..");
           
            
        } catch (Exception e) {
            e.printStackTrace();
 
            
        } finally {
            chSftp.quit();
            channel.closeChannel();
            
        }
        return ret;
    }

    
    public static long DownloadFile(String IP,String DIR,String src,String dst) throws Exception {
        long ret = -1;
    	SFTPGet test = new SFTPGet();

        Map<String, String> sftpDetails = new HashMap<String, String>();
        // 设置主机ip，端口，用户名，密码
        sftpDetails.put(SFTPConstants.SFTP_REQ_HOST, IP);//"124.158.9.11");
        sftpDetails.put(SFTPConstants.SFTP_REQ_USERNAME, "orchestra");
        sftpDetails.put(SFTPConstants.SFTP_REQ_PASSWORD, "{qNZdM-E6c9}c-5sU$");
        sftpDetails.put(SFTPConstants.SFTP_REQ_PORT, "22");
        
        SFTPChannel channel = test.getSFTPChannel();
        ChannelSftp chSftp = channel.getChannel(sftpDetails, 120000);
        
        
        //Vector list;
        SftpATTRS attr;
        
        

        FileProgressMonitor FPMonitor = null;
        try {
        boolean isCd = false;
        if (!isEmpty(DIR)) {  
        	chSftp.cd(DIR);  
            isCd = true;  
        }  	
        attr = chSftp.stat(src);
        long fileSize = attr.getSize();
        ret = fileSize;
        Log.i(TAG,"source file length " + fileSize);
        
        OutputStream out = new FileOutputStream(dst);
        
        
        try
        {
        	 FPMonitor = new FileProgressMonitor(fileSize);
             chSftp.get(src, dst, FPMonitor); // 代码�?1
        }catch (Exception e)
        {
        	e.printStackTrace();
        	if(FPMonitor != null)
            	FPMonitor.stop();
        	chSftp.get(src, dst, FPMonitor,ChannelSftp.RESUME);
        }
        
       
            
            
            if(isCd)
            	chSftp.cd("..");
           
            
        } catch (Exception e) {
            e.printStackTrace();
            if(FPMonitor != null)
            	FPMonitor.stop();
            
        } finally {
            chSftp.quit();
            channel.closeChannel();
            
        }
        return ret;
    }
}