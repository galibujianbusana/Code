package com.multak.Karaoke;  
  
import java.io.File;    
import java.io.FileNotFoundException;    
import java.io.FileOutputStream;    
import java.io.IOException;    
import java.io.InputStream;
import java.io.OutputStream;    
import java.net.SocketException;    
import java.nio.ByteBuffer;
import java.util.Properties;  
import java.util.Timer;
import java.util.TimerTask;
  
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import android.util.Log;
  
  
public class FtpUtil {  
  
	private static String TAG = "FtpUtil";
	public static long fileSize = 0;
	public static int transize = 0;
	public static MyListener myListener = null;
	private static long progressInterval = 5 * 1000;
    private static Timer mTimerProgress = null;
    private static TimerTask mTimerTaskProgress = null;
    private static int buffsize = 100 * 1024;
    private static long progress = 0;
	
    public FtpUtil(long fileSize) {
        this.fileSize = fileSize;
    }
    
	public static void ControlUARTJava(int n)
    {
    	if(myListener != null)
    		myListener.ControlUARTJava(n);
    	
    }
    public static void ControlUARTJavas(int n,String content)
    {
    	if(myListener != null)
    		myListener.ControlUARTJavaS(n,content);
    	
    }
    
    
    public static void PorgressTimerStrart()
    {
    	Log.i(TAG,"Try to start progress monitor.");

    	mTimerProgress = new Timer();    
    	mTimerTaskProgress = new TimerTask(){
			
			 @Override
	            public void run() {
				 //miniutecount ++;
				 //Log.i(TAG,"miniutecount " + miniutecount);
				 if(fileSize > 0)
				 {
					// long size = transize;
					 //long progress = (long)(transize * 100) / (long)fileSize;
					 //Log.i(TAG,"transize " + transize + " fileSize " + fileSize + " progress " + progress);
					 //if(progress <= 100)
						//  ControlUARTJavas(184,String.valueOf(progress));
				 }
				
			 }
			
		};
		mTimerProgress.schedule(mTimerTaskProgress, 1000, progressInterval);
        Log.i(TAG,"Progress monitor started.");
        ControlUARTJava(183);
    }
    
    public static void ProgressTimerEnd()
    {
    	Log.i(TAG,"Try to stop progress monitor.");
    	if (mTimerProgress != null) {
    		mTimerProgress.cancel();
    		mTimerProgress.purge();
    		mTimerProgress = null;
            
        }
    	if(mTimerTaskProgress != null){
    		mTimerTaskProgress.cancel();
    		mTimerTaskProgress = null;
    	}
    	Log.i(TAG,"Progress monitor stoped.");
    	
    }
    /** 
     * ��ȡFTPClient���� 
     * 
     * @param ftpHost 
     *            FTP���������� 
     * @param ftpPassword 
     *            FTP ��¼���� 
     * @param ftpUserName 
     *            FTP��¼�û��� 
     * @param ftpPort 
     *            FTP�˿� Ĭ��Ϊ21 
     * @return 
     */  
    public static FTPClient getFTPClient(String ftpHost, String ftpUserName,  
            String ftpPassword, int ftpPort) {  
        FTPClient ftpClient = new FTPClient();  
        try {  
            ftpClient = new FTPClient();  
            ftpClient.connect(ftpHost, ftpPort);// ����FTP������  
            if(!ftpClient.login(ftpUserName, ftpPassword))// ��½FTP������  
            {
            	Log.w(TAG,"login flag false" );
            }
            else
            {
            	Log.w(TAG,"login flag true" );
            }	
            if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {  
                Log.w(TAG,"δ���ӵ�FTP���û������������");  
                ftpClient.disconnect();
                
            } else {  
            	Log.w(TAG,"FTP���ӳɹ���");
            	
            }  
        } catch (SocketException e) {  
            e.printStackTrace();  
            Log.w(TAG,"FTP��IP��ַ���ܴ�������ȷ���á�");  
        } catch (IOException e) {  
            e.printStackTrace();  
            Log.w(TAG,"FTP�Ķ˿ڴ���,����ȷ���á�");  
        }  
        return ftpClient;  
    }  
  
    /* 
     * ��FTP�����������ļ� 
     *  
     * @param ftpHost FTP IP��ַ 
     *  
     * @param ftpUserName FTP �û��� 
     *  
     * @param ftpPassword FTP�û������� 
     *  
     * @param ftpPort FTP�˿� 
     *  
     * @param ftpPath FTP���������ļ�����·�� ��ʽ�� ftptest/aa 
     *  
     * @param localPath ���ص����ص�λ�� ��ʽ��H:/download 
     *  
     * @param fileName �ļ����� 
     */  
    public static void downloadFtpFile(String ftpHost, String ftpUserName,  
            String ftpPassword, int ftpPort, String ftpPath, String localPath,String fname) {  
    	final String Host = ftpHost;
    	final String UserName = ftpUserName;
    	final String PassWord = ftpPassword;
    	final int Port = ftpPort;
    	final String Fpath = ftpPath;
    	final String dst = localPath;
    	final String src = fname;
    	transize = 0;
    	progress = 0;
    	try {
			new Thread(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					FTPClient ftpClient = null;
					byte[] b= new byte[1024];	
					
					
					
					ftpClient = getFTPClient(Host, UserName, PassWord, Port);
					if(ftpClient == null || !ftpClient.isConnected())
					{
						ControlUARTJavas(195,dst);
		        		return;
					}
					
					try
					{
						ftpClient.setControlEncoding("UTF-8"); // ����֧��  
			            ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);  
			            ftpClient.enterLocalPassiveMode();  
						
						
			            if(!ftpClient.changeWorkingDirectory(Fpath))//("Smart K+/SongStore"))
			        	{
			        		Log.w(TAG,"changeWorkingDirectory flag false" );
			        		

			        		if (ftpClient.isConnected()) { 
			        			try { 
			        				ftpClient.logout();
			        				ftpClient.disconnect(); 
			        			} catch (IOException ioe) { } 
			        		 
			        		}
			        		ControlUARTJavas(195,dst);
			        		return;
			        	}
			        	else
			        	{
			        		Log.w(TAG,"changeWorkingDirectory flag true" );
			        		
			        	}
			            //PorgressTimerStrart();
			            File localFile = new File(dst);  
			            OutputStream os = new FileOutputStream(localFile);
			            InputStream in = ftpClient.retrieveFileStream(src);
			            ControlUARTJava(183);
			            int length = 0;
		            	while((length = in.read(b))!= -1)
		            	{
		            		os.write(b, 0, length);
		            		transize += length;
		            		
		            		
		            		long curprogress = transize ;
		            		curprogress = curprogress * 100 / fileSize;
		            		
		            		if(curprogress != progress)
		            		{
		            			progress = curprogress;
		            			if(progress <= 100)
		            			{
		            				Log.i(TAG,"transized " + transize);
		            				ControlUARTJavas(184,String.valueOf(progress));
		            			}
		  						  
		            		}	
		            	}
		            	
		            	os.flush();
		                os.close();  
		                in.close();
		                Log.i(TAG,"setp 1");
		                /*if(!ftpClient.completePendingCommand())
		                {
		                	Log.e(TAG,"Download fail");
		                	//ProgressTimerEnd();
		                	//return -1;
		                	if (ftpClient.isConnected()) { 
			        			try { 
			        				ftpClient.logout();
			        				ftpClient.disconnect(); 
			        			} catch (IOException ioe) { } 
			        		 
			        		}
			        		ControlUARTJavas(195,dst);
			        		return;
		                }
		                */
			            
					}catch(Exception e){
						e.printStackTrace();
						//ProgressTimerEnd();
						if (ftpClient.isConnected()) { 
		        			try { 
		        				ftpClient.logout();
		        				ftpClient.disconnect(); 
		        			} catch (IOException ioe) { } 
		        		 
		        		}
		        		ControlUARTJavas(195,dst);
		        		return;
						
						
		        		//return;
					}
		            	
					
					
					

						

						
						


						
						//finally { 
							//ProgressTimerEnd();
							Log.i(TAG,"setp 2");
							ControlUARTJavas(196,dst);
							if (ftpClient.isConnected()) { 
								try {
									ftpClient.logout(); 
									ftpClient.disconnect(); 
								} catch (IOException ioe) { ioe.printStackTrace();} 
							} 
						//	} 
						
					
						
						
						
					

				}
			}).start();
		} catch (Exception e) {
			Log.i(TAG, "e:" + e.getMessage());
			ControlUARTJavas(195,dst);
		}	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
        
/*
        
        try {  
            
            
  
            if(!ftpClient.changeWorkingDirectory(ftpPath))//("Smart K+/SongStore"))
        	{
        		Log.w(TAG,"changeWorkingDirectory flag false" );
        		

        		if (ftpClient.isConnected()) { 
        			try { 
        				ftpClient.logout();
        				ftpClient.disconnect(); 
        			} catch (IOException ioe) { } 
        		 
        		} 
        		return -1;
        	}
        	else
        	{
        		Log.w(TAG,"changeWorkingDirectory flag true" );
        		
        	}	
        
            
            PorgressTimerStrart();
            transize = 0;
            File localFile = new File(localPath);  
            OutputStream os = new FileOutputStream(localFile);  
            //ftpClient.retrieveFile(fileName, os);
            InputStream in = ftpClient.retrieveFileStream(fname);
            
            try
            {
            	int length = 0;
            	while((length = in.read(b))!= -1)
            	{
            		os.write(b, 0, length);
            		transize += length;
            	}	
            	
            }catch(Exception e)
			{
				e.printStackTrace();
			}
            os.flush();
            os.close();  
            in.close(); 
            if(!ftpClient.completePendingCommand())
            {
            	Log.e(TAG,"Download fail");
            	return -1;
            }	
           
        } catch (FileNotFoundException e) {  
        	Log.e(TAG,"û���ҵ�" + ftpPath + "�ļ�");  
            e.printStackTrace();  
        } catch (SocketException e) {  
        	Log.e(TAG,"����FTPʧ��.");  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
            Log.e(TAG,"�ļ���ȡ����");  
            e.printStackTrace();  
        }  
        ProgressTimerEnd();
        if (ftpClient.isConnected()) { 
			try {
				ftpClient.logout(); 
				ftpClient.disconnect(); 
			} catch (IOException ioe) { } 
		 
		}
        */
		//return transize; 
    }  
  
  
  
}  