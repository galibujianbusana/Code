﻿package com.multak.MK8507MOA;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.UUID;

import com.multak.server.OKSServer;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.multak.Karaoke.JavaVideoLib;
import com.multak.Karaoke.Karaoke;
import com.multak.Karaoke.KaraokeLib;
import com.multak.Karaoke.KaraokeVGALib;
import com.multak.Karaoke.YouTubeListAdapter;
import com.multak.MultakStandard.BaseHelper;
import com.multak.MultakStandard.ConfigFile;
import com.multak.MultakStandard.MultakShortKey;
import com.multak.MultakStandard.MultakShortKey.ShortKey;
import com.multak.MK8507MOA.R;


import com.multak.Karaoke.MultakRunnable;
import com.multak.Karaoke.YouTubeService;
import com.multak.Karaoke.YouTubeListAdapter;

import android.content.Context;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.GestureDetector.OnGestureListener;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.AdapterView.OnItemClickListener;


import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveVideoTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.util.Util;




public class MainActivity extends YouTubeBaseActivity implements OnGestureListener {
	private static final String TAG = "MainActivity";
	
	//用于每次安装之后的随机数
	private static String sID;
	private static final String INSTALLATION = "INSTALLATION";
	
	public static Karaoke mKaraoke = null;
	public static AudioManager mAudioManager = null;
	private static FrameLayout mFrameLayout = null;
	private static boolean download = false;

	private static Context ncontext = null;
	public static SimpleExoPlayer mediaPlayerBoth = null;
	
    public void onCreate(Bundle savedInstanceState) {
    	
    	Log.w(TAG,"MainActivity oncreate-------------------------IN---\n");
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.karaoke_vga);
		mAudioManager = (AudioManager) this.getSystemService(AUDIO_SERVICE);

		mKaraoke = new Karaoke(this);
		mKaraoke.KaraokeInit();
		ncontext = MainActivity.this;
		
		/*
		if(mediaPlayerBoth == null)
		{
			// 1. Create a default TrackSelector
			BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
			TrackSelection.Factory videoTrackSelectionFactory =
			    new AdaptiveVideoTrackSelection.Factory(bandwidthMeter);
			TrackSelector trackSelector = new DefaultTrackSelector(videoTrackSelectionFactory);

			// 2. Create a default LoadControl
			LoadControl loadControl = new DefaultLoadControl();

			// 3. Create the player
			mediaPlayerBoth = ExoPlayerFactory.newSimpleInstance(MainActivity.this, trackSelector, loadControl);
			mediaPlayerBoth.addListener(new PlayerEventListener());
		}
		*/
		
		
		YouTubeListAdapter.setContext(this);
        mFrameLayout = (FrameLayout)findViewById(R.id.youtubeLayout);
        mKaraoke.mGridView = (GridView)findViewById(R.id.youtubeList);
        mKaraoke.mGridView.setVisibility(View.GONE);
        mKaraoke.mProgress = (TextView)findViewById(R.id.progress);
        mKaraoke.mProgress.setVisibility(View.GONE);
        mKaraoke.mWaring = (TextView)findViewById(R.id.waring);
        mKaraoke.mWaring.setVisibility(View.GONE);
        mKaraoke.mWaring.setText(R.string.hdd_low_cap);
        mKaraoke.mYTSearch = (TextView)findViewById(R.id.YoutebeSearch);
        mKaraoke.mYTSearch.setText(R.string.Search_Youtube);
        mKaraoke.mYTSearch.setVisibility(View.GONE);
        String ydownload = KaraokeVGALib.getGLString(4,0);
        Log.i(TAG,"ydownload " + ydownload);
        if(ydownload.equals("DOWNLOAD"))
        {
        	//mKaraoke.mDownload = (ImageButton)findViewById(R.id.download);
        	//mKaraoke.mDownload.setVisibility(View.GONE);
        	download = true;
        }	
        mKaraoke.mGridView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				
				if(mKaraoke.mPriority != null) {
					mKaraoke.mPriority.setVisibility(View.INVISIBLE);
				}
				if(mKaraoke.mSelect != null) {
					mKaraoke.mSelect.setVisibility(View.INVISIBLE);
				}
				if(mKaraoke.mDownload != null) {
					mKaraoke.mDownload.setVisibility(View.INVISIBLE);
				}
				mKaraoke.mFocusID = position;
				mKaraoke.mPriority = (ImageButton)view.findViewById(R.id.priority);
				if(download == true)
				{
					FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mKaraoke.mPriority.getLayoutParams();
					lp.width = 83;
					mKaraoke.mPriority.setLayoutParams(lp);
				}	
				mKaraoke.mPriority.setVisibility(View.VISIBLE);
				mKaraoke.mPriority.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						YouTubeListAdapter adapter = (YouTubeListAdapter)mKaraoke.mGridView.getAdapter();
						KaraokeVGALib.setYoutube(11, adapter.getItemData(mKaraoke.mFocusID).m_videoName, adapter.getItemData(mKaraoke.mFocusID).m_videoID, "");
						Uri uri = Uri.parse(adapter.getItemData(mKaraoke.mFocusID).m_videoThumbUrl);
						Log.i(TAG,"put YPIC " + uri);
						mKaraoke.MapYPIC.put(adapter.getItemData(mKaraoke.mFocusID).m_videoID, uri);
						Log.i(TAG,"put m_videoID " + adapter.getItemData(mKaraoke.mFocusID).m_videoID + " YPIC " + uri);
						mKaraoke.mPriority.setVisibility(View.INVISIBLE);
						mKaraoke.mPriority = null;
						mKaraoke.mSelect.setVisibility(View.INVISIBLE);
						mKaraoke.mSelect = null;
						if(mKaraoke.mDownload != null)
						{
							mKaraoke.mDownload.setVisibility(View.INVISIBLE);
							mKaraoke.mDownload = null;
						}
					}
				});
				
				if(download == true)
				{	
					mKaraoke.mDownload = (ImageButton)view.findViewById(R.id.download);
					FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mKaraoke.mDownload.getLayoutParams();
					lp.topMargin = 94;
					mKaraoke.mDownload.setLayoutParams(lp);
					mKaraoke.mDownload.setVisibility(View.VISIBLE);
					mKaraoke.mDownload.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							YouTubeListAdapter adapter = (YouTubeListAdapter)mKaraoke.mGridView.getAdapter();
							KaraokeVGALib.setYoutube(12, adapter.getItemData(mKaraoke.mFocusID).m_videoName, adapter.getItemData(mKaraoke.mFocusID).m_videoID, "");
							mKaraoke.ControlUARTJava(180);
							
							mKaraoke.mPriority.setVisibility(View.INVISIBLE);
							mKaraoke.mPriority = null;
							mKaraoke.mSelect.setVisibility(View.INVISIBLE);
							mKaraoke.mSelect = null;
							mKaraoke.mDownload.setVisibility(View.INVISIBLE);
							mKaraoke.mDownload = null;
						}
					});
				}
				
				mKaraoke.mSelect = (ImageButton)view.findViewById(R.id.select);
				if(download == true)
				{
					FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mKaraoke.mSelect.getLayoutParams();
					lp.width = 83;
					lp.leftMargin = 83;
					mKaraoke.mSelect.setLayoutParams(lp);
				}
				mKaraoke.mSelect.setVisibility(View.VISIBLE);
				mKaraoke.mSelect.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						YouTubeListAdapter adapter = (YouTubeListAdapter)mKaraoke.mGridView.getAdapter();
						KaraokeVGALib.setYoutube(10, adapter.getItemData(mKaraoke.mFocusID).m_videoName, adapter.getItemData(mKaraoke.mFocusID).m_videoID, "");
						Uri uri = Uri.parse(adapter.getItemData(mKaraoke.mFocusID).m_videoThumbUrl);
						Log.i(TAG,"put m_videoID " + adapter.getItemData(mKaraoke.mFocusID).m_videoID + " YPIC " + uri);
						mKaraoke.MapYPIC.put(adapter.getItemData(mKaraoke.mFocusID).m_videoID, uri);
						mKaraoke.mPriority.setVisibility(View.INVISIBLE);
						mKaraoke.mPriority = null;
						mKaraoke.mSelect.setVisibility(View.INVISIBLE);
						mKaraoke.mSelect = null;
						if(mKaraoke.mDownload != null)
						{
							mKaraoke.mDownload.setVisibility(View.INVISIBLE);
							mKaraoke.mDownload = null;
						}	
						
					}
				});
			}
		});
        
        mKaraoke.mGridView.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
			//	if(keyboardStatus) {
			//		KaraokeLib.setGLString(20, 1, "");
			//	}
				return false;
			}
		});
		
		
		Log.w(TAG,"MainActivity oncreate-------------------------OUT--- \n");
		StartOKSServer();
    }
    
    public static void startYoutubeVideoPreview() {
    	mKaraoke.mstartYoutubeVideoPreview();
	}
	public static void myControlUARTSnd(int n) {
		mKaraoke.m_myControlUARTSnd(n);
	}
	public static void MsgToHDMI(int iparam1, int iparam2, int iparam3, 
			int iparam4, int iparam5, int iparam6, int iparam7, int iparam8,
			String strparam1, String strparam2, String strparam3, String strparam4) {

		mKaraoke.m_MsgToHDMI(iparam1, iparam2, iparam3,
				  iparam4, iparam5, iparam6, iparam7, iparam8,
				  strparam1, strparam2, strparam3, strparam4);
		return;
	}
   
	public static void setYouTubeListState(int state) {
		MultakRunnable runnable = new MultakRunnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Log.w(TAG, "setYouTubeListState" + m_IntParam);
				switch(m_IntParam) {
				case 0:
					mKaraoke.mGridView.setVisibility(View.INVISIBLE);
					break;
				case 1:
					mKaraoke.mGridView.setVisibility(View.VISIBLE);
					if(mKaraoke.YTSearched == false)
						mKaraoke.mYTSearch.setVisibility(View.VISIBLE);
					else
						mKaraoke.mYTSearch.setVisibility(View.GONE);
					break;
				default:
					LayoutParams lp = mFrameLayout.getLayoutParams();
					if(m_IntParam == 10) {
						if(lp.height == 606)
							break;
				    	lp.height = 606;
					} else if(m_IntParam == 11) {
						if(lp.height == 206)
							break;
				    	lp.height = 206;
					} else if(m_IntParam == 12) {
						if(lp.height == 284)
							break;
				    	lp.height = 284;
					} else if(m_IntParam == 13) {
						if(lp.height == 1)
							break;
				    	lp.height = 1;
					}
			    	mFrameLayout.setLayoutParams(lp);
					break;
				}
			}
		};
		runnable.m_IntParam = state;
		mKaraoke.mHandlerEx.post(runnable);
	}
	
	
    
    
    
	public void onBackPressed() {
		BaseHelper.log(TAG, "onBackPressed");
		return;
	}
	
	protected void onPause() {
		super.onPause();
    	if (mKaraoke != null)
    		mKaraoke.KaraokePause();
    }

	protected void onResume() {
		super.onResume();
    	if (mKaraoke != null)
    		mKaraoke.KaraokeResume();
	}

	protected void onStop() {
		if (mKaraoke != null)
			mKaraoke.KaraokeStop();
    	 
		super.onStop();
    }
   
    protected void onDestroy() {
    	BaseHelper.log(TAG, "onDestroy");
    	StopOKSServer();
    	super.onDestroy();
    }
    
	private Handler mHandler = new Handler() {  
        public void handleMessage(Message msg) {  
        	try {
	            switch (msg.what) {
	            default:
	            	break;
	            }
    		} catch(Exception e) {
    			
            }
        };  
    };

    public synchronized static String my_id(Context context) {  
        if (sID == null) {    
            File installation = new File(context.getFilesDir(), INSTALLATION);  
            try {  
                if (!installation.exists())  
                    writeInstallationFile(installation);  
                sID = readInstallationFile(installation);  
            } catch (Exception e) {  
                throw new RuntimeException(e);  
            }  
        }  
        return sID;  
    }  
 
    private static String readInstallationFile(File installation) throws IOException {  
        RandomAccessFile f = new RandomAccessFile(installation, "r");  
        byte[] bytes = new byte[(int) f.length()];  
        f.readFully(bytes);  
        f.close();  
        return new String(bytes);  
    }  
 
    private static void writeInstallationFile(File installation) throws IOException {  
        FileOutputStream out = new FileOutputStream(installation);  
        String id = UUID.randomUUID().toString();  
        id = id.replace("-", "");
        out.write(id.getBytes());  
        out.close();  
    }
    
    public void ControlUART(int n) {
		BaseHelper.log(TAG, "ControlUART " + n);
		try{
			Message msg = new Message();     
            msg.what = n;
            mHandler.sendMessage(msg);
		} catch(Exception e) {
            e.printStackTrace();
        }
	}
    
	@Override
	public boolean onDown(MotionEvent arg0) {
		BaseHelper.log(TAG, "Gesture onDown");
		return false;
	}

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
		BaseHelper.log(TAG, "Gesture onFling");
		
		return false;
	}

	@Override
	public void onLongPress(MotionEvent e) {
		BaseHelper.log(TAG, "Gesture onLongPress");
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
		BaseHelper.log(TAG, "Gesture onScroll");
		
		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {
		BaseHelper.log(TAG, "Gesture onShowPress");
		
	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		BaseHelper.log(TAG, "Gesture onSingleTapUp");
		
		return false;
	}
	int repeatcount = 0;
	@Override
	public boolean dispatchKeyEvent(KeyEvent event) {
		// TODO Auto-generated method stub
		BaseHelper.log(TAG, "dispatchKeyEvent event.getKeyCode() = " + event.getKeyCode());
		if (event.getAction() == KeyEvent.ACTION_DOWN) {
			ShortKey cKeyCode = MultakShortKey.ConvertKeyCodeToCUI(event.getKeyCode(), event);
			if (cKeyCode == ShortKey.mKey_Home) {
				mKaraoke.FinishActivity();
			} else if(cKeyCode == ShortKey.mKey_Mute || cKeyCode == ShortKey.mKey_Volup || cKeyCode == ShortKey.mKey_Voldown){
				KaraokeLib.queueKeyEvent(cKeyCode.ordinal(), 1);
				return super.dispatchKeyEvent(event);
			}else if(cKeyCode == ShortKey.mKey_Delete){ 
				mKaraoke.canceldownload();
			}
			
			else {
				Log.d("Key", "onKeyDown=" + event.getKeyCode() + " " + event.getDisplayLabel() + " " + event.getUnicodeChar() + " " + event.getNumber());
				KaraokeLib.queueKeyEvent(cKeyCode.ordinal(), 1);
				KaraokeVGALib.queueKeyEvent(cKeyCode.ordinal(), 1);
			}
			if(cKeyCode == ShortKey.mKey_MP3)
			{
				repeatcount++;
				
			}
			else if(cKeyCode == ShortKey.mKey_MTV)
			{
				if(repeatcount != 0)
				{
					repeatcount = 0;
					//later
					//Log.w("Youtube","Start update");
					//KaraokeVGALib.setGLString(3, 0, "");
				}
				
			}	
		}
		return true;
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent arg0) {
		// TODO Auto-generated method stub
		if (!ConfigFile.isSupportMouse()) {
			return true;
		}
		return super.dispatchTouchEvent(arg0);
	}
	 
	@Override
	public boolean dispatchTrackballEvent(MotionEvent arg0) {
		// TODO Auto-generated method stub
		if (!ConfigFile.isSupportMouse()) {
			return true;
		}
		return super.dispatchTrackballEvent(arg0);
	}
	private void StartOKSServer() {
		String[] args = new String[] {
				"MTVServer1",
				"-h", "127.0.0.1", 
				"-p", "8081",
				"-d", "/mnt/sda4/KARAOKE/SONG",
			};
		Log.i("OKServer","StartServer");
		OKSServer.StartServer(args);
		

	}
	   
	private void StopOKSServer() {
		OKSServer.StopServer("MTVServer1");
	}
/*	
private class PlayerEventListener implements ExoPlayer.EventListener{
		
		@Override
		public void onLoadingChanged(boolean arg0) {
			// TODO Auto-generated method stub
			//Log.i(TAG, "onLoadingChanged" + arg0);
		}


		@Override
		public void onPlayerError(ExoPlaybackException arg0) {
			// TODO Auto-generated method stub
			Log.i(TAG, "onPlayerError" + arg0);
			
			if(JavaVideoLib.m_UseYouTubeEXO == true){
				JavaVideoLib.youTubeEXOOnError();
			}
		}


		@Override
		public void onPlayerStateChanged(boolean arg0, int arg1) {
			// TODO Auto-generated method stub
			Log.i(TAG, "onPlayerStateChanged " + arg1);
			if(arg1 == ExoPlayer.STATE_ENDED){
				
				//JavaVideoLib.setYouTubeEXOStatus(JavaVideoLib.m_stopped);
				EXOStop();
			}
			else if(arg1 == ExoPlayer.STATE_READY)
			{
				JavaVideoLib.setYouTubeEXOStatus(JavaVideoLib.m_parsed);
			}
			
		}


		@Override
		public void onPositionDiscontinuity() {
			// TODO Auto-generated method stub
			//Log.i(TAG, "onPositionDiscontinuity");
		}


		@Override
		public void onTimelineChanged(Timeline arg0, Object arg1) {
			// TODO Auto-generated method stub
			//Log.i(TAG, "onTimelineChanged");
		}


		@Override
		public void onTracksChanged(TrackGroupArray arg0, TrackSelectionArray arg1) {
			// TODO Auto-generated method stub
			//Log.i(TAG, "onTracksChanged");
		}
		
	}
	
public static void ExoPlay(String url)
{
	
			    dataSourceFactory, extractorsFactory, null, null);
		
		mediaPlayerBoth.setPlayWhenReady(true);
		mediaPlayerBoth.setVideoSurface(JavaVideoLib.mVideoSurface);
		mediaPlayerBoth.prepare(videoSource);
		
		
	} catch (Exception e) {
		
		e.printStackTrace();
		KaraokeLib.setStatus(20, 1, 0);
		
		

	}
	
	
}

public static void EXOStop()
{
	mediaPlayerBoth.stop();
	JavaVideoLib.setYouTubeEXOStatus(JavaVideoLib.m_stopping);
}

public static void EXOPause()
{
	mediaPlayerBoth.setPlayWhenReady(false);
	JavaVideoLib.setYouTubeEXOStatus(JavaVideoLib.m_paused);
}

public static void EXOResume()
{
	mediaPlayerBoth.setPlayWhenReady(true);
	JavaVideoLib.setYouTubeEXOStatus(JavaVideoLib.m_playing);
}*/


}


