package com.multak.MK8507MOA;

import java.util.ArrayList;
import java.util.List;

import com.multak.MK8507MOA.R;
import com.multak.MultakStandard.BaseHelper;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

public class AppUtils {
	private Context mContext;
	public AppUtils(Context context) {
		mContext = context;
	}
	
	public class LauncherItem {
		Drawable icon;
		String name;
		ComponentName component;
		LauncherItem(Drawable d, String s,ComponentName cn) {
			icon = d;
			name = s;
			component = cn;
		}
	};
	    
	public boolean OpenApk(String packagename,String info,int type) {
		Intent it = new Intent(Intent.ACTION_MAIN);
		ArrayList<LauncherItem> lvalue = new ArrayList<LauncherItem>();
		
		PackageManager pkgMgt = mContext.getPackageManager();
		it.addCategory(Intent.CATEGORY_LAUNCHER); 
		List<ResolveInfo> ra =pkgMgt.queryIntentActivities(it,0);
		int GameHallTurn = -1;
		for(int i=0;i<ra.size();i++) {
			ActivityInfo ai = ra.get(i).activityInfo;
			Drawable icon = ai.loadIcon(pkgMgt);
			String label = ai.loadLabel(pkgMgt).toString();
			ComponentName c = new ComponentName(ai.applicationInfo.packageName,ai.name);
			LauncherItem item = new LauncherItem(icon,label,c);
			lvalue.add(item);
			if(ai.applicationInfo.packageName.equals(packagename) == true){
				GameHallTurn = i;
				break;
			}
			Log.w("MKLauncher", ai.applicationInfo.packageName);
		}
		if (GameHallTurn >= 0) {
			Bundle bundle = new Bundle();
			bundle.putString(packagename,info);
			it.putExtras(bundle);
			it.setComponent(lvalue.get(GameHallTurn).component);
			it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
			it.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
			BaseHelper.log(null, "lvalue.get(GameHallTurn).component = " + lvalue.get(GameHallTurn).component);
			mContext.startActivity(it);
			SetAnimate((Activity) mContext,type);
			return true;
		}
		return false;
	}
	
	public void OpenBrowser(String url,int type) {
		Intent intent= new Intent();       
        intent.setAction("android.intent.action.VIEW");   
        Uri content_url = Uri.parse(url);  
        intent.setData(content_url);          
        intent.setClassName("com.android.browser","com.android.browser.BrowserActivity");  
        mContext. startActivity(intent);
        SetAnimate((Activity) mContext,type);
	}

	private void SetAnimate(Activity mContext,int type) {
		if (type == 0) {
			mContext.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
		} else if (type == 1) {
			mContext.overridePendingTransition(R.anim.slide_up, R.anim.slide_down);
		} else if (type == 2) {
			mContext.overridePendingTransition(R.anim.sequential, R.anim.sequential);
		} else if (type == 3) {
			mContext.overridePendingTransition(R.anim.together, R.anim.together);
		} else if (type == 4) {
			mContext.overridePendingTransition(R.anim.flip, R.anim.flip);
		} else if (type == 5) {
			mContext.overridePendingTransition(R.anim.rotate, R.anim.rotate);
		} else if (type == 6) {
			mContext.overridePendingTransition(R.anim.zoom_in, R.anim.zoom_out);
		} else if (type == 7) {
			mContext.overridePendingTransition(R.anim.zoom_enter, R.anim.zoom_exit);
		} else if (type == 8) {
			mContext.overridePendingTransition(R.anim.blink, R.anim.blink);
		} else if (type == 9) {
			mContext.overridePendingTransition(R.anim.bounce, R.anim.bounce);
		}
	}
}
