package com.multak.MultakStandard;

import android.content.Context;
import android.util.Log;

public class MultakStandard
{
	//外部使用
	public static int NetDetectClose = -1;
	public static int NetDetectNormal = 0;
	
	public static int StorageDetectClose = -1;
	public static int StorageDetectNormal = 0;
	
	public static String []Suppliers = {"MTK","MSTAR","AML"};
	public static String []Customers = {"SkyWorth","Haier","Hisense","TCL"};
	public static String []Platforms = {"Android","Android22","Android23","Android40"};
	public static String []PlatType = {"Phone","PAD","TV"};
	//内部使用
	private Context mcontext = null,mcontext2 = null;
	private String mplatform = "";
	private int mnetflag = -1;
	private String TAG = "MultakStandard";
	private MultakConnect mMultakConnect = null;
	//下面参数是过滤所有网络情况
	private int supporttypes[] = {MultakConnect.NetTypeEth0,MultakConnect.NetTypeWifi,MultakConnect.NetTypeMobileDefault,MultakConnect.NetTypeBlueTooth,MultakConnect.NetTypeWiMax,MultakConnect.NetTypeMobileMMS,MultakConnect.NetTypeMobileSUPL,MultakConnect.NetTypeMobileDun};//������Ҫ���ܵ���������
	
	public MultakStandard(String platform,int netflag,int usbflag) {
		mplatform = platform;
		mnetflag = netflag;
		Log.e(TAG,"MultakStandard");
	}
	
	public void MultakStandardInit(Context context) {
		mcontext = context;
		if (mnetflag >= 0){
			mMultakConnect = new MultakConnect(mcontext,mplatform,MultakConnect.GET_NET_ACT_INIT_STATUS | MultakConnect.GET_NET_AVAILABLE_STATUS,supporttypes);
		}
		return;
	}
	

	public void MultakStandardInit2(Context context) {
		mcontext2 = context;
		if (mnetflag >= 0) {
			mMultakConnect = new MultakConnect(mcontext2,mplatform,MultakConnect.GET_NET_BROADCAST_STATUS,supporttypes);
		}
		return;
	}
	
	public void MultakStandardInit2(Context context,MultakConnectListener mMultakConnectListener) {
		mcontext2 = context;
		if (mnetflag >= 0) {
			mMultakConnect = new MultakConnect(context,mMultakConnectListener,mplatform,MultakConnect.GET_NET_BROADCAST_STATUS,supporttypes);
		}
		return;
	}
	
	public void MultakStandardUnInit() {
		Log.e(TAG,"MultakStandardUnInit");
		if (mnetflag >= 0) {
			mMultakConnect.MultakConnectUnInit(0);
			mnetflag = -1;
		}
		return;
	}
	
	public void MultakStandardUnInit2() {
		Log.e(TAG,"MultakStandardUnInit2");
		if (mnetflag >= 0) {
			mMultakConnect.MultakConnectUnInit(1);
			mnetflag = -1;
		}
		return;
	}
}