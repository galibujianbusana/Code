package com.multak.MultakStandard;

import java.util.ArrayList;
import java.util.List;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class MultakStorage {
	public class StorageInfo {
		public String devPath = "";
        public String path = "";
        public String label = "";
        public String format = "";
        public String uuid = "";
        public long totalSpace;
        public long usedSpace;
        public long availSpace;
	}
	
	public static int GET_USB_ALL_STATUS = 0xFF;
	public static int GET_USB_BROADCAST_STATUS = 0x02;
	public static int GET_USB_INIT_STATUS = 0x01;
	
	private int USB_DETECT_DELAY = 1000;//姝ゅ弬鏁板彲浠ユ牴鎹钩鍙拌皟鏁�骞冲彴蹇彲璋冨皬 鏀跺埌骞挎挱鍚庢壂鎻忕洏绗︾殑绛夊緟鏃堕棿
	private Context mcontext = null;
	private String mplatform = "";
	private String LastReceiveName = "";
	private String Lastintent = "";
	private String TAG = "MultakStorage";
	private MultakStorageListener mMultakStorageListener = null;
	private Handler mHandler;
	private int registerflag = 0;
	private final BroadcastReceiver mMountReceiver;
	
	MultakStorage(Context context,String platform,int UsbStatusFlag) {
		mcontext = context;
		mplatform = platform;
		this.mMultakStorageListener = (MultakStorageListener)mcontext;
		mMountReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				if (intent.getAction().equals("android.intent.action.MEDIA_MOUNTED")
					|| intent.getAction().equals("android.intent.action.MEDIA_REMOVED")
					||intent.getAction().equals("android.intent.action.MEDIA_BAD_REMOVAL")) {
					String ReceiveName = intent.getData().toString();
					if ((!intent.getAction().equals("android.intent.action.MEDIA_MOUNTED")) 
							&& LastReceiveName.equals(ReceiveName) 
							&& (Lastintent.equals("android.intent.action.MEDIA_REMOVED")
							|| Lastintent.equals("android.intent.action.MEDIA_BAD_REMOVAL"))) {
						LastReceiveName = ReceiveName;
						Lastintent = intent.getAction().toString();
						return;
					} else {
						Log.w(TAG,"============Scan Storage Device============");
						LastReceiveName = ReceiveName;
						Lastintent = intent.getAction().toString();
						Message msg = mHandler.obtainMessage(1);
						mHandler.sendMessageDelayed(msg, USB_DETECT_DELAY);
					}
				}
			}
		};
		
		if ((UsbStatusFlag & 0x01) == GET_USB_INIT_STATUS) {
			GetDevice();
		}
		if ((UsbStatusFlag & 0x02) == GET_USB_BROADCAST_STATUS) {
			IntentFilter intentFilter = new IntentFilter(Intent.ACTION_MEDIA_MOUNTED);
			intentFilter.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
			intentFilter.addAction(Intent.ACTION_MEDIA_REMOVED);
			intentFilter.addAction(Intent.ACTION_MEDIA_BAD_REMOVAL);
			intentFilter.addDataScheme("file");
			mcontext.registerReceiver(mMountReceiver, intentFilter);
			registerflag = 1;
		}
		
		mHandler = new Handler() {  
	        public void handleMessage(Message msg) {  
	        	try {
					switch (msg.what) 
					{
					case 1:
						GetDevice();
						break;
					default:
						break;
					}
	    		} catch(Exception e) {
	                e.printStackTrace();
	            }
	        };  
	    };
	}
	
	public void MultakStorageUnInit(int mode) {
		Log.w(TAG,"unregisterReceiver mMountReceiver mode = " + mode);
		if (mode == 1) {
			if (mMountReceiver != null && registerflag == 1) {
				mcontext.unregisterReceiver(mMountReceiver);
				registerflag = 0;
			}
		}
		return;
	}
	
	private List<SystemUtil.ExternDiskInfo> diskInfos = new ArrayList<SystemUtil.ExternDiskInfo>();
	private StorageInfo mStorageInfo = new StorageInfo();
	private void GetDevice() {
		//Log.w(TAG,"============ GetDevice ===========");
		mMultakStorageListener.MultakStorageDeviceStart();
		diskInfos.clear();
		SystemUtil.getDevice(diskInfos, mplatform);
		if (diskInfos != null) {
			for (SystemUtil.ExternDiskInfo diskInfo:diskInfos) {
				mStorageInfo.devPath = diskInfo.devPath;
				mStorageInfo.path = diskInfo.path;
				mStorageInfo.label = diskInfo.label;
				mStorageInfo.format = diskInfo.format;
				mStorageInfo.uuid = diskInfo.uuid;
				mStorageInfo.totalSpace = diskInfo.totalSpace;
				mStorageInfo.usedSpace = diskInfo.usedSpace;
				mStorageInfo.availSpace = diskInfo.availSpace;
				mMultakStorageListener.MultakStorageDeviceAdd(mStorageInfo);
			}
		}
		mMultakStorageListener.MultakStorageDeviceEnd();
		return;
	}
}
