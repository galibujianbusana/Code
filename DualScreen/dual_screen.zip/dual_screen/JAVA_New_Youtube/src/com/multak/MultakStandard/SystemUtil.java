﻿package com.multak.MultakStandard;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.StatFs;
import android.util.Log;

public class SystemUtil {
	private static String TAG = "SystemUtil";
    static public class ExternDiskInfo {
        public String devPath = "";
        public String path = "";
        public String label = "";
        public String format = "";
        public String uuid = "";
        public long totalSpace;
        public long usedSpace;
        public long availSpace;
    }
    
    static public class NetInfo {
    	public String netIP = "";
    	public String netBcast = "";
    	public String netMask = "";
        public String netMacAddr = "";
    }

    /**
     * 
     * @return system space in Byte
     */
    public static long getTotalSpace(String diskRootPath) {
        try {
            StatFs sf = new StatFs(diskRootPath);
            long blockSize = sf.getBlockSize();
            long blockCount = sf.getBlockCount();
            return blockSize * blockCount;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * 
     * @return available space in Byte
     */
    public static long getAvailSpace(String diskRootPath) {
        try {
            StatFs sf = new StatFs(diskRootPath);
            long blockSize = sf.getBlockSize();
            long availCount = sf.getAvailableBlocks();
            return blockSize * availCount;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * 
     * @return file or directory size in Byte
     */
    public static long getFileSize(String filePath) {
        File file = new File(filePath);
        if (!file.isDirectory()) {
            return file.length();
        }
        long totalSize = 0;
        if (file.listFiles() == null) {
            return 0;
        }
        for (File subFile : file.listFiles()) {
            totalSize += getFileSize(subFile.getAbsolutePath());
        }
        return totalSize;
    }

    public static int execCmd(String cmd) {
        Process process;
        try {
            process = Runtime.getRuntime().exec(cmd);
            // flush all output avoid blocking
            InputStream input = process.getInputStream();
            byte[] buffer = new byte[100];
            while (input.read(buffer) > 0)
                System.out.print(new String(buffer));
            input.close();
            input = process.getErrorStream();
            while (input.read(buffer) > 0)
                System.out.print(new String(buffer));
            input.close();
            return process.waitFor();
        } catch (Exception e) {
            return -1;
        }
    }
    
    public static String execCmdandFilterWithRes(String cmd,String filter) {
    	String result = null;  
    	String line1 = null;
    	try {
    		Process process = Runtime.getRuntime().exec(cmd);
    		InputStream inStream = process.getInputStream();
    		BufferedReader BR = new BufferedReader(new InputStreamReader(inStream, "ISO-8859-1"));
    		while ((line1 = BR.readLine()) != null&& line1.contains(filter)== false) {
    		}
    	} catch (Exception e) {
    		Log.e(TAG,"Failed to exe command:" + cmd + ", error:" + e.toString());
    	}
    	result = line1;
    	return result;
    }
    /**
     * 
     * @param cmd
     *            command to be executed
     * @return lines of result strings
     */
    public static List<String> execCmdWithRes(String cmd) {
        try  {
            List<String> results = new ArrayList<String>();
            Process process = Runtime.getRuntime().exec(cmd);
            InputStream inStream = process.getInputStream();
            BufferedReader BR = new BufferedReader(new InputStreamReader(inStream, "ISO-8859-1"));
            String line1 = null;
            while ((line1 = BR.readLine()) != null) {
                results.add(line1);
            }
            if (results.size() == 0) {
                return null;
            }
            BR.close();
            InputStream error = process.getErrorStream();
            byte[] buffer = new byte[100];
            while (error.read(buffer) > 0)
                ;
            error.close();
            process.waitFor();
            return results;

        } catch (Exception e) {
            Log.e(TAG,"Failed to exe command:" + cmd + ", error:" + e.toString());
        }
        return null;
    }

    public static void getsystemroot() {
        Class<?> clazz;
        try {
            clazz = Class.forName("android.os.SystemProperties");
            Method setMethod = clazz.getMethod("set", String.class, String.class);
            Method getMethod = clazz.getMethod("get", String.class, String.class);
            setMethod.invoke(null, "ctl.start", "linuxcmd");

            while (true) {
                String result = (String) getMethod.invoke(null, "init.svc.linuxcmd", " ");
                if (result != null && result.equals("stopped")) {
                    break;
                }
                // Thread.sleep(500);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {

            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    private static List<String> toReadResFile(String mPath)  {

        //Log.i(TAG, "[toReadResFile]: to read rsult file. " + mPath);
        File file = new File(mPath);
        List<String> results = new ArrayList<String>();
        if (!file.exists()) {
            Log.e(TAG, "[toReadResFile]: " + mPath + " does not exist.");
            return null;
        }
        try {
            BufferedReader BR = new BufferedReader(new InputStreamReader(
                    new FileInputStream(mPath), "ISO-8859-1"));

            String line1 = null;
            while ((line1 = BR.readLine()) != null) {
                results.add(line1);
            }
            BR.close();
            if (results.size() == 0) {
                return null;
            }
            // // InputStream error = process.getErrorStream();
            // byte[] buffer = new byte[100];
            // while (error.read(buffer) > 0)
            // ;
            // error.close();
            // process.waitFor();
            return results;

        } catch (Exception e) {
        	Log.e(TAG,"Failed to exe command:");
        }
        return null;
    }

    public static List<String> execCmdWithResMTK(String cmd)  {
        if (cmd.equals("busybox blkid")) {
            getsystemroot();
            return toReadResFile("/tmp/blkid.txt");
        } else {
            try {
                List<String> results = new ArrayList<String>();
                Process process = Runtime.getRuntime().exec(cmd);
                InputStream inStream = process.getInputStream();
                BufferedReader BR = new BufferedReader(
                        new InputStreamReader(inStream, "ISO-8859-1"));
                String line1 = null;
                while ((line1 = BR.readLine()) != null) {
                    results.add(line1);
                }
                if (results.size() == 0) {
                    return null;
                }
                BR.close();
                InputStream error = process.getErrorStream();
                byte[] buffer = new byte[100];
                while (error.read(buffer) > 0)
                    ;
                error.close();
                process.waitFor();
                return results;

            } catch (Exception e) {
            	Log.e(TAG,"Failed to exe command:" + cmd + ", error:" + e.toString());
            }
            return null;
        }
    }
    
    public static void getEthInfo(NetInfo netinfo) {
    	netinfo.netBcast = "";
    	netinfo.netIP = "";
    	netinfo.netMacAddr = "";
    	netinfo.netMask = "";
    	String mac = null;

		File fp;
		fp = new File("/sys/class/net/eth0/address");//
		if (fp.isFile() == true && fp.canRead() == true) {
			FileReader fr;
    		try {
    			fr = new FileReader("/sys/class/net/eth0/address");
    			BufferedReader br = new BufferedReader(fr);
    			mac = br.readLine();
    			if (mac.length() != 17) {
    				Log.e(TAG,"Invaild Mac Addr");
    			} else {
    				netinfo.netMacAddr = mac;
    			}
    			br.close();
    			fr.close();
    		} catch (FileNotFoundException e1) {
    			// TODO Auto-generated catch block
    			e1.printStackTrace();
    		}catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
		} else {
			Log.e(TAG,"can not get Eth Mac");
		}
    	return;
    }
    public static void getDevice(List<ExternDiskInfo> diskInfos,String platform) {
    	List<String> mountedDevices = null;
    	mountedDevices = execCmdWithRes("mount");
         for (String mount : mountedDevices) {
             String[] items = mount.split(" ");

             if (items[0].startsWith("/dev/block/vold")) {
                 ExternDiskInfo info = new ExternDiskInfo();
                 info.devPath = items[0];
                 if (items[1].startsWith("/")) {
                	 info.path = items[1];
                	 Log.w("UsbShortCut","info.path = " + info.path);
                     if (items[2].startsWith("type")) {
                    	 info.format = items[3];
                     } else  {
                    	 info.format = items[2];
                     }
                 } else {
                	 info.path = items[2];
                     if (items[3].startsWith("type")) {
                    	 info.format = items[4];
                     } else {
                    	 info.format = items[3];
                     }
                 }
                 info.totalSpace = getTotalSpace(info.path);
                 if (info.totalSpace == 0) {
                     continue;
                 }
                 info.availSpace = getAvailSpace(info.path);
                 info.usedSpace = info.totalSpace - info.availSpace;
                 if (platform != null && platform.startsWith(MultakStandard.Suppliers[0]) && platform.startsWith(MultakStandard.Platforms[0])) {
                	 getLabelandUuidMTK(info);
                 } else {
	                 info.label = "null";
	                 info.uuid = "null";
                 }
                 
                 //add platform special!!!
                 if (info.path.startsWith("/mnt/sdcard") || info.path.startsWith("/mnt/secure/asec")) {
                	 continue;
                 }
                 diskInfos.add(info);
             }
         }
    	return; 	
    }
    
    public static void getLabelandUuidMTK(ExternDiskInfo info) {

        List<String> blkidInfos = null;
        blkidInfos = execCmdWithResMTK("busybox blkid");
        if (blkidInfos != null) {
            for (String blkid : blkidInfos) {
                // if (blkid.startsWith(info.devPath))
                if (blkid.substring(0, blkid.lastIndexOf(":")).equals(info.devPath)) {
                    int label_pos = blkid.indexOf("LABEL=");
                    int uuid_pos = blkid.indexOf("UUID=");
                    if (uuid_pos >= 0) {
                        String uuidItem = blkid.substring(uuid_pos, blkid.length());
                        uuidItem = uuidItem.substring(6, uuidItem.length() - 1);// remove
                        // UUID=
                        info.uuid = uuidItem;
                    }
                    if (label_pos > 0) {
                        String labelItem = blkid.substring(label_pos, uuid_pos - 1);
                        labelItem = labelItem.substring(7, labelItem.length() - 1);// remove
                        
                        // LABEL=
                        if (StringEncoder.isUTF8(labelItem)) {
                            labelItem = StringEncoder.convertString(labelItem, "UTF-8");
                        } else {
                            labelItem = StringEncoder.convertString(labelItem, "GBK");
                        }
                        info.label = labelItem;
                    }
                }
            }
        }
        return;
    }

    /**
     * require permission android.permission.GET_TASKS
     * 
     * @param context
     * @return
     */
    public static String getCurrentRunningPackage(Context context) {
        ComponentName cn = ((ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE))
                .getRunningTasks(1).get(0).topActivity;
        return cn.getPackageName();
    }

    private static long[] readCPUValues() {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream("/proc/stat")));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("cpu")) {
                    line = line.substring(3).trim();
                    String[] values = line.split(" ");
                    long[] result = new long[values.length];
                    for (int i = 0; i < values.length; i++) {
                        result[i] = Long.parseLong(values[i]);
                    }
                    reader.close();
                    return result;
                }
            }
            reader.close();
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public static int getCpuUsage() {
        long[] valuesBefore = readCPUValues();
        if (valuesBefore == null) {
            return 0;
        }
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
        	
        }
        long[] valuesAfter = readCPUValues();
        if (valuesAfter == null) {
            return 0;
        }
        long idleTime = valuesAfter[3] - valuesBefore[3];
        long totalTime = (valuesAfter[0] + valuesAfter[1] + valuesAfter[2] + valuesAfter[3]
                + valuesAfter[4] + valuesAfter[5] + valuesAfter[6])
                - (valuesBefore[0] + valuesBefore[1] + valuesBefore[2] + valuesBefore[3]
                        + valuesBefore[4] + valuesBefore[5] + valuesBefore[6]);
        return (int) ((1.0f - ((float) idleTime / (float) totalTime)) * 100);
        /*
         * final String UserStart = "User "; final String SystemStart = "System "; List<String>
         * topInfos = execCmdWithRes("top -m 1 -n 1"); int UserUsage = 0; int SystemUsage = 0; for
         * (String info : topInfos) { if (info.startsWith(UserStart)) { String[] items =
         * info.split(","); for (String item : items) { item = item.trim(); if
         * (item.startsWith(UserStart)) { String usage = item.substring(UserStart.length(),
         * item.length() - 1); try { UserUsage = Integer.parseInt(usage); } catch (Exception e) {
         * 
         * } } else if (item.startsWith(SystemStart)) { String usage =
         * item.substring(SystemStart.length(), item.length() - 1); try { SystemUsage =
         * Integer.parseInt(usage); } catch (Exception e) {
         * 
         * } } } } } return UserUsage + SystemUsage;
         */
    }
    
    public boolean fileIsExist(String filePath) {
		File f = new File(filePath);
		if (f.exists() != true) {
			return false;
		}
		return true;
	}

    public  static void checkPath(String path, boolean needMedia)
    {
    	File ktvfile3 = new File(path);
		if(ktvfile3.canRead() == false) {
    		if(ktvfile3.mkdir() == true) {
    			
        	}
		}
		
		if(!needMedia) {
			ktvfile3 = new File(path + "/.nomedia");
			if(ktvfile3.canRead() == false) {
	    		if(ktvfile3.mkdir() == true) {
	    			
	        	}
			}									
		}
    } 
    
    public static void deleteDir(File dir) { 
        if (dir == null || !dir.exists() || !dir.isDirectory()) 
            return; // 检查参数 
        for (File file : dir.listFiles()) { 
            if (file.isFile()) 
                file.delete(); // 删除所有文件 
            else if (file.isDirectory()) 
                deleteDir(file); // 递规的方式删除文件夹 
        } 
        dir.delete();// 删除目录本身 
    } 
    
    public static void copyFile(String oldPath, String newPath) { 
        try { 
            int bytesum = 0; 
            int byteread = 0; 
            File oldfile = new File(oldPath); 
            if (oldfile.exists()) { //文件存在时 
                InputStream inStream = new FileInputStream(oldPath); //读入原文件 
                FileOutputStream fs = new FileOutputStream(newPath); 
                byte[] buffer = new byte[1444];
                while ( (byteread = inStream.read(buffer)) != -1) { 
                    bytesum += byteread; //字节数 文件大小 
                    System.out.println(bytesum); 
                    fs.write(buffer, 0, byteread); 
                } 
                fs.close();
                inStream.close(); 
            } 
        } catch (Exception e) { 
            System.out.println("复制单个文件操作出错"); 
            e.printStackTrace(); 
        } 
    } 
    
    public static void deleteFile(String FilePath) 
    {
    	File file = new File(FilePath);
    	if (file.exists()) { // 判断文件是否存在
    		if (file.isFile()) { // 判断是否是文件
    			file.delete(); // delete()方法 你应该知道 是删除的意思;
    		} else if (file.isDirectory()) { // 否则如果它是一个目录
    		
    		} else {
    			
    		}
    	}
    }
    
    public static void copyFolder(String oldPath, String newPath) { 

        try { 
            (new File(newPath)).mkdirs(); //如果文件夹不存在 则建立新文件夹 
            File a=new File(oldPath); 
            String[] file=a.list(); 
            File temp=null; 
            for (int i = 0; i < file.length; i++) { 
                if(oldPath.endsWith(File.separator)){ 
                    temp=new File(oldPath+file[i]); 
                } else { 
                    temp=new File(oldPath+File.separator+file[i]); 
                } 

                if(temp.isFile()) { 
                    FileInputStream input = new FileInputStream(temp); 
                    FileOutputStream output = new FileOutputStream(newPath + "/" + 
                            (temp.getName()).toString()); 
                    byte[] b = new byte[1024 * 5]; 
                    int len; 
                    while ( (len = input.read(b)) != -1) { 
                        output.write(b, 0, len); 
                    } 
                    output.flush(); 
                    output.close(); 
                    input.close(); 
                } 
                if(temp.isDirectory()) {//如果是子文件夹 
                    copyFolder(oldPath+"/"+file[i],newPath+"/"+file[i]); 
                } 
            } 
        } catch (Exception e) { 
            System.out.println("复制整个文件夹内容操作出错"); 
            e.printStackTrace(); 
        } 
    }
    
    
    public static String computeSignature(String baseString, String keyString) throws GeneralSecurityException, UnsupportedEncodingException {

        SecretKey secretKey = null;
        byte[] keyBytes = keyString.getBytes();
        secretKey = new SecretKeySpec(keyBytes, "HmacSHA256");
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKey);

        byte[] text = baseString.getBytes();
        byte[] digest = mac.doFinal(text);
        
        BigInteger hash = new BigInteger(1, digest);
        String enc = hash.toString(16);
        if ((enc.length() % 2) != 0) {
        	enc = "0" + enc;
        }
        return enc.toLowerCase();
    }
    
    public static String getLocalIpAddress() {    
        try {    
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {    
                 NetworkInterface intf = en.nextElement();    
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {    
                     InetAddress inetAddress = enumIpAddr.nextElement();    
                    if (!inetAddress.isLoopbackAddress()) {    
                        return inetAddress.getHostAddress().toString();    
                     }    
                 }    
             }    
         } catch (SocketException ex) {    
             //Log.e(TAG, ex.toString());    
         }    
        return null;    
    }   
    
    /**
     * 获得某域名的IP地址
     * @param domain 域名
     * @return
     */
     public static InetAddress[] getServerIP(String domain) 
     {
    	 InetAddress[] myServer = null;
    	 try  {
	   	  	myServer = InetAddress.getAllByName(domain);
	   	 } catch (Exception e) {
	   	  	e.printStackTrace();
	   	 }
	   	 return myServer;
     }    
}
