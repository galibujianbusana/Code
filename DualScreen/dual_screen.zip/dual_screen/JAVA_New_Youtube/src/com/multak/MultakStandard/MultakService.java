package com.multak.MultakStandard;

import java.util.ArrayList;
import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.util.Log;

public class MultakService {
	private static Context mContext = null;
	private static ComponentName component = null;
	private static final String TAG = "MultakService";
	private static Intent it = null;
	
	private static boolean addLauncherService(Intent it, String ServiceName) {

		PackageManager pkgMgt = mContext.getPackageManager();
		ActivityManager actMgt = (ActivityManager)mContext.getSystemService(Context.ACTIVITY_SERVICE);
		//it.addCategory(Intent.CATEGORY_LAUNCHER); 
	         
		List<ResolveInfo> ra =pkgMgt.queryIntentServices(it,0);
		ServiceInfo ai;
		int i;
		for(i=0;i<ra.size();i++) {
			ai = ra.get(i).serviceInfo;
			if(ai.applicationInfo.packageName.equals(ServiceName) == true) {
				component = new ComponentName(ai.applicationInfo.packageName,ai.name);
				Log.w(TAG, ai.applicationInfo.packageName);
				ArrayList<RunningServiceInfo> runningService = (ArrayList<RunningServiceInfo>) actMgt.getRunningServices(30);
				for(i = 0 ; i<runningService.size();i++) {
					if(runningService.get(i).service.getPackageName().toString().equals(ai.applicationInfo.packageName)) {
						return false;
					}
				}
				return true;
			}
		}
		return false;
	}
	
	public static void CloseService() {
		if (mContext != null && it != null) {
			mContext.stopService(it);
			component = null;
			it = null;
		}
	}
	 
	public static void OpenService(String strname ,String info,Context context) {
		if (it == null) {
			mContext = context;
	 		it = new Intent(Intent.ACTION_MAIN);
	 		Bundle bundle = new Bundle();
	 		bundle.putString(strname,info);
	 		it.putExtras(bundle);
	 		if (addLauncherService(it,strname)) {
		 		it.setComponent(component);
		 		mContext.startService(it);
	 		} else {
	 			Log.w(TAG,"Service is open no need open again");
	 		}
		}
	}	
}
