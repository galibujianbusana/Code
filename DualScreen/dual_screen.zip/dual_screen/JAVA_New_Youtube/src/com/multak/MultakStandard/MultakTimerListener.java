package com.multak.MultakStandard;

public interface MultakTimerListener {
	public void MultakTimerCallBack(int FixRate);
}
