package com.multak.MultakStandard;

import android.view.KeyEvent;

public class MultakShortKey
{
	public enum ShortKey {
		mKey_Null,		
		mKey_Up,
		mKey_Down,
		mKey_Left,
		mKey_Right,
		mKey_Enter,		
		mKey_Power,
		mKey_Mute,
		mKey_BGV,
		mKey_Record,
		mKey_Restart,			//10
		mKey_Home,
		mKey_Repeat,
		mKey_Delete,
		mKey_Copy,
		mKey_Num_0,
		mKey_Num_1,
		mKey_Num_2,
		mKey_Num_3,
		mKey_Num_4,
		mKey_Num_5,				//20
		mKey_Num_6,
		mKey_Num_7,
		mKey_Num_8,
		mKey_Num_9,
		mKey_PROG,
		mKey_BKSP,
		mKey_Karaoke,
		mKey_Selected,
		mKey_Setup,
		mKey_Return,			//30
		mKey_Play,
		mKey_Stop,
		mKey_Pause,
		mKey_Next,
		mKey_Keyup,
		mKey_Keydown,
		mKey_Tempoup,
		mKey_Tempodown,
		mKey_Volup,
		mKey_Voldown,			//40
		mKey_Melodyup,
		mKey_Melodydown,
		mKey_Vocal,
		mKey_Cheer,
		mKey_Prev,
		mKey_MTV,
		mKey_MP3,
		mKey_Newsong,
		mKey_FAVO,
		mKey_other_Melodyup,	//50
		mKey_other_Melodydown,
		mKey_Zoom,
	}
    private static long lasttime = 0;
    private static long lasttimeflag = -1;
    private static long lastrespondflag = 0;
    private static long lastrespondtime = 0;
    private static long KeyNotRespondTimeHigh = 600;
    private static long KeyNotRespondTimeMiddle = 450;
    private static long KeyNotRespondTimeLow = 150;
    private static long KeyNotRespondTimeUpDown = 80;
    
	public static boolean KeyProtect(ShortKey keyCode) {
		long curtime = System.currentTimeMillis();
		if (lasttimeflag == -1) {
			lastrespondtime = 0;
			lastrespondflag = 1;
		} else if (lasttimeflag == 0) {
			lastrespondtime = lastrespondtime - (curtime - lasttime);
			lastrespondflag = 1;
		} else {
			lastrespondtime = lastrespondtime - (curtime - lasttime);
			lastrespondflag = 0;
		}
		lasttime = curtime;
		
		if (lastrespondflag == 0) {
			switch(keyCode)
			{
			case mKey_Next:
			case mKey_Repeat:
			case mKey_BGV:
			case mKey_Delete:
			case mKey_Copy:
				lastrespondtime = lastrespondtime + KeyNotRespondTimeHigh;
			break;
			case mKey_Mute:
			case mKey_Karaoke:
			case mKey_Selected:
			case mKey_Setup:
			case mKey_Vocal:
			case mKey_FAVO:
			case mKey_Play:
			case mKey_Stop:
			case mKey_Pause:
			case mKey_Restart:
				lastrespondtime = lastrespondtime + KeyNotRespondTimeMiddle;
			break;
			case mKey_Up:
			case mKey_Down:
				lastrespondtime = lastrespondtime + KeyNotRespondTimeUpDown;
			break;
			case mKey_Left:
			case mKey_Right:
			case mKey_Return:
				//lastrespondtime = lastrespondtime;
			break;
			default:
				lastrespondtime = lastrespondtime + KeyNotRespondTimeLow;
			break;
			}
		} else {
			
		}
		
		if (lastrespondtime <= 0) {
			if (lasttimeflag != 0) {
				if (lastrespondflag == 1) {
					lasttimeflag = 1;
				} else {
					lasttimeflag = -1;
				}
			} else {
				lasttimeflag = -1;
			}
			return true;
		} else {
			lasttimeflag = 0;
			return false;
		}
	}
	
	public static ShortKey ConvertKeyCodeToCUI(int aKeyCode, KeyEvent event) {	
		switch(aKeyCode)
		{
		case KeyEvent.KEYCODE_POWER:
			return ShortKey.mKey_Power;
		case KeyEvent.KEYCODE_MUTE:
			return ShortKey.mKey_Mute;
		case KeyEvent.KEYCODE_F1:
			return ShortKey.mKey_BGV;
		case KeyEvent.KEYCODE_MENU:
			return ShortKey.mKey_Record;
		case KeyEvent.KEYCODE_F2:
			return ShortKey.mKey_Restart;
		case KeyEvent.KEYCODE_ALT_LEFT:		//57:
			return ShortKey.mKey_Home;
		case KeyEvent.KEYCODE_SUBTITLE:
			return ShortKey.mKey_Delete;
		case KeyEvent.KEYCODE_F3:
			return ShortKey.mKey_Repeat;
		case KeyEvent.KEYCODE_BACK:			//KeyEvent.KEYCODE_DEL:
			return ShortKey.mKey_Return;
		case KeyEvent.KEYCODE_F4:
			return ShortKey.mKey_Copy;
		case KeyEvent.KEYCODE_1:
			return ShortKey.mKey_Num_1;
		case KeyEvent.KEYCODE_2:
			return ShortKey.mKey_Num_2;
		case KeyEvent.KEYCODE_3:
			return ShortKey.mKey_Num_3;
		case KeyEvent.KEYCODE_4:
			return ShortKey.mKey_Num_4;
		case KeyEvent.KEYCODE_5:
			return ShortKey.mKey_Num_5;
		case KeyEvent.KEYCODE_6:
			return ShortKey.mKey_Num_6;
		case KeyEvent.KEYCODE_7:
			return ShortKey.mKey_Num_7;
		case KeyEvent.KEYCODE_8:
			return ShortKey.mKey_Num_8;
		case KeyEvent.KEYCODE_9:
			return ShortKey.mKey_Num_9;
		case KeyEvent.KEYCODE_SPACE:
			return ShortKey.mKey_PROG;
		case KeyEvent.KEYCODE_0:
			return ShortKey.mKey_Num_0;
		case KeyEvent.KEYCODE_DEL:			//KeyEvent.KEYCODE_BACK:
			return ShortKey.mKey_BKSP;
		case KeyEvent.KEYCODE_F5:
			return ShortKey.mKey_Karaoke;
		case KeyEvent.KEYCODE_F6:
			return ShortKey.mKey_Selected;
		case KeyEvent.KEYCODE_DPAD_UP:
			return ShortKey.mKey_Up;
		case KeyEvent.KEYCODE_DPAD_DOWN:
			return ShortKey.mKey_Down;
		case KeyEvent.KEYCODE_DPAD_LEFT:
			return ShortKey.mKey_Left;
		case KeyEvent.KEYCODE_DPAD_RIGHT:
			return ShortKey.mKey_Right;
		case KeyEvent.KEYCODE_ENTER:
		case KeyEvent.KEYCODE_DPAD_CENTER:
			return ShortKey.mKey_Enter;
		case KeyEvent.KEYCODE_F7:
			return ShortKey.mKey_Setup;
		case KeyEvent.KEYCODE_ESCAPE:
			return ShortKey.mKey_Return;
		case KeyEvent.KEYCODE_MEDIA_PLAY:
			return ShortKey.mKey_Play;
		case KeyEvent.KEYCODE_MEDIA_STOP:
			return ShortKey.mKey_Stop;		
		case KeyEvent.KEYCODE_MEDIA_PAUSE:
			return ShortKey.mKey_Pause;
		case KeyEvent.KEYCODE_MEDIA_NEXT:
			return ShortKey.mKey_Next;	
		case KeyEvent.KEYCODE_SEMICOLON:	//KeyEvent.KEYCODE_NUMPAD_0:
			return ShortKey.mKey_Keyup;	
		case KeyEvent.KEYCODE_APOSTROPHE:	//KeyEvent.KEYCODE_NUMPAD_1:
			return ShortKey.mKey_Tempoup;	
		case KeyEvent.KEYCODE_VOLUME_UP:
			return ShortKey.mKey_Volup;	
		case KeyEvent.KEYCODE_GRAVE:		//KeyEvent.KEYCODE_NUMPAD_2:
			return ShortKey.mKey_Melodyup;	
		case KeyEvent.KEYCODE_COMMA:		//KeyEvent.KEYCODE_NUMPAD_3:
			return ShortKey.mKey_Keydown;	
		case KeyEvent.KEYCODE_PERIOD:		//KeyEvent.KEYCODE_NUMPAD_4:
			return ShortKey.mKey_Tempodown;	
		case KeyEvent.KEYCODE_VOLUME_DOWN:
			return ShortKey.mKey_Voldown;	
		case KeyEvent.KEYCODE_SLASH:		//KeyEvent.KEYCODE_NUMPAD_5:
			return ShortKey.mKey_Melodydown;
		case KeyEvent.KEYCODE_AUDIO:
			return ShortKey.mKey_Vocal;
		case KeyEvent.KEYCODE_F9:
			return ShortKey.mKey_Cheer;
		case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
			return ShortKey.mKey_Prev;
		case KeyEvent.KEYCODE_F10:
			return ShortKey.mKey_MTV;
		case KeyEvent.KEYCODE_F11:
			return ShortKey.mKey_MP3;
		case KeyEvent.KEYCODE_F12:
			return ShortKey.mKey_Newsong;
		case KeyEvent.KEYCODE_EQUALS:		//KeyEvent.KEYCODE_NUMPAD_DOT:
			return ShortKey.mKey_FAVO;
		case KeyEvent.KEYCODE_PAGE_UP:
			return ShortKey.mKey_other_Melodyup;
		case KeyEvent.KEYCODE_PAGE_DOWN:
			return ShortKey.mKey_other_Melodydown;
		case KeyEvent.KEYCODE_F8:
			return ShortKey.mKey_Zoom;	
		default:
			return ShortKey.mKey_Null;
		}
	}
}
