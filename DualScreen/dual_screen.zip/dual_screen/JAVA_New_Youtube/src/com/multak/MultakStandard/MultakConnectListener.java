package com.multak.MultakStandard;

import java.util.List;

import com.multak.MultakStandard.MultakConnect.NetType;

public interface MultakConnectListener {
	public void MultakConnectBroadcastOn(List<NetType> type,int typenum);
	public void MultakConnectBroadcastOff();
	public void MultakConnectBroadcastAll(List<NetType> type,int typenum);
}
