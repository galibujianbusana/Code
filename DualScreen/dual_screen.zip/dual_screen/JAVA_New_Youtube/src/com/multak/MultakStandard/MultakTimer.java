package com.multak.MultakStandard;

import java.io.FileReader;
import java.util.Timer;
import java.util.TimerTask;

import android.content.Context;
import android.util.Log;

public class MultakTimer {
	private Context mContext = null;
	private String TAG = "MultakTimer";
	private MultakTimerTask mMultakTimerTask = null;
	private Timer mTimer = null;
	FileReader fr = null;
	private int FixRate = 15;
	private MultakTimerListener mMultakTimerListener = null;
	
	MultakTimer(Context tcontext) {
		Log.w(TAG,"MultakTimer Init!!!!");
		mContext = tcontext;
		this.mMultakTimerListener = (MultakTimerListener)mContext;
		
		mTimer = new Timer();
		mMultakTimerTask = new MultakTimerTask();
		mTimer.scheduleAtFixedRate(mMultakTimerTask, 0, FixRate);
	}
	
	public void MultakTimerUninit() {
		mMultakTimerTask.cancel();
		mTimer.cancel();
		Log.w(TAG,"MultakTimer Uninit!!!!");
	}
	
	class MultakTimerTask extends TimerTask {
		@Override
		public void run() {
			// TODO Auto-generated method stub
			mMultakTimerListener.MultakTimerCallBack(FixRate);
		}
	}

}
