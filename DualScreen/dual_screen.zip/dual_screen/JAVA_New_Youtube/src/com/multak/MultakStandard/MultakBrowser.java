package com.multak.MultakStandard;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class MultakBrowser {
	Context mContext;
	String mUrl;
	
	MultakBrowser(Context context,String url) {
		mContext = context;
		mUrl = url;
		EnterNetPage();
	}
	
	public void MultakBrowserUnInit() {
		return;
	}
	
  	public void EnterNetPage() {
  		Intent intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        Uri CONTENT_URI_BROWSERS = Uri.parse(mUrl);
        intent.setData(CONTENT_URI_BROWSERS);
        intent.setClassName("com.android.browser", "com.android.browser.BrowserActivity");
        mContext.startActivity(intent);
  		return;
  	}
}
