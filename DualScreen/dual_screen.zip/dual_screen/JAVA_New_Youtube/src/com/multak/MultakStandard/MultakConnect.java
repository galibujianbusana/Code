package com.multak.MultakStandard;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import com.multak.MK8507MOA.SimpleWebServer;
import com.multak.MultakStandard.MultakTimer.MultakTimerTask;
import com.multak.MultakStandard.SystemUtil.NetInfo;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.util.Log;

import com.multak.Karaoke.Karaoke;

@SuppressWarnings("unused")
public class MultakConnect {
	public class NetType {
		public State stats;
		public int type;
		public String mac;
	}
	public static int GET_NET_ALL_STATUS = 0xFF;
	public static int GET_NET_BROADCAST_STATUS = 0x02;
	public static int GET_NET_ACT_INIT_STATUS = 0x01;
	public static int GET_NET_AVAILABLE_STATUS = 0x04;
	
	public static int NetTypeMobileDefault = ConnectivityManager.TYPE_MOBILE;
	public static int NetTypeMobileMMS = ConnectivityManager.TYPE_MOBILE_MMS;
	public static int NetTypeMobileSUPL = ConnectivityManager.TYPE_MOBILE_SUPL;
	public static int NetTypeMobileDun = ConnectivityManager.TYPE_MOBILE_DUN;
	public static int NetTypeWifi = ConnectivityManager.TYPE_WIFI;//wifi
	public static int NetTypeEth0 = 9;//android api 12
	public static int NetTypeBlueTooth = 7;//android api 13
	public static int NetTypeWiMax = ConnectivityManager.TYPE_WIMAX ;
	
	private int CONNECT_DETECT_DELAY = 1000;
	private Context mcontext = null;
	private String mplatform = "";
	private static String TAG = "MultakConnect";
	private int startflag = 0;
	private Handler handler = null;
	private static int mtypes[] = null;
	private static MultakConnectListener mMultakConnectListener = null;
	private static int laststatus = -99;
	private static int lastinfosize = -1;
	private static int NeedBroadcastFlag = 0;
	private static int MaxNetNum = 10;
	private static ArrayList<NetType> AllNetType;
	private static ArrayList<NetType> AllCurNetType;
	private static int NetNum = 0;
	private Runnable updateThread;
	private NetType mNetType = new NetType();
	private NetInfo netinfo = new NetInfo();
	
	private static boolean isAPConnect = false;

	private MultakTimerTask mMultakTimerTask = null;
	private Timer mTimer = null;
	
	private static boolean ServerStatus = false;
	private static String intToIp(int i) {
		return (i & 0xFF ) + "." +  ((i >> 8 ) & 0xFF) + "." +       
        		((i >> 16 ) & 0xFF) + "." + ( i >> 24 & 0xFF) ;  
	}
	
	@SuppressWarnings("static-access")
	private void MultakConnectStart(String platform,int NetStatusFlag,int supporttypes[]) {
		mplatform = platform;
		mtypes = supporttypes;
		laststatus = -99;
		lastinfosize = -1;
		NeedBroadcastFlag = 0;
		AllNetType = new ArrayList<NetType>();
		AllCurNetType = new ArrayList<NetType>();
		if (AllNetType == null || AllCurNetType == null) {
			Log.e(TAG,"NetType == null");
		} else {
			if ((NetStatusFlag & 0x04) == GET_NET_AVAILABLE_STATUS) {
				GetAllNetWorkInfo(mcontext);
			}
			if ((NetStatusFlag & 0x01) == GET_NET_ACT_INIT_STATUS) {
				GetCurNetWorkInfo(mcontext);
			}
			GetCurNetWorkInfo(mcontext);
			/*updateThread = new Runnable() {
				
				public void run() {
					// TODO Auto-generated method stub
					GetCurNetWorkInfo(mcontext);
					if (startflag == 1)
					{
						handler.postDelayed(updateThread, CONNECT_DETECT_DELAY);
					}
				}
			};*/
			if ((NetStatusFlag & 0x02) == GET_NET_BROADCAST_STATUS) {
				startflag = 1;
				if (handler == null)
				{
					handler = new Handler();
					mTimer = new Timer();
					mMultakTimerTask = new MultakTimerTask();
					mTimer.schedule(mMultakTimerTask, 0, CONNECT_DETECT_DELAY);
					//handler.post(updateThread);
				}
			}
		}
	}
	
	MultakConnect(Context context,MultakConnectListener mMultakConnectListener,String platform,int NetStatusFlag,int supporttypes[]) {
		mcontext = context;
		this.mMultakConnectListener = (MultakConnectListener)mMultakConnectListener;
		MultakConnectStart(platform,NetStatusFlag,supporttypes);
	}
	
	MultakConnect(Context context,String platform,int NetStatusFlag,int supporttypes[]) {
		mcontext = context;
		this.mMultakConnectListener = (MultakConnectListener)mcontext;
		MultakConnectStart(platform,NetStatusFlag,supporttypes);
	}
	
	class MultakTimerTask extends TimerTask {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			if (startflag == 1) {
				GetCurNetWorkInfo(mcontext);
			}
		}
	}
	
	private static boolean SpecialJudgetJustForA20Extern(NetworkInfo info,Context context) {
		if (info.getType() == NetTypeWifi) {
			WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
			if (wifiManager.isWifiEnabled()) {
        		WifiInfo coninfo = wifiManager.getConnectionInfo();
            	//Log.w(TAG,"wifi SSID [" + coninfo.getSSID() + "] is connect!");
            	//Log.w(TAG,"wifi level [" + coninfo.getRssi() + "] is connect!");
        		if(coninfo.getSSID() != null && (!coninfo.getSSID().equals("0x")) && coninfo.getRssi() > -1000) {
        			return true;
        		} else {
        			return false;
        		}
			}
			return false;
		} else {
			return true;
		}
	}
	
	private boolean SpecialJudgetJustForA20(NetworkInfo info) {
		if (info.getType() == NetTypeWifi) {
			WifiManager wifiManager = (WifiManager) mcontext.getSystemService(Context.WIFI_SERVICE);
			if (wifiManager.isWifiEnabled()) {
        		WifiInfo coninfo = wifiManager.getConnectionInfo();
            	//Log.w(TAG,"wifi SSID [" + coninfo.getSSID() + "] is connect!");
            	//Log.w(TAG,"wifi level [" + coninfo.getRssi() + "] is connect!");
        		if(coninfo.getSSID() != null && (!coninfo.getSSID().equals("0x")) && coninfo.getRssi() > -1000) {
        			return true;
        		} else {
        			return false;
        		}
			}
			return false;
		} else {
			return true;
		}
	}
	
	public static boolean isNetworkAvailable(Context context) {
		boolean ret = false;
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity == null || connectivity.equals("")) {
			ret = false;
        } else {
            NetworkInfo info = connectivity.getActiveNetworkInfo();
            if(info == null || !info.isConnected()) {
				ret = false;
            } else {
                if(info.isAvailable())  {
                	if (mtypes != null) {
	           	    	 for (int type:mtypes) {
	           	    		if (type == info.getType() && SpecialJudgetJustForA20Extern(info,context)) {
	           	    			Log.w(TAG, "**** network is on");
								ret = true;
	           	    		}
	           	    	 }
                	} else {
                		ret = true;
                	}
                }
            }
        }

		if(isAPConnect == true) {
			Log.w(TAG, "**** ap network is on");
			ret = true;
		}

        return ret;
    }
	
	public void MultakConnectUnInit(int mode) {
		if (mode == 1) {
			//startflag = 0;
			if (startflag == 1) {
				startflag = 0;
				mMultakTimerTask.cancel();
				mTimer.cancel();
			}
		}
		return;
	}
	
	private void GetAllNetWorkInfo(NetworkInfo[] info,int i) {
		 if (mtypes != null) {
	    	 for (int type:mtypes)  {
	    		 if (info[i].getType() == type && SpecialJudgetJustForA20(info[i]))  {
					if (NetNum < MaxNetNum) {
						//Log.w(TAG, "Network All");
						String mac = "";
						//NetType mNetType = new NetType();
						mNetType.type = info[i].getType();
    					if (mNetType.type == NetTypeBlueTooth) {
    						mac = GetBluetoothMacAddr(mcontext);
    					}
    					
    					if (mNetType.type == NetTypeWifi) {
    						mac = GetWifiMacAddr(mcontext);
    					} else if (mNetType.type == NetTypeEth0) {
    						SystemUtil.getEthInfo(netinfo);
    						mac = netinfo.netMacAddr;
    					}
    					
    					if (mac != null) {
    						mNetType.mac = ChangeMacAddrType(mac);
    					} else {
    						mNetType.mac = "";
    					}
    					mNetType.stats = info[i].getState();
    					AllNetType.set(NetNum, mNetType);
    					NetNum++;
    				 }
	    		 }
	    	 }
		 }
	}
	
	private void GetAllNetWorkInfo(Context context) {
		NetNum = 0;
		//NetType mNetType = new NetType();
		mNetType.stats = NetworkInfo.State.UNKNOWN;
		mNetType.type = -1;
		mNetType.mac = "";
		AllNetType.clear();
		for (int i = 0;i < MaxNetNum;i++) {	
			AllNetType.add(mNetType);
		}
		ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity == null) {
			
		} else {
		   NetworkInfo[] info = connectivity.getAllNetworkInfo();
		   if (info != null) {
			    for (int i = 0; i < info.length; i++) {
				    GetAllNetWorkInfo(info,i);
			    }
			    //Log.w(TAG, "Network All info.length = " + info.length);
		   	}
		}
	   // Log.w(TAG, "Network All AllNetType = " + AllNetType);
		//Log.w(TAG, "Network All NetNum = " + NetNum);
		mMultakConnectListener.MultakConnectBroadcastAll(AllNetType,NetNum);
		return;
	}
	
	private void GetCurNetWorkInfo(NetworkInfo[] info,int i,int ActInfoSize) {
		 if (mtypes != null) {
	    	 for (int type:mtypes) {
	    		 if (info[i].getType() == type && SpecialJudgetJustForA20(info[i])) {
	    			 if (laststatus != info[i].getType() || lastinfosize != ActInfoSize || laststatus < 0 || laststatus == -99) {	
	    				// Log.w(TAG,"info[" + i + "].getType() = " + info[i].getType());
		    			// Log.w(TAG,"info[" + i + "].getExtraInfo() = " + info[i].getExtraInfo());
    					laststatus = info[i].getType();
    					lastinfosize = ActInfoSize;
    					if (NetNum < MaxNetNum) {
    						Log.w(TAG, "Network link");
    						String mac = "";
    						//NetType mNetType = new NetType();
    						mNetType.type = info[i].getType();
	    					if (mNetType.type == NetTypeBlueTooth) {
	    						mac = GetBluetoothMacAddr(mcontext);
	    					}
	    					
	    					if (mNetType.type == NetTypeWifi) {
	    						mac = GetWifiMacAddr(mcontext);
	    					} else if (mNetType.type == NetTypeEth0) {
	    						SystemUtil.getEthInfo(netinfo);
	    						mac = netinfo.netMacAddr;
	    					}
	    					
	    					if (mac != null) {
	    						mNetType.mac = ChangeMacAddrType(mac);
	    					} else {
	    						mNetType.mac = "";
	    					}
	    					mNetType.stats = info[i].getState();
	    					AllCurNetType.set(NetNum, mNetType);
	    					NetNum++;
	    					NeedBroadcastFlag = 1;
    					} else {
    						 Log.e(TAG,"NetTypeNum is too large MaxNetNum = " + MaxNetNum);
    					}
    				 }
	    		 }
	    	 }
    	 }
	}
	
	private enum WIFI_AP_STATE {
		WIFI_AP_STATE_DISABLING, WIFI_AP_STATE_DISABLED, WIFI_AP_STATE_ENABLING,  WIFI_AP_STATE_ENABLED, WIFI_AP_STATE_FAILED
	}

	private boolean isWifiApEnabled(Context context) {
		return getWifiApState(context) == WIFI_AP_STATE.WIFI_AP_STATE_ENABLED;
	}

	private WIFI_AP_STATE getWifiApState(Context context) {
		int tmp;
		try {
			WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
			Method method = wifiManager.getClass().getMethod("getWifiApState");
			tmp = ((Integer) method.invoke(wifiManager));
			//Log.e(TAG,"getWifiApState is " + tmp);
			// Fix for Android 4
			if (tmp > 10) {
				tmp = tmp - 10;
			}
			if(tmp >= WIFI_AP_STATE.class.getEnumConstants().length)
				return WIFI_AP_STATE.WIFI_AP_STATE_FAILED;
			else
				return WIFI_AP_STATE.class.getEnumConstants()[tmp];
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return WIFI_AP_STATE.WIFI_AP_STATE_FAILED;
		}
	}

	private void GetCurNetWorkInfo(Context context) {
		NeedBroadcastFlag = 0;
		NetNum = 0;
		//NetType mNetType = new NetType();
		mNetType.stats = NetworkInfo.State.UNKNOWN;
		mNetType.type = -1;
		mNetType.mac = "";
		AllCurNetType.clear();
		for (int i = 0;i < MaxNetNum;i++) {	
			AllCurNetType.add(mNetType);
		}
		ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity == null) {
			NeedBroadcastFlag = -1;
		} else {
		   NetworkInfo[] info = connectivity.getAllNetworkInfo();
		   if (info != null) {	
			   int ActInfoSize = 0;
			   for (int i = 0; i < info.length; i++) {
				     if (info[i].getState() == NetworkInfo.State.CONNECTED) {
						//Log.e(TAG, "CONNECTED " + i + " is " + info[i].getTypeName() + " " + info[i].getType());
				    	 ActInfoSize++;
				     }
			   }
			   if (ActInfoSize == 0 && lastinfosize != ActInfoSize) {
				   NeedBroadcastFlag = -1;
			   }
			   for (int i = 0; i < info.length; i++) {
				   if (info[i].getState() == NetworkInfo.State.CONNECTED) {
					   GetCurNetWorkInfo(info,i,ActInfoSize);
				   }
			   }
			   if (NeedBroadcastFlag > 0) {
				   mMultakConnectListener.MultakConnectBroadcastOn(AllCurNetType,NetNum);
			   }
		   } else {
			   NeedBroadcastFlag = -1; 
		   }

		   if(NeedBroadcastFlag <= 0) {
			   if(isWifiApEnabled(context)) {
				   NeedBroadcastFlag = 1;
				   lastinfosize = 1;
				   if(!isAPConnect) {
					   isAPConnect = true;
					   mMultakConnectListener.MultakConnectBroadcastOn(AllCurNetType, NetNum);
				    	/*if(!ServerStatus)
				    	{
				    		String ip = "192.168.43.1";
				    		String[] args = new String[]{
				                 "-h", ip, 
				                 "-d", "/mnt/sdcard/",
			                 };
				    		SimpleWebServer.StartServer(args);
				    		ServerStatus = true;
				    		Karaoke.CreateQRCodeBitmap("http://"+ip+":8080/code.png","/mnt/sdcard/code.png");
					    	}*/
				   }
			   } else {
					isAPConnect = false;
					/*if(ServerStatus)
					{
						SimpleWebServer.StopServer();
						ServerStatus = false;
					}*/
			   }
		   }
			/*else if(ServerStatus)
			{
				SimpleWebServer.StopServer();
				ServerStatus = false;
			}*/
		}

		if (NeedBroadcastFlag < 0  && (lastinfosize >= 0 || lastinfosize == -1)) {
			laststatus = -1;
			lastinfosize = 0;
			isAPConnect = false;
			Log.w(TAG, "Network unlinked");
			mMultakConnectListener.MultakConnectBroadcastOff();
		}
		return;
	}

	private static String ChangeMacAddrType(String fullmac) {
		String mac;
		mac = fullmac.replace(":", "");
		mac = mac.replace(".", "");
		return mac;
	}
	
	private static String GetBluetoothMacAddr(Context context) {
		BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (mBluetoothAdapter == null) {
			return "";
		} else {
			return mBluetoothAdapter.getAddress();
		}
	}

	private static String GetWifiMacAddr(Context context) {
		WifiManager wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
		WifiInfo wifiinfo = wifi.getConnectionInfo();
		return wifiinfo.getMacAddress();
	}

	private static int GetFirstNetworkAvailable(Context context,int []types) {
		ConnectivityManager connectivity = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity == null) {
			
		} else {
			NetworkInfo[] info = connectivity.getAllNetworkInfo();
			if (info != null) {
				for (int i = 0; i < info.length; i++) {
					if (info[i].getState() == NetworkInfo.State.CONNECTED ) {
						for (int type:types) {
							if (info[i].getType() == type&& SpecialJudgetJustForA20Extern(info[i],context)) {
								return info[i].getType();
							}
						}
					}
				}
			}
		}
		return -1;
	}
	
	public static boolean isWiFiActive(Context inContext) {
		WifiManager mWifiManager = (WifiManager) inContext
				.getSystemService(Context.WIFI_SERVICE);
		WifiInfo wifiInfo = mWifiManager.getConnectionInfo();
		int ipAddress = wifiInfo == null ? 0 : wifiInfo.getIpAddress();
		if (mWifiManager.isWifiEnabled() && ipAddress != 0) {
			BaseHelper.log(TAG, "**** WIFI is on");
			return true;
		} else {
            //System.out.println("**** WIFI is off");
			return false;   
		}
	}
}
