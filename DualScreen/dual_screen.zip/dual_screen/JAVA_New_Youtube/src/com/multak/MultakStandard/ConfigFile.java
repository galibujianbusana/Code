package com.multak.MultakStandard;

public class ConfigFile {
	public static boolean isSupportMouse() {
		return true;
	}
}
