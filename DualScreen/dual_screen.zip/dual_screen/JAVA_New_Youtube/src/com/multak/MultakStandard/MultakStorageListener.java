package com.multak.MultakStandard;

import com.multak.MultakStandard.MultakStorage.StorageInfo;

public interface MultakStorageListener {
	public void MultakStorageDeviceStart();
	public void MultakStorageDeviceEnd();
	public void MultakStorageDeviceAdd(StorageInfo deviceInfo);
}
