package com.multak.MultakStandard;

import java.io.UnsupportedEncodingException;

import android.util.Log;

public class StringEncoder {
    public static boolean isUTF8(String input) {
        byte[] utf;
        try {
            utf = input.getBytes("ISO-8859-1");
        } catch (UnsupportedEncodingException e) {
            return false;
        }
        int ix;
        char c;
        /*
         * utf is a string of 1, 2, 3 or 4 bytes.  The valid strings
         * are as follows (in "bit format"):
         *    0xxxxxxx                                      valid 1-byte
         *    110xxxxx 10xxxxxx                             valid 2-byte
         *    1110xxxx 10xxxxxx 10xxxxxx                    valid 3-byte
         *    11110xxx 10xxxxxx 10xxxxxx 10xxxxxx           valid 4-byte
         */
        for (ix = 0; ix < utf.length;) { 
        	c = (char)utf[ix];
        	/* string is 0-terminated */
        	if ((c & 0x80) == 0x00) {
        		/* 1-byte code, starts with 10 */
        		ix++;
        	} else if ((c & 0xe0) == 0xc0) {
        		/* 2-byte code, starts with 110 */
        		if (utf.length < 2) {
        			return false;
        		}
        		if ((utf[ix+1] & 0xc0 ) != 0x80) {
        			return false;
        		}
        		ix += 2;
        	} else if ((c & 0xf0) == 0xe0) {
        		/* 3-byte code, starts with 1110 */
        		if (utf.length  < 3) {
        			return false;
        		}
        		if (((utf[ix+1] & 0xc0) != 0x80) ||
        				((utf[ix+2] & 0xc0) != 0x80)) {
        			return false;
        		}
        		ix += 3;
        	} else if ((c & 0xf8) == 0xf0) {
        		/* 4-byte code, starts with 11110 */
        		if (utf.length  < 4) {
        			return false;
        		}
        		if (((utf[ix+1] & 0xc0) != 0x80) ||
                   ((utf[ix+2] & 0xc0) != 0x80) ||
                   ((utf[ix+3] & 0xc0) != 0x80)) {
                   return false;
        		}
        		ix += 4;
        	}  else if ((c & 0xFB) == 0xF8) {
        		/* 4-byte code, starts with 11110 */
        		if (utf.length  < 5) {
        			return false;
        		}
        		if (((utf[ix+1] & 0xc0) != 0x80) ||
                   ((utf[ix+2] & 0xc0) != 0x80) ||
                   ((utf[ix+3] & 0xc0) != 0x80)||
                   ((utf[ix+4] & 0xc0) != 0x80)) {
        			return false;
        		}
        		ix += 5;
        	} else { /* unknown encoding */
        		return false;
        	}
        }
        return true;
	}
    
    public static String convertString(String original, String targetCharSet) {
    	try {
			return new String(original.getBytes("ISO-8859-1"), targetCharSet);
		} catch (UnsupportedEncodingException e) {
			Log.e("USBLABEL","failed to convert string [" + original + "] to " + targetCharSet);
			return original;
		}
    }
}

